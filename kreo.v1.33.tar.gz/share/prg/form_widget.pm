#!/usr/bin/perl -w

# form_widget.pm version 1.33 Janvier 2026 par Thierry Le Gall

# fonctions de création et de positionnement de widgets dans un formulaire

require Tk::BrowseEntry;

# création des widgets
sub form_widget {
    if    ($_[0] eq 'entry'    ) { $_[1]->Entry      (-textvariable=>$_[2], -width =>$_[3]) }
    elsif ($_[0] eq 'textvar'  ) { $_[1]->Label      (-textvariable=>$_[2]) }
    elsif ($_[0] eq 'text'     ) { $_[1]->Label      (-text =>$_[2]) }
    elsif ($_[0] eq 'button'   ) { $_[1]->Button     (-text =>$_[2] , -command =>$_[3]) }
    elsif ($_[0] eq 'check'    ) { $_[1]->Checkbutton(-text =>$_[2] , -variable=>$_[3]) }
    elsif ($_[0] eq 'check_com') { $_[1]->Checkbutton(-text =>$_[2] , -variable=>$_[3], -command=>$_[4],                   -highlightthickness=>0) }
    elsif ($_[0] eq 'radio'    ) { $_[1]->Radiobutton(-text =>$_[2] , -variable=>$_[3],   -value=>$_[4], -command=>$_[5] , -highlightthickness=>0) }
    elsif ($_[0] eq 'browse'   ) { $_[1]->BrowseEntry(-label=>$_[2] , -variable=>$_[3], -choices=>$_[4],   -width=>$_[5] , -state=>'readonly') } }

# positionnement des widgets
sub form_widget_place {
    if    ($_[0] eq 'grid' ) { $_[1]->grid (-row =>$_[2] , -column=>$_[3], -sticky=>'w'     ) }
    elsif ($_[0] eq 'place') { $_[1]->place(-rely=>$_[2] , -relx  =>$_[3], -anchor=>'center') }
    elsif ($_[0] eq 'pack' ) { $_[1]->pack (-side=>'left', -fill  =>'x'  , -expand=>'yes'   ) } }

1;
