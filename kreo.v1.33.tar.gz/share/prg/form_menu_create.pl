#!/usr/bin/perl -w

# form_menu_create.pl version 1.33 Janvier 2026 par Thierry Le Gall

($form,$var) = @ARGV;

$i = $lg = 0;
foreach (split/;/,$var) {
   if ( $i % 2 ) { push @fct  , $_ }
   else          { push @name , $_ ; $x = length($_); $lg = $x if $x > $lg }
   $i++ }

$lg = "%-$lg"."s" ;
$i = 0;
foreach ( @name ) { $resu .= sprintf " $lg ;%-s;\n" , $_ , $fct[$i]; $i++ }
`printf "$resu" > $form`;
