sub form_var_create {
    my($form,$title,$nb) = (split/;/,`form.tk form_var_create`);
    return if ! $form || ! $title || ! $nb; 
    return if $nb > 9;
    my($i,$var);
    $i = 0; while ( $nb > $i ) { $i ++; $var .= "variable $i ;" }
    $form =~ tr/ /_/;
    $form = "$dir{var}/form/$form";
    `form_var_create.pl $form "$title" "$var"`; # creation d'un formulaire temporaire 
    $var = `form.tk $form`;                     # execution pour la saisie des noms des variables 
    `form_var_create.pl $form "$title" "$var"`; # creation du formulaire final
    $var = `form.tk $form`;                     # test du formulaire
    file_select($form) }                        # affichage du fichier du formulaire

sub form_menu_create {
    my($form,$nb) = (split/;/,`form.tk form_menu_create`);
    return if ! $form || ! $nb; 
    return if $nb > 9;
    my $title = $form;
    $form =~ tr/ /_/;
    $form = "$dir{var}/form/$form";
    `form_tempo_create.pl $form "$title" $nb`; # creation d'un formulaire temporaire
    $var = `form.tk $form`;                    # execution pour la saisie du menu
    `form_menu_create.pl $form "$var"`;        # creation du menu final
    $var = `form_menu.tk $form`;               # test du menu
    file_select($form) }                       # affichage du fichier du menu

sub appli_create {
    my($appli) = (split/;/,`form.tk appli_create`);
    return if ! $appli;
    my $dir = "$env{facila}/$appli";
    my $exe = "$dir/prg/$appli";
    return if error('dir_exist',$dir);
    return if error('project_exist',"$dir{data}/init/$appli");
    `appli.sh $appli`;
    `project.sh create $appli "$dir" "$exe"`;
    project_select($appli);
    kreo_page_set('arch');
    info('entry',$msg{result_project_create});
    project_select($appli);
    project_exec();
    help('106') }

1;
