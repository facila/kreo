#!/usr/bin/perl -w

chdir $ENV{FACILA};
`chmod -R 755 kreo`;
`chmod -R 777 kreo/data`;

foreach (`share/prg/myls -f kreo | grep -v prg`) { `chmod 644 $_` }
foreach (`share/prg/myls -d kreo/data`         ) { `chmod 750 $_` }
foreach (`share/prg/myls -f kreo/data`         ) { `chmod 640 $_` }
