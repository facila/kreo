sub dir_select {
    my $dir = $_[0];
    return if error('dir_absent',$dir);
    $init{current_dir} = $dir;
    kreo_page_set('dir');
    histo($init{current_dir}) }

sub dir_open {
    kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if error('dir_absent',$dir);
    myopen('dir',$dir);
    histo($dir) }

sub dir_create {
    kreo_page_set('dir');
    my $dir = `form.tk entry_1 dir_create "$init{current_dir}"`;
    return if ! $dir;
    return if error('file_exist',$dir);
    return if error('dir_exist' ,$dir);
    return if shell_error("mkdir \"$dir\"");
    $init{current_dir} = $dir;
    kreo_page_set('dir') }

sub dir_change {
    kreo_page_set('dir');
    my $dir = `form.tk entry_1 dir_change "$init{current_dir}"`;
    return if ! $dir;
    return if error('dir_absent',$dir);
    return if shell_error("cd \"$dir\"");
    $init{current_dir} = $dir;
    kreo_page_set('dir') }

sub dir_stock {
    kreo_page_set('dir');
    my $stock = $appli{stock};
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if error('dir_absent',$dir);
    return if shell_error("cp -pR \"$dir\" \"$stock\"");
    $init{current_dir} = $stock;
    kreo_page_set('dir') }

sub dir_copy {
    kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if error('dir_absent',$dir);
    my $dir_new = `form.tk entry_2 dir_copy "$dir" "$dir"`;
    return if ! $dir_new;
    return if shell_error("cp -pR \"$dir\" \"$dir_new\"");
    $init{current_dir} = $dir_new;
    kreo_page_set('dir') }

sub dir_move {
    kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if error('dir_absent',$dir);
    my $dir_new = `dirname $dir`;
    chomp($dir_new = `dirname "$dir_new"`);
    $dir_new = `form.tk entry_2 dir_move "$dir" "$dir_new"`;
    return if ! $dir_new;
    return if shell_error("mv \"$dir\" \"$dir_new\"");
    $init{current_dir} = $dir_new;
    kreo_page_set('dir') }

sub dir_rename {
    kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if error('dir_absent',$dir);
    my $dir_new = `form.tk entry_2 dir_rename "$dir" "$dir"`;
    return if ! $dir_new;
    return if shell_error("mv \"$dir\" \"$dir_new\"");
    $init{current_dir} = $dir_new;
    kreo_page_set('dir') }

sub dir_delete {
    kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if error('dir_absent',$dir);
    return if ! `form.tk valid dir_delete "$dir"`;
    return if save('delete',$dir); # delete déplace le répertoire dans save/delete
    if ( $dir eq $init{current_dir} ) {
       chomp( $init{current_dir} = `dirname "$dir"` );
       $init{current_file} = '' }
    kreo_page_set('dir') }

1;
