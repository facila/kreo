# Kreo_tk.pm version 0.01 01/01/2021 par Thierry Le Gall
#
# fonctions permettant de créer et gérer une application en perl TK à partir de fichiers de configuration
#
# variables globales
# $dir{var} , $var{page} , $env{lang}
# %init , %var , %file , %widget , %page , %info , %menu , %button , %tk
#
##########################################################################################
# fichiers dans $dir{var}/tk utilisés dans kreo_main
# main_var
# main_frame
# main_balloon
#
# fonctions utilisées dans main_frame
# fichiers associés dans $dir{var}/tk
# kreo_menu
# kreo_button
# kreo_entry
# kreo_book
# kreo_variable
#
sub kreo_main {
    # création de main , main_frame et main_balloon
    chdir "$dir{var}/tk";

    use Tk;
    use Tk::NoteBook;
    use Tk::Balloon;
    use Tk::BrowseEntry;
    use Encode;

    # initialisation des variables
    my($file,$main,$frame,$fct,$msg);
    $file = 'main_var';
    open(F1,"<$var{mode}",$file);
    while(<F1>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($t,$v,$x) = split/;/;
       $v =~ tr/ //d;
       $$t{$v} = $x }
    close F1;

    $widget{main} = MainWindow->new;
    $main = $widget{main};
    $main->setPalette($tk{bg_main});
    $main->title     ($tk{title});
    $main->geometry  ($tk{geometry});
    $main->minsize   ($tk{min_w},$tk{min_h});
    $main->bind    ('all','<Key-F10>' ,sub{});
    $main->bind    ('all','<Alt-Key>' ,sub{});
    $main->bind    ('<Escape>'        ,sub{$fct=$tk{escape}; &$fct});
    $main->protocol('WM_DELETE_WINDOW',sub{$fct=$tk{exit}  ; &$fct});

    $file = 'main_frame';
    open(F1,"<$var{mode}",$file);
    while(<F1>) {
       next if /^#|^\s*$/; # lignes ignorées
       tr/ //d;
       chomp;
       my($w,$function,$name,$f,$e,$h) = split/;/;
       $frame = $main->$w;
       $widget{$name} = $frame;
       $frame->pack(-fill=>$f,-expand=>$e);
       if ( $h           ) { $frame->configure(-height=>$h) }
       if ( $w eq 'Text' ) { $frame->configure(-font=>$tk{font},-state=>'disabled') }
       else                { &$function($frame,$name) } }
    close F1;

    &kreo_cursor($tk{cursor});

    if ( -f 'main_balloon' ) {
       $balloon = $main->Balloon(-font=>$tk{font},-bg=>$tk{bg_text},-fg=>$tk{fg_text});
       $msg  = '';
       $file = 'main_balloon';
       open(FILE,"<$var{mode}",$file);
       while(<FILE>) {
          next if /^#|^\s*$/; # lignes ignorées
          chomp;
          my($b,$x,$f) = split/;/;
          if    ( $x == 1 ) { $msg  = "     $b : $f\n" }
          elsif ( $x == 2 ) { $msg .= " ALT $b : $f\n" }
          elsif ( $x == 3 ) { $msg .= "CTRL $b : $f"; $balloon->attach($button{$b},-msg=>$msg) } }
       close F1 }

    return $main }

sub kreo_menu {
    my($frame,$file) = @_;
    my($pere,$fils,$widget);
    my %pere;
    open(F2,"<$var{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($f,$w,$t,$c,$a) = split /;/;
       $f =~ tr/ //d;
       $w =~ tr/ //d if $w;
       $c =~ tr/ //d if $c;
       @a = (); @a = split/,/,$a if $a && $a ne '';

       if    ( $f eq 'menu'      ) { $fils = $widget = $frame->Menubutton(-text =>$t)->pack(-side=>'left',-fill=>'x') }
       elsif ( $f eq 'cascade'   ) { $fils = $widget = $pere->cascade    (-label=>$t) }
       elsif ( $f eq 'command'   ) {         $widget = $pere->command    (-label=>$t,-command=>[\&$c,@a]) }
       elsif ( $f eq 'checkbu'   ) {         $widget = $pere->checkbutton(-label=>$t,-variable=>\$$c,-selectcolor=>$tk{fg_select}) }
       elsif ( $f eq 'separator' ) {                   $pere->separator; next }

       if    ( $f eq 'menu'    ) { %pere = (); $pere = $fils }
       elsif ( $f eq 'cascade' ) { $pere{$fils} = $pere ; $pere = $fils }
       elsif ( $f eq 'fin'     ) { $pere = $pere{$pere}; next }

       $widget->configure(-font=>$tk{font},-foreground=>$tk{fg_main},-activeforeground=>$tk{bg_select},-activebackground=>$tk{fg_select});
       $menu{$w} = $widget if $w }
    close F2 }

sub kreo_button {
    my($frame,$file) = @_;
    open(F2,"<$var{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($b,$x,$c,$a) = split/;/;

       if   ($x==0) { $t = $c; $t = "$b\n$t" if $b =~ /^F\d+$/ }
       elsif($x==1) { $button{$b} = $frame->Button(-text=>$t);
                      $button{$b}->pack(-side=>'left',-fill=>'x',-expand=>1);
                      $button{$b}->configure(-font=>$tk{font},-foreground=>$tk{fg_main},-activeforeground=>$tk{bg_select},-activebackground=>$tk{fg_select}); 
	              &kreo_state('button',$b,'disabled') }
       elsif($x==4) { $$b = $frame->Label (-text=>''); # inutile de connaitre le wigdet , il n'est donc pas mis dans %button
                      $$b->pack(-side=>'left',-fill=>'x',-expand=>1) }

       if ( $c ) {
          &kreo_state('button',$b,'normal');
          @a = (); @a = split/,/,$a if $a;
          if   ($x==1) { $button{$b}->configure(-command=>[\&$c,@a]) if $c }
          elsif($x==2) { $button{$b}->bind("<ButtonRelease-2>",[\&kreo_bind,$c,@a]) }
          elsif($x==3) { $button{$b}->bind("<Button-3>"       ,[\&kreo_bind,$c,@a]) }

          # touches de fonction Fx
          if ( $b =~ /^F\d+$/ ) {
             if   ($x==1) { $widget{main}->bind("<$b>"        ,[\&kreo_bind,$c,@a]) }
             elsif($x==2) { $widget{main}->bind("<Alt-$b>"    ,[\&kreo_bind,$c,@a]) }
             elsif($x==3) { $widget{main}->bind("<Control-$b>",[\&kreo_bind,$c,@a]) } } } }
    close F2 }

sub kreo_entry {
    my($frame,$file) = @_;
    my $widget;

    $frame->configure(-bg=>$tk{bg_main});

    open(F2,"<$var{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($w,$t,$v,$i) = split/;/;
       if    ( $w eq 'check' ) { $bg = $tk{bg_main} ; $fg = $tk{fg_main} ; $widget = $frame->Checkbutton(-text=>"$t",-variable=>\$var{$v}) }
       elsif ( $w eq 'label' ) { $bg = $tk{bg_main} ; $fg = $tk{fg_main} ; $widget = $frame->Label(-text=>"$t") }
       elsif ( $w eq 'entry' ) { $bg = $tk{bg_entry}; $fg = $tk{fg_entry}; $widget = $frame->Entry(-width=>$i ) }

       $widget->pack(-side=>'left',-fill=>'both',-expand=>1);
       $widget->configure(-font=>$tk{font},-bg=>$bg,-fg=>$fg);

       if ( $w eq 'check' ) {
          $init{$v} = $var{$v} = $i;
          $widget->configure(-selectcolor=>$tk{fg_entry},-highlightcolor=>$tk{bg_main},-highlightthickness=>5);
          $widget->configure(-activeforeground=>$tk{fg_entry},-activebackground=>$tk{bg_main}) }
       elsif ( $w eq 'entry' ) {
          $widget{$t} = $widget;
          if ( $v ) { $widget->bind('<Return>',\&$v); $widget->bind('<KP_Enter>',\&$v) }
          $widget->configure(-insertbackground=>$tk{fg_entry}) } }
    close F2 }

sub kreo_book {
    my($book,$file) = @_;
    my($bg,$fg);

    $book->configure(-font=>$tk{font},-backpagecolor=>$tk{bg_main},-bg=>$tk{bg_main},-inactivebackground=>$tk{bg_book});

    open(F2,"<$var{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($page,$label,$info) = split /;/;
       $page =~ tr/ //d;
       $widget{"book_$page"} = $book->add($page,-label=>$label,-raisecmd=>[sub{&kreo_page($page)}]);

       next if $page eq 'form'; # page form réservée pour faire des formulaires

       # zones info et text associées à la page
       $bg = $tk{bg_text};
       $fg = $tk{fg_text};

       if ( $info ) {
          $info{$page} = $widget{"book_$page"}->Text(-height=>1)->pack(-fill=>'x');
          $info{$page}->configure(-state=>'disabled',-font=>$tk{font},-bg=>$bg,-fg=>$fg) }

       $page{$page} = $widget{"book_$page"}->Scrolled('Text',-scrollbars=>'osoe',-wrap=>'none')->pack(-fill=>'both',-expand=>1);
       $page{$page}->configure(-state=>'disabled',-font=>$tk{font},-bg=>$bg,-fg=>$fg);
       $page{$page}->configure(-insertbackground=>$tk{bg_text},-insertwidth=>3) }
    close F2 }

sub kreo_variable {
    my($file) = @_;
    my $widget = $widget{$file};
    my($nom,$lg,$var,$all);

    open(F2,"<$var{mode}","$dir{var}/tk/$file");
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       foreach (split/;/) {
          ($nom,$lg,$var) = split/,/;
	  $var =~ tr/ //d;
          $lg  = "%-".$lg."s";
          $all .= sprintf "$nom$lg" , $var{$var} }
       $all .= "\n" }
    close F2;
    chomp $all;

    &kreo_insert($widget,\$all,$tk{fg_text},$tk{bg_text}) }

##########################################################################################
# fonctions de création et de placement de widgets
# kreo_widget
#
sub kreo_widget {
    # widgets pour les formulaires
    if    ($_[0] eq "text"     ) { $_[1]->Label      (-text  =>$_[2]) }
    elsif ($_[0] eq "textvar"  ) { $_[1]->Label      (-textvariable=>$_[2]) }
    elsif ($_[0] eq "entry"    ) { $_[1]->Entry      (-width =>$_[2] , -textvariable=>$_[3]) }
    elsif ($_[0] eq "button"   ) { $_[1]->Button     (-text  =>$_[2] , -command =>$_[3]) }
    elsif ($_[0] eq "radio"    ) { $_[1]->Radiobutton(-text  =>$_[2] , -variable=>$_[3], -value=>$_[4], -command=>$_[5]) }
    elsif ($_[0] eq "check"    ) { $_[1]->Checkbutton(-text  =>$_[2] , -variable=>$_[3]) }
    elsif ($_[0] eq "check_com") { $_[1]->Checkbutton(-text  =>$_[2] , -variable=>$_[3], -command=>$_[4]) }
    elsif ($_[0] eq "list"     ) { $_[1]->Listbox    (-width =>$_[2] , -height  =>$_[3]) }
    elsif ($_[0] eq "browse"   ) { $_[1]->BrowseEntry(-width =>$_[2] , -variable=>$_[3], -choices=>$_[4], -state=>'readonly') }
    elsif ($_[0] eq "grid"     ) { $_[1]->grid       (-column=>$_[2] , -row     =>$_[3]) }
    elsif ($_[0] eq "place"    ) { $_[1]->place      (-relx  =>$_[2] , -rely    =>$_[3], -anchor=>'center') }
    elsif ($_[0] eq "pack"     ) { $_[1]->pack       (-side  =>'left', -fill    =>'x'  , -expand=>'yes') } }

##########################################################################################
# fonctions complèmentaires 
# kreo_shell
# kreo_page
# kreo_page_set
# kreo_page_clear
# kreo_page_text
# kreo_page_edit
# kreo_page_save
# kreo_insert
# kreo_bind
# kreo_cursor
# kreo_wait
# kreo_state
# kreo_tag_add
# kreo_tag_color
# kreo_tag_underline
# kreo_tag_underline_text
# kreo_tag_enter_leave

sub kreo_shell {
    my($ref_text,$command) = @_;
    chomp($$ref_text = `$command`);
    return if $env{lang} !~ /UTF-8/;
    $$ref_text = &decode('utf8',$$ref_text) }

sub kreo_page {
    # fonction kreo_page exécutée à l'activation de la page
    # - soit par la commande raisecmd de tk::notebook
    # - soit par la fonction kreo_page_set
    # - soit par la touche escape
    my($page) = @_;
    $var{page} = $page;
    my $fct = "page_$page";
    &$fct(1) } # 1 avec tag

sub kreo_page_set {
    # affichage d'une page
    my($page) = @_;
    if ( $var{page} ne $page ) { $widget{book}->raise($page) } # activation de la page + exécution de la fonction kreo_page
    else                       { &kreo_page($page) } }

sub kreo_page_clear {
    # effacement d'une page et de l'info
    my($page) = @_;
    my $text = '' ;
    &kreo_insert($widget{info},\$text,$tk{fg_file},$tk{bg_file}) if $widget{info};
    &kreo_insert($page{$page} ,\$text,$tk{fg_text},$tk{bg_text}) if $page{$page} }

sub kreo_page_text {
    # affichage de text et de info dans une page
    my($page,$ref_text,$ref_info) = @_;
    &kreo_insert($widget{info},$ref_info,$tk{fg_file},$tk{bg_file});
    &kreo_insert($page{$page} ,$ref_text,$tk{fg_text},$tk{bg_text}) }

sub kreo_page_edit {
    my($page) = @_;
    my $fct = "page_$page";
    &$fct(0); # sans tag
    $page{$page}->configure(-state=>'normal',-fg=>$tk{bg_text},-bg=>$tk{fg_text});
    $page{$page}->focus }

sub kreo_page_save {
    my($page,$file) = @_;
    my $text = $page{$page}->get('1.0','end');
    open(FILE,">$var{mode}",$file);
    print FILE "$text";
    close FILE;
    $page{$page}->configure(-state=>'disabled',-fg=>$tk{fg_text},-bg=>$tk{bg_text}) }

sub kreo_insert {
    my($widget,$ref_text,$fg,$bg) = @_;
    $widget->configure(-state=>'normal');
    $widget->delete('1.0','end');
    $widget->insert('end',$$ref_text);
    $widget->configure(-state=>'disabled');
    $widget->configure(-fg=>$fg,-bg=>$bg) }

sub kreo_bind {
    shift; my $c = shift; &$c(@_) }

sub kreo_cursor {
    my($cursor) = @_;
    foreach(keys %widget) { $widget{$_}->configure(-cursor=>$cursor) }
    foreach(keys %page  ) {   $page{$_}->configure(-cursor=>$cursor) } }

sub kreo_wait {
    &kreo_cursor($tk{cursor_wait});
    $widget{main}->idletasks;
    &kreo_cursor($tk{cursor}) }

sub kreo_state {
    my($tab,$widget,$state) = @_;
    if ( $$tab{$widget} ) {
       $$tab{$widget}->configure(-state=>$state) }
    else {
       foreach(keys %$tab) { $$tab{$_}->configure(-state=>$state) if /^$widget/ } } }

sub kreo_tag_add {
    my($widget,$tag,$x,$y,$fg,$bg) = @_;
    $widget->tagAdd ($tag,$x,$y);
    $widget->tagConfigure($tag,-foreground=>$fg,-background=>$bg);
    $widget->tagBind($tag,"<Enter>",[\&kreo_tag_enter_leave,$widget,$tag,$bg,$fg,$tk{cursor_select}]);
    $widget->tagBind($tag,"<Leave>",[\&kreo_tag_enter_leave,$widget,$tag,$fg,$bg,$tk{cursor}]) }

sub kreo_tag_color {
    my($widget,$tag,$x,$y,$fg,$bg) = @_;
    $widget->tagAdd ($tag,$x,$y);
    $widget->tagConfigure($tag,-foreground=>$fg,-background=>$bg) }

sub kreo_tag_enter_leave {
    shift;
    my($widget,$tag,$fg,$bg,$cursor) = @_;
    $widget->tagConfigure($tag,-foreground=>$fg,-background=>$bg);
    $widget->configure(-cursor=>$cursor) }

sub kreo_tag_underline {
    $_[1]->tagConfigure($_[2],-underline=>$_[3]) }

sub kreo_tag_underline_text {
    my($widget,$ref) = @_;
    my($ligne,$tag);
    foreach(`echo \"$$ref\"`) {
       $ligne ++;
       $tag = "line_$ligne" ;
       $widget->tagDelete ($tag) ;
       $widget->tagAdd    ($tag,"$ligne.0","$ligne.end");
       $widget->tagBind($tag,"<Enter>",sub{$widget->tagConfigure($tag,-underline=>1)});
       $widget->tagBind($tag,"<Leave>",sub{$widget->tagConfigure($tag,-underline=>0)}) } }

##########################################################################################
# fonctions texte et fichier
# kreo_file_code
# kreo_file_date
# kreo_file_line
# kreo_file_info

#sub kreo_utf8 {
#    return if $env{lang} !~ /UTF-8/;
#    my($ref_text)=@_;
#    $$ref_text = &decode('utf8',$$ref_text) }

sub kreo_file_code {
    my($file) = @_;
    return if ! -e $file;
    chomp(my $code=`file -b --mime-encoding $file`);
    return $code }

sub kreo_file_date {
    my($file) = @_;
    return if ! -e $file;
    return 1 if `date +%Y%m%d` eq `date +%Y%m%d -r $file` }

sub kreo_file_line {
    my($file) = @_;
    return if ! -e $file;
    open FILE,$file;
    my @file = <FILE>;
    close FILE;
    return @file }

sub kreo_file_info {
    my($file) = @_;
    return if ! -e $file;

    $var{file_ext}  = '';
    $var{file_ext}  = $1 if $file =~ /\.([^\.]*)$/;
    $var{file_code} = &kreo_file_code($file);
    my $wc='' ; $wc = &kreo_file_line($file) if $var{file_code} ne 'binary';
    my $ls='' ; &kreo_shell(\$ls,"ls -l $file");

    my $text = " $var{file_code}"; 
    $text .= " : $wc lignes" if $wc;
    $text .= " : $ls";
    return $text }

1;
