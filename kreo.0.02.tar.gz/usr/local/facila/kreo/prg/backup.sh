#!/bin/bash

 FACILA=/usr/local/facila
PROJECT=$1
   DATE=`date +%y%m%d_%H%M`
    TAR=$PROJECT.$DATE.tar.gz
    DIR=$FACILA/kreo/data/project
   FILE=`cat $DIR/$PROJECT | tr "\n" " "`
 BACKUP=$FACILA/backup

printf "$BACKUP/$TAR"

cd /
tar -czf $TAR $FILE 2> /dev/null
mv $TAR $BACKUP
chmod -R 600 $BACKUP

# lire le contenu      : cd / ; tar -tzf $BACKUP
# restaurer l'ensemble : cd / ; tar -xzf $BACKUP
