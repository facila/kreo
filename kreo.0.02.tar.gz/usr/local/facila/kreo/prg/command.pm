# commandes utilisées par les menus et les boutons

sub aide {
    $file{help} = "$dir{var}/help/$_[0]";
    &kreo_page_set('help') }

sub tester {
    my $dir = "$dir{facila}/$var{project}/prg";
    my $opt = $widget{entry_include}->get();
    system("$dir/$var{project} $opt&") }

sub sauvegarder {
    my $text = " $msg{project_save} $var{project} : ".`$dir{prg}/backup.sh $var{project}`;
    &kreo_insert($widget{info},\$text,$tk{fg_ok},$tk{bg_ok}) }

sub creer {
    my $text;
    my $project = $widget{entry_include}->get();
    my $info    = $widget{info};

    if ( ! $project ) {
       $text = " $msg{project_empty}";
       &kreo_insert($info,\$text,$tk{fg_ko},$tk{bg_ko});
       return }

    my $file = "$dir{data}/project/$project";
    if ( -f $file ) {
       $text = " $project : $msg{project_exist}";
       &kreo_insert($info,\$text,$tk{fg_ko},$tk{bg_ko});
       return }

    my $dir = "$dir{facila}/$project";
    if ( -d $dir ) {
       $text = "$dir : $msg{project_exist}";
       &kreo_insert($info,\$text,$tk{fg_ko},$tk{bg_ko});
       return }

    $var{project} = $project;
    $var{file} = $var{dir} = '';
    &kreo_variable('variable');

    `create_project.sh $dir{facila} $project`;
    &bind_list('bind',$project);
    $text = " $msg{project_create}";
    &kreo_insert($info,\$text,$tk{fg_entry},$tk{bg_entry}) }

sub editer_project {
    &kreo_page_set('project');
    &kreo_page_edit('project') }

sub enregistrer_project {
    my $file = "$dir{data}/project/$var{project}";
    &kreo_page_save('project',$file);
    &kreo_page_set('project') }

sub rechercher {
    $var{find} = $_[0];
    $var{find} = 'project' if $var{find} =~ /Tk::Entry=HASH/;
    &kreo_page_set('find') }

sub terminal {
    system("sudo $var{terminal} &") }

sub ouvrir {
    if ( $var{file_code} ne 'binary' || $var{file_ext} eq 'gz' ) {
       system("sudo $var{editeur} $var{file} &") }
    else {
       &kreo_insert($widget{info},\" $msg{find_file}",$tk{fg_ko},$tk{bg_ko}) } }

sub editer {
    my $page = 'file';
    my $file = $var{file};
    if ( $var{file_code} ne 'binary' ) {
       &kreo_page_set($page);
       &kreo_page_edit($page) }
    else {
       &kreo_insert($widget{info},\" $msg{find_file}",$tk{fg_ko},$tk{bg_ko}) } }

sub enregistrer {
    my $page = 'file';
    my $file = $var{file};
    if ( $var{file_code} ne 'binary' ) {
       &kreo_page_save($page,$file);
       &kreo_page_set($page) }
    else {
       &kreo_insert($widget{info},\" $msg{find_file}",$tk{fg_ko},$tk{bg_ko}) } }

sub error_file {
    my($opt,$file) = @_;
    return 0 if -f $file && $var{file_code} ne 'binary';
    &kreo_insert($widget{info},\" $msg{find_file}",$tk{fg_ko},$tk{bg_ko});
    return 1 }

1;
