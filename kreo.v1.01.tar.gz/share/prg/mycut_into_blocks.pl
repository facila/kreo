#!/usr/bin/perl -w

# mycut_into_blocks.pl version 1.00 Janvier 2023 par Thierry Le Gall
#
# rechercher les fichiers d'un dossier contenus dans un fichier
#
# syntaxe :
# mycut_into_blocks.pl FILE DIR EXCLUDE
# FILE    = fichier à analyser
# DIR     = dossier contenant les fichiers à rechercher
# EXCLUDE = chaine à exclure des fichiers

use strict;
require "$ENV{FACILA}/share/prg/mycut.pm";

my ($file,$dir,$exclude) = @ARGV;
my (%line,%source_dir,%file,%include);

&mycut_source_file($file,\%line);
&mycut_source_dir ($dir,$exclude,\%source_dir) ;
&mycut_into_blocks(\%line,\%source_dir,\%file,\%include) ;

foreach ( sort { $a cmp $b } keys %file    ) { print "f:$_\n" }
foreach ( sort { $a cmp $b } keys %include ) { print "i:$_\n" }
foreach ( sort { $a cmp $b } keys %line    ) { print "l:$_\n" }
