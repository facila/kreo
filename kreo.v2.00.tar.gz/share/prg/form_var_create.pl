#!/usr/bin/perl -w

# form_var_create.pl version 2.00 Septembre 2026 par Thierry Le Gall

($form,$title,$var) = @ARGV;
exit if ! $var;

foreach(split/;/,$var) {
   $i ++;
   $out   .= "v$i;";
   $text  .= "g;$i;1;text;$_;v$i\n";
   $entry .= "g;$i;2;entry;v$i;20;";
   $entry .= "f;" if $i == 1; 
   $entry .= "\n" }

$resu  = "# variables du formulaire\n\n";
$resu .= "form;title   ;$title;\n";
$resu .= "form;geometry;widthxheight+200+200;\n";
$resu .= "form;out     ;$out\n\n";

$resu .= "# widgets du formulaire\n\n";
$resu .= $text;
$i ++;
$resu .= "g;$i;1;text;\n\n";
$resu .= "$entry\n";
$i ++;
$resu .= "g;$i;1;button;Annuler;cancel;\n";
$resu .= "g;$i;2;button;Valider;valid;";

open(FILE,">",$form);
print FILE "$resu";
close FILE;
