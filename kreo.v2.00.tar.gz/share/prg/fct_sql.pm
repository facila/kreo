# fct_sql.pm version 2.00 Septembre 2026 par Thierry Le Gall

require "$ENV{FACILA}/share/prg/fct_utf8.pm";
use DBI;

# variables globales : %dbi
# $dbi{username} $dbi{password} $dbi{base} : à déclarer en dehors du module
# $dbi{dbh} : initialisée dans fct_sql_connect

# fonctions shell
sub fct_sql_count {
    my($table)=@_;
    my $mysql = "mysql -u $dbi{username} -p$dbi{password} $dbi{base}";
    my $query = "SELECT COUNT(1) FROM $table";
    chomp(my $total = `$mysql -Bse "$query" 2> /dev/null`);
    return $total }

# fonctions perl
sub fct_sql_connect    { $dbi{dbh} = DBI->connect("DBI:mysql:$dbi{base}",$dbi{username},$dbi{password}) }
sub fct_sql_disconnect { $dbi{dbh}->disconnect() }
sub fct_sql_exec       { my($query) = @_; fct_sql_connect(); $dbi{dbh}->do($query); fct_sql_disconnect() }

sub fct_sql_exist {
    fct_sql_connect();
    my($table,$var,$val) = @_;
    fct_utf8('encode',\$val);
    $sth = $dbi{dbh}->prepare("SELECT `$var` FROM $table WHERE `$var`='$val'");
    $sth->execute(); my @row = $sth->fetchrow_array(); $sth->finish();
    fct_sql_disconnect();
    return @row }

sub fct_sql_select {
    fct_sql_connect();
    my($table,$var,$val,$ref) = @_;
    fct_utf8('encode',\$val);
    $sth = $dbi{dbh}->prepare("SELECT * FROM $table WHERE `$var`='$val'");
    $sth->execute(); @$ref = $sth->fetchrow_array(); $sth->finish();
    fct_sql_disconnect() }

sub fct_sql_tables {
    # tableau des tables %$ref
    my($ref) = @_;
    my $sth = $dbi{dbh}->prepare("SHOW TABLES");
    $sth->execute();
    while ( my @row = $sth->fetchrow_array() ) { $$ref{$row[0]} = 1 }
    $sth->finish() }

sub fct_sql_columns {
    # tableau des colonnes d'une table @$ref
    my($table,$ref) = @_;
    my $sth = $dbi{dbh}->prepare("SHOW COLUMNS FROM $table");
    $sth->execute();
    while ( my @row = $sth->fetchrow_array() ) { push @$ref,$row[0] }
    $sth->finish() }

sub fct_sql_id {
    # tableau %$ref des id et des valeurs d'une table au format id,value
    my($table,$ref) = @_;
    my $sth = $dbi{dbh}->prepare("SELECT * FROM $table");
    $sth->execute();
    while ( my($id,$value) = ($sth->fetchrow_array())[0,1] ) {
       fct_utf8('decode',\$value); # utf8 pour les accents
       $$ref{$table}{$id} = $value }
    $sth->finish() }

sub fct_sql_sort {
    # 
    my($table,$field,$old,$new,$tmp) = @_;
    fct_sql_connect();
    $dbi{dbh}->do("UPDATE $table set $field='$tmp' WHERE $field='$old'");
    $dbi{dbh}->do("UPDATE $table set $field='$old' WHERE $field='$new'");
    $dbi{dbh}->do("UPDATE $table set $field='$new' WHERE $field='$tmp'");
    fct_sql_disconnect() }

1;
