#!/bin/bash

# version 2.00 Septembre 2026 par Thierry Le Gall
# script de création du répertoire data de kreo

mkdir data
mkdir data/archive
mkdir data/init
mkdir data/note

cp prg/appli_init data/appli
