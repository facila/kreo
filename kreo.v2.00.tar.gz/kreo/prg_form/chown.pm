$var{file} = $_[0]; 

sub reinit {
    $var{user}  = `stat --printf=%U $var{file}`;
    $var{group} = `stat --printf=%G $var{file}`;
    $var{in} = $var{out} = "$var{user}:$var{group}";
    $widget{4}->focus;
    $widget{4}->icursor('end') }

sub browse {
    my @list;
    if    ( $_[0] eq 'user'  ) { for(`sort /etc/passwd | cut -f1 -d:`) { chomp; push @list,$_ } }
    elsif ( $_[0] eq 'group' ) { for(`sort /etc/group  | cut -f1 -d:`) { chomp; push @list,$_ } }
    return \@list }

sub result {
    $var{out} = "$var{user}:$var{group}";
    print $var{out} if $var{out} ne $var{in};
    exit }

1;
