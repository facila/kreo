sub page_help {
    chomp(my $file = `ls -1 $dir{var}/help/$var{help}*`);
    return if &error('file_absent',$file);
    &kreo_help('help',$var{help});
    &kreo_file_all($file) }

sub page_project {
    my $dir = "$dir{data}/project";
    return if &error('dir_absent',$dir);
    my $page = $var{page};
    my @list;
    my $lg = 0;
    foreach(`ls -1 $dir`) { chomp; $lg = length($_) if length($_) > $lg; push @list,$_ }
    $lg .= 's';
    my $text = "\n";
    my $dsc;
    foreach(@list) {
       $dsc = `grep project_dsc $dir{data}/project/$_/init | cut -f2 -d';'`;
       $text .= sprintf " %-$lg : %-s" , $_ , $dsc }

    my $info = '';
    &kreo_page_text($page,\$text,\$info);
    &tag_project($page,\$text) }

sub page_arch {
    my $file = "$dir{project_data}/archive";
    return if &error('file_absent',$file);
    my $page  = $var{page};
    my ($tag) = @_;
    my $text;
    &kreo_shell(\$text,"cat $file");
    &kreo_page_text($page,\$text,\" $file");
    &tag_file($page,\$text) if $tag }

sub page_note {
    my $file = "$dir{project_data}/note";
    return if &error('note_absent',$file);
    my $page = $var{page};
    my $text;
    &kreo_shell(\$text,"cat $file");
    &kreo_page_text($page,\$text,\" $file") }

sub page_dir {
    my $dir = $init{current_dir};
    return if &error('dir_absent',$dir);
    my $page = $var{page};
    &kreo_variable('variable');
    &kreo_insert($widget{info},\" $dir",$fg{dir},$bg{dir});
    my $text = '';
    my $code = '';
       %code = ();
    &kreo_wait_start;
    &kreo_shell(\$text,"ls -al $dir");
    &kreo_shell(\$code,"file --mime-encoding $dir/*");
    &kreo_insert($page{$page},\$text,$fg{text},$bg{text});
    foreach(split/\n/,$code) { $code{$1} = $2 if /^(.*): *(.*)/ }
    &tag_dir($page,\$text);
    &kreo_wait_stop }

sub page_file {
    my $file = $init{current_file};
    return if &error('file_absent',$file);
    my $page = $var{page};
    &histo($file);
    &kreo_variable('variable');
    &kreo_file_all($file);

    my $text = '';
    if ( -s $file ) {
       if ( $var{file_code} ne 'binary'           ) { &kreo_shell(\$text,"cat $file") }
       if ( $var{file_ext}  =~ /($env{archive})$/ ) { &kreo_shell(\$text,"cat $dir{var}/help/*archive*") } }
    &kreo_insert($page{$page},\$text,$fg{text},$bg{text}) }

sub page_find {
    $init{entry_include} = $widget{entry_include}->get();
    $init{entry_exclude} = $widget{entry_exclude}->get();
    return if &error('entry');

    $var{find_opt}  = '-s';
    $var{find_opt} .= 'i' if $init{entry_case};
    `cp /dev/null $tmp{tmp}`;

    &kreo_wait_start;
    my $fct = "find_$var{find}";
    if ( &$fct                    ) { &kreo_wait_stop; return }
    if ( &error('find',$tmp{tmp}) ) { &kreo_wait_stop; return }

    my ($text,$info);
    $text = $info = '';
    `cp $tmp{tmp} $tmp{find}`; # $tmp{find} utilisé pour rechercher dans la page Rechercher

    if    ( $var{find} eq 'file'             ) { $var{find_tag} = 0 }
    elsif ( $var{find} =~ /dir|project|name/ ) { $var{find_tag} = 1 }

    &kreo_shell    (\$text,"cat $tmp{find}");
    &kreo_page_text('find',\$text,\$info);
    &tag_file      ('find',\$text) if $var{find_tag};

    $text = &kreo_file_line($tmp{find});
    $text = " $text lignes dans $var{find_info}";
    &kreo_insert($widget{info},\$text,$fg{result},$bg{result});
    &kreo_wait_stop }

sub page_histo {
    my $page = 'histo';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat $tmp{histo}");
    &kreo_page_text($page,\$text,\$info);
    &tag_file      ($page,\$text) }

sub page_debug {
    my $page = 'debug';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat $tmp{debug}");
    &kreo_page_text($page,\$text,\$info) }

sub page_var {
    &kreo_page_global('var') }

####################################################################
# fonctions find

# rechercher dans la page Rechercher
sub find_find {
    return 1 if &error('find_empty',$tmp{find});
    $var{find_file} = $tmp{find};
    $var{find_info} = $msg{result_find};
    &appli_grep }

# rechercher dans le fichier
sub find_file {
    return 1 if &error('file_absent',$init{current_file});
    $var{find_file} = $var{find_info} = $init{current_file};
    &appli_grep }

# rechercher dans le dossier
sub find_dir {
    return 1 if &error('dir_absent',$init{current_dir});
    $var{find_file} = $var{find_info} = $init{current_dir};
    chdir $var{find_file};
    $var{find_file} .= "/*";
    &appli_grep }

# rechercher dans le projet
sub find_project {
    return 1 if &error('project_absent',$init{project_dir});
    my $opt = $var{find_opt};
    $var{find_info} = $appli{project_name};
    my $text;
    &kreo_shell(\$text,"cat $dir{project_data}/archive");
    foreach(split/\n/,$text) {
       if ( -d $_ ) {
          $var{find_file} = "$_";
          chdir $_;
          &appli_grep }
       elsif ( -s $_ ) {
          $var{find_file} = $_ ;
          $var{find_opt} .= 'H';
          &appli_grep;
          $var{find_opt} = $opt } } }

# rechercher dans un fichier
sub find_name_file { &find_name('file') } 

# rechercher dans un dossier
sub find_name_dir { &find_name('dir') } 

sub find_name {
    return 1 if &error('project_absent',$init{project_dir});
    my $name = $_[0];
    my $fct = "my$name";
    my $text;
    `cp /dev/null $tmp{debug}`;
    $var{find_info} = $msg{"result_find_name_$name"};
    $var{find_file} = $tmp{debug} ;
    $var{find_opt}  = '-i' if $init{entry_case};
    foreach ( `cat $dir{data}/project/$appli{project_name}/archive` ) {
       chomp;
       $text = `$fct "$_" >> $tmp{debug}` }
    &appli_grep }

1;
