#!/bin/bash

# version 0.08 Septembre 2021 par Thierry Le Gall
# script de création d'un projet dans kreo

DATA=$1
PROJECT=$2
DIR=$3
EXE=$4
DSC=$5

   cd $DATA/project
mkdir $PROJECT
   cd $PROJECT
 echo $DIR > archive
 echo note > note
 
{ echo "current_dir;$DIR;"
  echo "current_file;$EXE;"
  cat $DATA/init 
  echo "project_dir;$DIR;"
  echo "project_exe;$EXE;"
  echo "project_dsc;$DSC;"
} > init

if [ "$DIR" != "" -a ! -d $DIR ]
then mkdir $DIR
     cd $DIR
     mkdir data prg var
fi

if [ "$EXE" != "" -a ! -f $EXE ]
then { echo "#!/bin/bash"
       echo
       echo "# ligne à remplacer par le fichier de démarrage de l'application"
       echo $PROJECT
     } > $EXE
     chmod +x $EXE
fi
