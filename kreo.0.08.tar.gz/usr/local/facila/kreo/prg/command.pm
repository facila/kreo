#!/usr/bin/perl -w

# commandes utilisées par les menus , les boutons et les tags

our %msg;

############### Aide ###############
sub help {
    my($nb) = @_;

    if ( ! $nb ) {
       # si nb est vide help est appelé par escape -> recherche du menu supérieur à afficher
       $nb = $var{help};
       foreach( sort { $b <=> $a } keys %help ) {
          if ( $nb >= $_ ) { $nb = $help{$_}; last } } }

    &kreo_help_bind('','help',$nb) }

############### Fonction ###############
sub form_create {
    my($form,$title,$nb) = (split/;/,`form.tk form_create`);
    return if ! $form || ! $title || ! $nb; 
    return if $nb > 9;
    $form =~ tr/ /_/;
    $form = "$dir{var}/form/$form";
    `form.pl $form "$title" $nb`;
    &file_select($form) }

sub appli_create {
    my($appli) = (split/;/,`form.tk appli_create`);
    return if ! $appli;
    my $dir = "$dir{facila}/$appli";
    my $exe = "$dir/prg/$appli";
    return if &error('dir_exist',$dir);
    return if &error('project_exist',"$dir{data}/project/$appli");
    `appli_create.sh $appli`;
    `project_create.sh $dir{data} $appli "$dir" "$exe"`;
    &project_select($appli);
    &kreo_page_set('arch');
    &info('entry',$msg{result_project_create});
    &project_select($appli);
    &project_exec;
    &help('105');
    }

#######################################
sub kreo_form_menu {
    my($widget,$file,$link) = @_;
    $widget->update;
    my($x,$y) = $widget->pointerxy();
    my $command = `form_menu.tk $file $x $y`;
    return if ! $command;
    &$command($link) }    

############### Rechercher ###############
sub find {
    $var{find} = $_[0];
    $var{find} = 'project' if $var{find} =~ /Tk::Entry=HASH/;
    &kreo_page_set('find') }

############### Projet ###############
sub project_exec {
    my $opt = $widget{entry_include}->get();
    system("$init{project_exe} $opt") }

sub project_right {
    return if ! $appli{project_name};
    my $file = "$dir{data}/project/$appli{project_name}/right";
    return if &error('file_absent',$file);
    system($file);
    &kreo_page($var{page});
    &kreo_insert($widget{info},\" $appli{project_name} : $msg{right}",$fg{result},$bg{result}) }

sub project_clear {
    foreach(keys %var) { $var{$_} = '' }
    &appli_reinit;
    &kreo_variable('variable');
    }

sub project_init {
    my $project = $_[0];
    $dir{project_data} = "$dir{data}/project/$project";
    &kreo_var_read('init',"$dir{project_data}/init");
    $widget{entry_include}->insert('end',$init{entry_include});
    $widget{entry_exclude}->insert('end',$init{entry_exclude});
    &kreo_variable('variable');
    my $page = 'arch';
    $page = 'dir' if $init{current_dir};
    &kreo_page_set($page) }

sub project_select {
    if ( $appli{project_name} ) {
       &kreo_var_write('init',"$dir{project_data}/init");
       &project_clear }
    $appli{project_name} = $_[0];
    &project_init($appli{project_name}) }

sub project_create {
    my ($project,$dir,$exe,$dsc) = (split/;/,`form.tk project_create`);
    return if ! $project;
    return if &error('project_exist',"$dir{data}/project/$project");
    `project_create.sh $dir{data} $project "$dir" "$exe" "$dsc"`;
    &project_select($project);
    &kreo_page_set('arch');
    &info('entry',$msg{result_project_create}) }

sub project_modify {
    my $project = $_[0];
    $project = $appli{project_name} if ! $project;
    return if ! $project;
    &project_select($project);
    my $form = `form.tk project_modify $project "$init{project_dir}" "$init{project_exe}" "$init{project_dsc}"`;
    return if ! $form;
    my ($dir,$exe,$dsc) = split/;/,$form;
    `project_modify.sh $dir{data} $project "$dir" "$exe" "$dsc"`;
    $init{project_dir} = $dir;
    $init{project_exe} = $exe;
    $init{project_dsc} = $dsc;
    &kreo_variable('variable') }

sub project_copy {
    my $project = $_[0];
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    my $project_new = `form.tk entry_2 project_copy $project ''`;
    return if ! $project_new;
    return if &error('project_exist',$project_new);
    `cd $dir{data}/project; cp -rp $project $project_new`;
    &project_select($project_new) }

sub project_rename {
    my $project = $_[0];
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    my $project_new = `form.tk entry_2 project_rename $project ''`;
    return if ! $project_new;
    return if &error('project_exist',$project_new);
    `cd $dir{data}/project; mv $project $project_new`;
    &project_select($project_new) }

sub project_delete {
    my $project = $_[0];
    $project = $appli{project_name} if ! $project;
    return if ! $project;
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    return if ! `form.tk valid project_delete $project`;
    `rm -rf $dir`;
    &project_clear if $project eq $appli{project_name};
    &kreo_page_set('project') }

############### Dossier ###############
sub dir_select {
    $init{current_dir} = $_[0];
    &kreo_page_set('dir');
    &histo($init{current_dir}) }

sub dir_open {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if &error('dir_absent',$dir);
    &open('dir',$dir);
    &histo($dir) }

sub dir_create {
    &kreo_page_set('dir');
    my $dir = `form.tk entry_1 dir_create $init{current_dir}`;
    return if ! $dir;
    return if &error('file_exist',$dir);
    return if &error('dir_exist' ,$dir);
    return if &shell_error("mkdir $dir");
    $init{current_dir} = $dir;
    &kreo_page_set('dir') }

sub dir_copy {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `form.tk entry_2 dir_copy $dir $dir`;
    return if ! $dir_new;
    return if &shell_error("cp -pR $dir $dir_new");
    $init{current_dir} = $dir_new;
    &kreo_page_set('dir') }

sub dir_move {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `dirname $dir`;
    chomp($dir_new = `dirname $dir_new`);
    $dir_new = `form.tk entry_2 dir_move $dir $dir_new`;
    return if ! $dir_new;
    return if &shell_error("mv $dir $dir_new");
    $init{current_dir} = $dir_new;
    &kreo_page_set('dir') }

sub dir_rename {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `form.tk entry_2 dir_rename $dir $dir`;
    return if ! $dir_new;
    return if &shell_error("mv $dir $dir_new");
    $init{current_dir} = $dir_new;
    &kreo_page_set('dir') }

sub dir_delete {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $init{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    return if ! `form.tk valid dir_delete $dir`;
    return if &shell_error("rmdir $dir");
    if ( $dir eq $init{current_dir} ) {
       chomp( $init{current_dir} = `dirname $dir` );
       $init{current_file} = '' }
    &kreo_page_set('dir') }

############### Fichier ###############
sub file_fct {
    my $page = $var{page};
    return 1 if $page !~ /file|arch|note/;

    my $file;
    if    ( $page eq 'file' ) { $file = $init{current_file}; return 1 if &error('file_binary',$file,$var{file_code}) }
    elsif ( $page eq 'note' ) { $file = "$dir{project_data}/note" } 
    elsif ( $page eq 'arch' ) { $file = "$dir{project_data}/archive" } 
    return 1 if &error('file_absent',$file);

    &kreo_page_set($page);
    my($fct) = @_;
    if    ( $fct eq 'edit'  ) { return if   $var{"edit_$page"}; $var{"edit_$page"} = 1; &kreo_page_edit($page) }
    elsif ( $fct eq 'save'  ) { return if ! $var{"edit_$page"}; $var{"edit_$page"} = 0; &kreo_page_save($page,$file); &kreo_page_set($page) }
    elsif ( $fct eq 'close' ) { return if ! $var{"edit_$page"}; $var{"edit_$page"} = 0;                               &kreo_page_set($page) } }

sub file_edit  { &file_fct('edit') }
sub file_save  { &file_fct('save') }
sub file_close { &file_fct('close') }

sub file_select {
    &kreo_page_set('file');
    return if &error('file_edit',$init{current_file});
    $init{current_file} = $_[0];
    &kreo_shell(\$init{current_dir},"dirname $init{current_file}");
    &kreo_page_set('file') }

sub file_open {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $ext  = &kreo_file_ext ($file);
    my $code = &kreo_file_code($file);
    return if &error('file_open',$file,$code,$ext);
    &open('file',$file);
    &histo($file) }

sub file_create {
    &kreo_page_set('dir');
    my $file = `form.tk entry_1 file_create $init{current_dir}`;
    return if ! $file;
    return if &error('file_exist',$file);
    return if &error('dir_exist' ,$file);
    return if &shell_error("echo ' ' > $file");
    $init{current_file} = $file;
    &kreo_page_set('dir') }

sub file_copy {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form.tk entry_2 file_copy $file $file`;
    return if ! $file_new;
    return if &shell_error("cp -p $file $file_new");
    $init{current_file} = $file_new;
    &kreo_page_set('file') }

sub file_move {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    chomp(my $dir_new = `dirname $file`);
    $dir_new = `form.tk entry_2 file_move $file $dir_new`;
    return if ! $dir_new;
    return if &shell_error("mv $file $dir_new");
    chomp($file = `basename $file`);
    $init{current_dir}  = $dir_new;
    $init{current_file} = "$dir_new/$file";
    &kreo_page_set('dir') }

sub file_rename {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form.tk entry_2 file_rename $file $file`;
    return if ! $file_new;
    return if &shell_error("mv $file $file_new");
    $init{current_file} = $file_new;
    &kreo_page_set('file') }

sub file_delete {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    return if ! `form.tk valid file_delete $file`;
    return if &shell_error("rm $file");
    $init{current_file} = '' if $file eq $init{current_file};
    &kreo_page_set('dir') }

sub file_verif {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    &shell_verif($file) }

sub file_change {
    my($fct,$file) = @_;
    my $var = `form.tk $fct $file`;
    return if ! $var;
    return if &shell_error("$fct $var $file");
    &kreo_page_set('dir') }

############### Archive ###############
sub archive_open {
    my $project = $_[0];
    $project = $appli{project_name} if ! $project;
    return if ! $project;
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    return if &error('file_absent',"$dir/archive");
    &open('file',"$dir/archive") }

sub archive_create {
    return if &error('project_absent',$init{project_dir});
    $init{current_dir}  = "$dir{facila}/archive";
    $init{current_file} = `$dir{prg}/archive_create.sh $appli{project_name} $dir{project_data} $init{current_dir}`;
    &kreo_page_set('file') }

sub archive_select {
    $init{current_dir}  = "$dir{facila}/archive";
    $init{current_file} = '';
    &kreo_page_set('dir') }

############### Terminal ###############
sub term_var  {
    my $var = `form.tk open "$appli{term}" "$appli{edit}"`;
    return if ! $var; 
    ( $appli{term} , $appli{edit} ) = split/;/,$var }

sub term_file { &file_select("$dir{share}/myopen") }

############### Quitter ###############
# Quitter utilise les commandes appli_ dans kreo_appli.pm

1;
