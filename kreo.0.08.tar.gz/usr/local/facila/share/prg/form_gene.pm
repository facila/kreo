# form_gene.pm version 0.08 Septembre 2021 par Thierry Le Gall

sub valid {
    if ( @out == 1 ) { print $var{$out[0]} if $var{$out[0]} }
    else { foreach(@out) { print "$var{$_}" if $var{$_}; print";" } }
    exit if $new }

sub cancel {
    exit if $new }

sub form_gene {
    if ( $_[0] && $_[0] eq 'new' ) { shift; $new = 1 }
    my $form = shift;
    exit if ! -f $form;

    require "$dir{share}/form_widget.pm";

    my $init;
    if ( -f "$dir{form}/$form.pm" ) {
       require "$dir{form}/$form.pm";
       $init = 1;
       &init(@_);
       @_ = () }

    open(FILE,"<$env{mode}",$form);
    while(<FILE>) { if ( /^form;(.*?);(.*);/ ) { $a = $1; $a =~ tr/ //d; $form{$a} = $2 } }
    close FILE;

    # cas avec une fonction dans le formulaire
    if ( $_[0] && $form{$_[0]} ) { $form{title} = $form{$_[0]}; shift }

    # @out : variables en sortie
    if ( $form{out} ) { @out = split/;/,$form{out} }

    my($p,$x,$y,$w,$v1,$v2,$v3,$v4);
    my($i,$l,$width,$height);
    my %width = ();
    my %w = ();
    my $ref_list;
    $i = $width = 0;

    open(FILE,"<$env{mode}",$form);
    while(<FILE>) {
       $i++;

       next if /^#|^\s*$/; # lignes ignorées
       next if /^form/;
       last if /^end/;

       chomp;
       ($p,$x,$y,$w,$v1,$v2,$v3,$v4) = split/;/;
       $w  =~ tr/ //d;
       $v1 =~ tr/ //d if $w !~ /text|check|browse/;

       # l longueur du champ
       if ($w =~ /entry/) {
          $l = $v2;
	  if ( $form{geometry} =~ /width/ ) {
             $l = length($_[0]) + 10 if $_[0];
             $l = $v2 if $v2 && $l < $v2 } }

       if ($w eq 'browse') {
          $v3 = $v1;
          $v3 =~ tr/ //d;
          $ref_list = &browse($v1) }

       if    ($w eq 'text'     ) { $w{$i} = &form_widget($w,$main,$v1) }
       elsif ($w eq 'textvar'  ) { $w{$i} = &form_widget($w,$main,\$var{$v1});    $var{$v1} = shift if $_[0] }
       elsif ($w eq 'entry'    ) { $w{$i} = &form_widget($w,$main,\$var{$v1},$l); $var{$v1} = shift if $_[0] }
       elsif ($w eq 'button'   ) { $w{$i} = &form_widget($w,$main,$v1,\&$v2) }
       elsif ($w eq 'browse'   ) { $w{$i} = &form_widget($w,$main,$v1,\$var{$v3},$ref_list,$v2) }
       elsif ($w eq 'list'     ) { $w{$i} = &form_widget($w,$main,$v1,$v2) }
       elsif ($w eq 'check'    ) { $w{$i} = &form_widget($w,$main,$v1,\$var{$v2}) }
       elsif ($w eq 'check_com') { $w{$i} = &form_widget($w,$main,$v1,\$var{$v2},\&$v3) }
       else  { next }

       if    ($p eq 'p') { $p = 'place'; $x = "0.$x"; $y = "0.$y" } # conversion de place qui est en pourcentage dans tk
       elsif ($p eq 'g') { $p = 'grid' }
       elsif ($p eq 'k') { $p = 'pack' }
       &form_widget($p,$w{$i},$x,$y);

       $w{$i}->configure(-font=>"$form{font} $form{size}");
       $w{$i}->configure(-fg=>$form{fg_text} ,-bg=>$form{bg_text});
       if    ($w eq 'entry') { $w{$i}->configure(-fg=>$form{fg_entry},-bg=>$form{bg_entry}) }
       elsif ($w =~ /check/) { $w{$i}->configure(-selectcolor=>$form{fg_entry}) }

       # longueur du formulaire
       if ($w =~ /text|entry/) {
          $width{$x} += $w{$i}->reqwidth;
	  $width      = $width{$x} if $width < $width{$x} }

       $w{$i}->focus          if $v3 && $w =~ /entry|button/;
       $w{$i}->icursor('end') if $v3 && $w eq 'entry' }
    close FILE;


    if ( $new ) {
       # longueur du formulaire
       if ( $width && $form{geometry} =~ /width/ ) {
          $width += $form{add_width};	
          $width  = $form{min_width} if $width < $form{min_width};
          $form{geometry} =~ s/width/$width/ }

       # hauteur du formulaire
       if ( $form{geometry} =~ /height/ ) {
          $height = 3 * $form{size} * $x;
          $form{geometry} =~ s/height/$height/ } }

    &reset if $init }

1;
