use strict;

sub source_file {
    my($file,$ref_source) = @_;
    foreach my $line (`cat $file`) {
       chomp $line;
       $$ref_source{$line} = 1 } }

# création du tableau contenant tout les fichiers à rechercher
# format %tab{nom_du_fichier}{ligne_du_fichier} = 1
sub list_dir {
    my($ref_list,$dir) = @_;
    chdir $dir;
    foreach(`grep . *`) {
       chomp;
       my($file,$line) = split/:/;
       $$ref_list{$file}{$line} = 1 } }

# recherche des fichiers de la liste contenus dans le fichier a analyser
sub find_file {
    my($ref_source,$ref_list,$ref_find) = @_; 
    my(%ko);
    my($ref,$file,$line);
    foreach $file (keys %$ref_list) {
       $ref = $$ref_list{$file};
       foreach $line (keys %$ref) {
          next if $ko{$file};
          $$ref_find{$file} = 1;
          if ( ! $$ref_source{$line} ) {
             $ko{$file} = 1;
             delete $$ref_find{$file} } } } }

# exclusion des fichiers inclus
sub result_file {
    my($ref_list,$ref_find,$ref_result) = @_; 
    my($file1,$file2,$ref1,$ref2,$line,$include);
    foreach $file1 (keys %$ref_find) {
       $$ref_result{$file1} = 1;
       foreach $file2 (keys %$ref_find) {
          next if $file1 eq $file2;
          $ref1 = $$ref_list{$file1};
          $ref2 = $$ref_list{$file2};
          foreach $line (keys %$ref1) {
             $include = 0;
             last if ! $$ref2{$line};
             $include = 1 }
          delete $$ref_result{$file1} if $include } } }

1;
