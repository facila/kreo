#!/usr/bin/perl -w

# file_dir.pl version 0.08 Septembre 2021 par Thierry Le Gall
# recherche dans $file des fichiers du répertoire $dir

require "/usr/local/facila/share/prg/file_dir.pm";

($file,$dir) = @ARGV;

# création de %source : tableau contenant les lignes du fichier à analyser
%source = ();
&source_file($file,\%source);

# création de %list : tableau de tout les fichiers à rechercher
%list = ();
&list_dir(\%list,$dir);

# recherche des fichiers
%find = ();
&find_file(\%source,\%list,\%find);

# exclusion des fichiers inclus
%result = ();
&result_file(\%list,\%find,\%result);

# %result : fichiers trouvés
foreach $f (keys %result) {
   print "f:$f\n";
   foreach $line (`cat $f`) {
      chomp $line;
      delete $source{$line} } }

# lignes non trouvées dans %source
foreach $line (keys %source) {
   print "l:$line\n" }
