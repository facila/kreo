# form_gene.pm version 1.00 Février 2023 par Thierry Le Gall

sub valid {
    my $out='';
    foreach(@out) { $out .= $var{$_} if defined $var{$_}; $out .= ';' if @out != 1 }
    if ( $out ) {
       $out = &encode('utf8',$out) if $env{lang} =~ /UTF-8/;
       print $out }
    exit if $new }

sub cancel {
    exit if $new }

sub form_gene {
    if ( $_[0] && $_[0] eq 'new' ) { shift; $new = 1 }
    my $form = shift;
    exit if ! -f $form;

    require "$dir{share}/prg/form_widget.pm";

    open(FILE,"<$env{mode}",$form);
    while(<FILE>) {
       if ( /^form;(.*?);(.*);/ ) {
          $a = $1; $a =~ tr/ //d;
          $b = $2; $b =~ s/\$(\w+)/$ENV{$1}/g; # pour remplacer des variables dans la chaine $b
          $form{$a} = $b } }
    close FILE;

    # cas avec une fonction dans le formulaire
    if ( $_[0] && $form{$_[0]} ) { $form{title} = $form{$_[0]}; shift }

    my $init;
    if ( $form{pm} && -f $form{pm} ) {
       require $form{pm};
       $init = 1;
       &init(@_);
       @_ = () }

    # @out : variables en sortie
    if ( $form{out} ) { @out = split/;/,$form{out} }

    my($p,$x,$y,$w,$v1,$v2,$v3,$v4);
    my($i,$l,$width,$height);
    my %width = ();
    my $ref_list;
    %widget = (); # tableau utilisation dans les fonctions du formaulaire
    $i = $width = 0;

    open(FILE,"<$env{mode}",$form);
    while(<FILE>) {
       next if /^#|^\s*$/; # lignes ignorées
       next if /^form/;
       last if /^end/;

       chomp;
       ($p,$x,$y,$w,$v1,$v2,$v3,$v4) = split/;/;
       $w  =~ tr/ //d;
       $v1 =~ tr/ //d if $w !~ /text|check|browse/;

       # $i numéro de widget du formulaire
       $i++ if $p =~ /^(p|g|k)$/;

       # l longueur du champ
       if ($w =~ /entry/) {
          $l = $v2;
          if ( $form{geometry} =~ /width/ ) {
             $l = length($_[0]) + 10 if $_[0];
             $l = $v2 if $v2 && $l < $v2 } }

       if ($w eq 'browse') {
          $v2 =~ tr/ //d;
          $ref_list = &browse($v2) }

       if    ($w eq 'text'     ) { $widget{$i} = &form_widget($w,$main,$v1) }
       elsif ($w eq 'textvar'  ) { $widget{$i} = &form_widget($w,$main,\$var{$v1});    $var{$v1} = shift if @_ }
       elsif ($w eq 'entry'    ) { $widget{$i} = &form_widget($w,$main,\$var{$v1},$l); $var{$v1} = shift if @_ }
       elsif ($w eq 'button'   ) { $widget{$i} = &form_widget($w,$main,$v1,\&$v2) }
       elsif ($w eq 'browse'   ) { $widget{$i} = &form_widget($w,$main,$v1,\$var{$v2},$ref_list,$v3) }
       elsif ($w eq 'list'     ) { $widget{$i} = &form_widget($w,$main,$v1,$v2) }
       elsif ($w eq 'check'    ) { $widget{$i} = &form_widget($w,$main,$v1,\$var{$v2}) }
       elsif ($w eq 'check_com') { $widget{$i} = &form_widget($w,$main,$v1,\$var{$v2},\&$v3) }
       else  { next }

       if    ($p eq 'p') { $p = 'place'; $x = "0.$x"; $y = "0.$y" } # conversion de place qui est en pourcentage dans tk
       elsif ($p eq 'g') { $p = 'grid' }
       elsif ($p eq 'k') { $p = 'pack' }
       &form_widget($p,$widget{$i},$x,$y);

       $widget{$i}->configure(-font=>"$form{font} $form{size}");
       $widget{$i}->configure(-fg=>$form{fg_text} ,-bg=>$form{bg_text});
       if    ($w eq 'entry' ) { $widget{$i}->configure(-fg=>$form{fg_entry},-bg=>$form{bg_entry}) }
       elsif ($w eq 'browse') { $widget{$i}->configure(-disabledbackground=>$form{bg_text},-disabledforeground=>$form{fg_text}) }
       elsif ($w =~ /check/ ) { $widget{$i}->configure(-selectcolor=>$form{fg_entry}) }

       # longueur du formulaire
       if ($w =~ /text|entry/) {
          $width{$x} += $widget{$i}->reqwidth;
	  $width      = $width{$x} if $width < $width{$x} }

       $widget{$i}->focus          if $v3 && $w =~ /entry|button/;
       $widget{$i}->icursor('end') if $v3 && $w eq 'entry' }
    close FILE;

    if ( $new ) {
       # longueur du formulaire
       if ( $width && $form{geometry} =~ /width/ ) {
          $width += $form{add_width};	
          $width  = $form{min_width} if $width < $form{min_width};
          $form{geometry} =~ s/width/$width/ }

       # hauteur du formulaire
       if ( $form{geometry} =~ /height/ ) {
          $height = 3 * $form{size} * $x;
          $form{geometry} =~ s/height/$height/ } }

    &reset if $init }

1;
