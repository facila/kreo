use strict;
 
# mycut.pm version 1.00 Janvier 2023 par Thierry Le Gall

# rechercher les fichiers d'un dossier contenus dans un tableau

# création d'un tableau contenant les lignes d'un fichier à analyser
# mycut_source_file
# - $file            = fichier à mettre dans le tableau
# - $ref_source_file = pointeur sur le tableau de lignes à analyser 
sub mycut_source_file {
    my($file,$ref_source_file) = @_;

    foreach (`cat $file`) {
       chomp;
       $$ref_source_file{$_} = 1 } }

# création d'un tableau contenant tous les fichiers à rechercher
# mycut_source_dir
# - $dir            = dossier contenant les fichiers à rechercher
# - $exclude        = chaine à exclure des fichiers
# - $ref_source_dir = pointeur sur le tableau des fichiers/lignes à rechercher 
sub mycut_source_dir {
    my($dir,$exclude,$ref_source_dir) = @_;
    my($file,$line);

    chdir $dir;
    foreach(`grep . *`) {
       chomp;
       ($file,$line) = split/:/;
       next if $exclude && $line =~ /$exclude/;
       $$ref_source_dir{$file}{$line} = 1 } }

# mycut_into_blocks
# - $ref_source_file    = pointeur sur le tableau des lignes à analyser 
# - $ref_source_dir     = pointeur sur le tableau des fichiers/lignes à rechercher
# - $ref_result_file    = pointeur sur le tableau du résultat des fichiers trouvés 
# - $ref_result_include = pointeur sur le tableau du résultat des fichiers inclus dans d'autres
# en sortie , le tableau $ref_source_file ne contient plus que les lignes non trouvées
sub mycut_into_blocks {
    my($ref_source_file,$ref_source_dir,$ref_result_file,$ref_result_include) = @_;
    my(%no_line);
    my($file,$line,$ref_source_dir_file);

    # recherche des fichiers
    foreach $file (keys %$ref_source_dir) {
       $ref_source_dir_file = $$ref_source_dir{$file};
       foreach $line (keys %$ref_source_dir_file) {
          last if $no_line{$file};
          $$ref_result_file{$file} = 1;
          if ( ! $$ref_source_file{$line} ) {
             $no_line{$file} = 1;
             delete $$ref_result_file{$file} } } }

    # recherche des fichiers inclus
    my($file1,$file2,$ref1,$ref2,$include);
    foreach $file1 (keys %$ref_result_file) {
       foreach $file2 (keys %$ref_result_file) {
          next if $file1 eq $file2;
          $ref1 = $$ref_source_dir{$file1};
          $ref2 = $$ref_source_dir{$file2};
          foreach $line (keys %$ref1) {
             $include = 0;
             last if ! $$ref2{$line};
             $include = 1 }
          $$ref_result_include{$file1} = 1 if $include } }
    foreach $file (keys %$ref_result_file) {
       delete $$ref_result_file{$file} if $$ref_result_include{$file} }

    # recherche des lignes non trouvées
    foreach $file (sort { $a cmp $b } keys %$ref_result_file) {
       foreach $line (`cat $file`) {
          chomp $line;
          delete $$ref_source_file{$line} } } }

1;
