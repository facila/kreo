sub tag_project {
    my ($page,$ref_text) = @_;
    my $line = 0;
    foreach(split/\n/,$$ref_text) {
       $line++;
       next if $line == 1;
      #if ( /^ ([^ ]+) / ) {
       if ( /^ (.*?) +:/ ) {
          my $link   = $1 ;
          my $y      = length($link)+1;
          my $tag    = $page."_$line";
          my $widget = $page{$page};
          &kreo_tag_add($widget,$tag,"$line.1","$line.$y",$fg{entry},$bg{entry});
          $widget->tagBind($tag,"<Button-1>",[\&kreo_bind,'project_select',$link]);
          $widget->tagBind($tag,"<Button-2>",[\&kreo_bind,'kreo_form_menu',$widget,"$dir{var}/form/menu_project",$link]) } } }

sub tag_file {
    my ($page,$ref_text) = @_;
    my $line = 0;
    foreach(split/\n/,$$ref_text) {
       chomp;
       $line++;
       $_ = $1 if /(.*?):/;
       my $link = $_;
       my $y = length($link);
       &tag_dir_file($link,$page{$page},$page."_$line","$line.0","$line.$y") } }

sub tag_dir {
    my ($page,$ref_text) = @_;
    my $dir = $init{current_dir};
    my ($file,$x,$y,$mod,$own,$group,$link,$begin,$all);
    our($fg,$bg);
    my $line = 0;

    foreach(split/\n/,$$ref_text) {
       chomp;
       $line++;

       if ( /^[bc]/ ) { ($mod,$own,$group,$link) = (split/\s+/,$_,10)[0,2,3,9] } # special = block ou caractere
       else           { ($mod,$own,$group,$link) = (split/\s+/,$_,9 )[0,2,3,8] }

       if ( $link ) {
          next if $link eq '.';
          next if $link eq '..' && $dir eq '/';
          $link = $1 if / -> (.*)/;

          if    (                  $dir eq '/'          ) { $file = "/$link" }
          elsif ( $link eq '..' && $dir =~ /^(.+)\/.*$/ ) { $file = $1 }
          elsif ( $link eq '..' && $dir =~ /^(\/).+$/   ) { $file = $1 }
          elsif ( $link =~ /^\//                        ) { $file = $link }
          else                                            { $file = "$dir/$link" }

	  $y = length($_);
	  $x = $y - length($link);
          &tag_dir_file($file,$page{$page},$page."_$line"."_file","$line.$x","$line.$y");
          next if $mod =~ /^[bcl]/;  

          $mod = substr($mod,1);
          $x = 1;
          $y = $x + length($mod);
          &tag_change('chmod',$file,$page{$page},$page."_$line"."_chmod","$line.$x","$line.$y");

          ($begin,$all) = /(.*)($own\s+$group)/;
          $x = length($begin);
          $y = $x + length($all);
          &tag_change('chown',$file,$page{$page},$page."_$line"."_chown","$line.$x","$line.$y") } } }

sub tag_change {
    # tag sur l'affichage des permissions , du propriètaire et du group. $fg et $bg déterminés dans tag_dir_file
    my($fct,$file,$widget,$tag,$x,$y) = @_;
    &kreo_tag_add($widget,$tag,$x,$y,$fg,$bg);
    $widget->tagBind($tag,"<Button-1>",[\&kreo_bind,'file_change',$fct,$file]) }

sub tag_dir_file {
    # tag sur l'affichage des noms de dossiers et des noms de fichiers. $fg et $bc utilisés ensuite dans tag_change
    my($file,$widget,$tag,$x,$y) = @_;

    if ( -d $file ) {
       $fg = $fg{dir} ; $bg = $bg{dir};
       &kreo_tag_add($widget,$tag,$x,$y,$fg,$bg);
       $widget->tagBind($tag,"<Button-1>",[\&kreo_bind,'dir_select',$file]);
       $widget->tagBind($tag,"<Button-2>",[\&kreo_bind,"kreo_form_menu",$widget,"$dir{var}/form/menu_dir",$file]) }
    elsif ( -f $file ) {
       my $code = $code{$file};
       my $menu = 'menu_file';
       $fg = $fg{file};
       $bg = $bg{file};
       if ( $file =~ /\.($env{archive})$/ ) {
          $fg = $fg{archive};
          $menu = 'menu_binary';
          $menu = 'menu_archive' if $file =~ /$dir{share}\/save\/archive/ }
       else {
          if ( ! $code           ) { $code = &kreo_file_code($file) }
          if ( $code eq 'binary' ) { $menu = 'menu_binary'; $fg = $fg{binary} } }
       &kreo_tag_add($widget,$tag,$x,$y,$fg,$bg);
       $widget->tagBind($tag,"<Button-1>",[\&kreo_bind,'file_select',$file]);
       $widget->tagBind($tag,"<Button-2>",[\&kreo_bind,'kreo_form_menu',$widget,"$dir{var}/form/$menu",$file]) }
    elsif ( -b $file || -c $file ) {
       $fg = $fg{special} ; $bg = $bg{special};
       &kreo_tag_color($widget,$tag,$x,$y,$fg,$bg) }
    else {
       $fg = $fg{error} ; $bg = $bg{error};
       &kreo_tag_color($widget,$tag,$x,$y,$fg,$bg) } }

1;
