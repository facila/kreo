#!/bin/bash

# création d'une version pour un projet de kreo dans facila avec des DATA par defaut ou vides
# - les DATA sont réinitialisés
# - la version est créée
# - les DATA sont remises à leurs valeurs initiales

cd $FACILA

   DATE=`date +%y%m%d_%H%M`
PROJECT=$1
   DATA=$PROJECT/data
   INIT=kreo/data_init/$PROJECT
    DIR=share/save/data/$PROJECT.$DATE
VERSION=share/save/version/$PROJECT.$DATE.tar.gz

     SRC=`kreo/prg/version.pl kreo/data/archive/$PROJECT`
 SRC_DIR=`echo $SRC | cut -f1 -d';'`
SRC_FILE=`echo $SRC | cut -f2 -d';'`

if [ -d $DATA ]                          # cas des projets avec des DATA
then mkdir $DIR                          # création du dossier de sauvegarde
     mv $DATA/* $DIR                     # sauvegarde du dossier $DATA
     [ -d $INIT ] && cp -r $INIT/* $DATA # copie du dossier d'installation dans $DATA
fi

tar -C $SRC_DIR $SRC_FILE -czf $VERSION  # creation de la version

[ -d $DATA  ] && cp -r $DIR/* $DATA      # retour au dossier initial de $DATA

printf $VERSION
