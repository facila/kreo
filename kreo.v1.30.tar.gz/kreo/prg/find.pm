sub find {
    $var{find} = $_[0];
    $var{find} = 'project' if $var{find} =~ /Tk::Entry=HASH/;
    &kreo_page_set('find') }

# rechercher dans la page Rechercher
sub find_find {
    return 1 if &error('find_empty',$tmp{find});
    $var{find_file} = $tmp{find};
    $var{find_info} = $msg{result_find};
    &appli_grep }

# rechercher dans le fichier
sub find_file {
    return 1 if &error('file_absent',$init{current_file});
    $var{find_file} = $var{find_info} = $init{current_file};
    &appli_grep }

# rechercher dans le dossier
sub find_dir {
    return 1 if &error('dir_absent',$init{current_dir});
    $var{find_file} = $var{find_info} = $init{current_dir};
    chdir $var{find_file};
    $var{find_file} .= "/*";
    &appli_grep }

# rechercher dans le projet
sub find_project {
    my $project = $appli{project_name};
    return 1 if &error('project_absent',"$dir{data}/init/$project");
    my $opt = $var{find_opt};
    $var{find_info} = $project;
    my $text;
    &fct_shell(\$text,"cat \"$dir{data}/archive/$project\"");
    foreach(split/\n/,$text) {
       if ( -d $_ ) {
          $var{find_file} = "$_";
          chdir $_;
          &appli_grep }
       elsif ( -s $_ ) {
          $var{find_file} = $_ ;
          $var{find_opt} .= 'H';
          &appli_grep;
          $var{find_opt} = $opt } } }

# rechercher dans un fichier
sub find_name_file { &find_name('file','-f') } 

# rechercher dans un dossier
sub find_name_dir { &find_name('dir','-d') } 

sub find_name {
    my $project = $appli{project_name};
    return 1 if &error('project_absent',"$dir{data}/init/$project");
    my ($name,$opt) = @_;
    my $text;
    `cp /dev/null $tmp{debug}`;
    $var{find_info} = $msg{"result_find_name_$name"};
    $var{find_file} = $tmp{debug} ;
    $var{find_opt}  = '-i' if $init{entry_case};
    foreach ( `cat $dir{data}/archive/$project` ) {
       chomp;
       $text = `myls $opt "$_" >> $tmp{debug}` }
    &appli_grep }

1;
