sub help {
    my($nb) = @_;
    if ( ! $nb ) {
       # si nb est vide help est appelé par escape -> recherche du menu supérieur à afficher
       $nb = $var{help};
       foreach( sort { $b <=> $a } keys %help ) {
          if ( $nb >= $_ ) { $nb = $help{$_}; last } } }
    &kreo_help_bind('','help',$nb) }

sub parameter  {
    my $var;
    &fct_shell(\$var,"form.tk parameter \"$appli{term}\" \"$appli{edit}\" \"$appli{save}\" \"$appli{stock}\"");
    return if ! $var; 
    ( $appli{term} , $appli{edit} , $appli{save} , $appli{stock} ) = split/;/,$var }

sub parameter_term { &file_select("$dir{share}/prg/myopen") }

sub histo {
    my ($file) = @_;
    `( echo "$file" ; grep -vx "$file" $tmp{histo} ) > $tmp{tmp}; cp $tmp{tmp} $tmp{histo}` }

sub info {
    my ($info,$msg) = @_;
    &kreo_insert($widget{info},\" $msg",$fg{$info},$bg{$info}) }

sub open {
    my ($type,$file) = @_;
    my $term = $appli{term};
    my $edit = $appli{edit};
    return &info('error',"$term $msg{error_term} $dir{var}/appli/init") if ! `which "$term"`;
    if    ( $type eq 'file' ) { return &info('error',"$edit $msg{error_edit} $dir{var}/appli/init") if ! `which "$edit"` }
    elsif ( $type eq 'dir'  ) { $edit = '' }
    system("$dir{share}/prg/myopen \"$file\" \"$term\" \"$edit\"") }

sub shell_verif {
    my $shell = "myverif $_[0]";
    my $msg  = '';
    &fct_shell(\$msg,"($shell) 2>&1");
    return if ! $msg;
    my $info = 'error';
    $info = 'result' if $msg =~ /OK/;
    `cp /dev/null $tmp{debug} 2>/dev/null`;
    print DEBUG "shell command : $shell\n";
    print DEBUG "$msg\n\n";
    &kreo_page_set('debug');
    &info($info,$msg);
    return 1 }

sub shell_error {
    my $shell = $_[0];
    my $msg   = '';
    &fct_shell(\$msg,"($shell) 2>&1");
    return if ! $msg;
    `cp /dev/null $tmp{debug} 2>/dev/null`;
    print DEBUG "shell command : $shell\n";
    print DEBUG "$msg\n\n";
    &kreo_page_set('debug');
    &info('error',$msg);
    return 1 }

sub error {
    my ($msg,$file,$code,$ext) = @_;

    if    ( $msg =~ /absent/ && ! $file ) { } # error

    elsif ( $msg eq 'note_absent'    ) { return if   -f $file }
    elsif ( $msg eq 'find_empty'     ) { return if   -s $file }
    elsif ( $msg eq 'find'           ) { return if   -s $file }

    elsif ( $msg eq 'project_extract') { return if $file ne $env{appli} }
    elsif ( $msg eq 'project_exist'  ) { return if ! -f $file }
    elsif ( $msg eq 'project_absent' ) { return if   -f $file }

    elsif ( $msg eq 'dir_exist'      ) { return if ! -d $file }
    elsif ( $msg eq 'dir_absent'     ) { if ( -d $file ) { $msg = 'dir_right'; `cd "$file"`; return if ! $? } } # 2 errors testées : dir_absent et dir_right

    elsif ( $msg eq 'file_exist'     ) { return if ! -f $file }
    elsif ( $msg eq 'file_absent'    ) { if ( -f $file ) { $msg = 'file_right'; `cat "$file"`; return if ! $? } } # 2 errors testées : file_absent et file_right
    elsif ( $msg eq 'file_binary'    ) { return if $code ne 'binary' }
    elsif ( $msg eq 'file_open'      ) { return if $code ne 'binary' || ( $ext && $ext !~ /.($env{archive})$/ ) }

    elsif ( $msg eq 'file_edit'      ) { return if ! $var{edit_file} }
    elsif ( $msg eq 'arch_edit'      ) { return if ! $var{edit_arch} }
    elsif ( $msg eq 'note_edit'      ) { return if ! $var{edit_note} }

    elsif ( $msg eq 'entry'          ) { return if $init{entry_include} || $init{entry_exclude} }

    if ( $msg eq 'file_open' ) { $msg = 'file_binary' }

    my $error = $msg{"error_$msg"}; 
    if    ( $msg eq 'find'  ) { $error .= " : $init{entry_include} - $init{entry_exclude}" }
    elsif ( $msg !~ /entry/ ) { $error  = "$error : $file" }
    &info('error',$error);
    return 1 }

1;
