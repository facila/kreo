# kreo.pm version 1.30 Janvier 2025 par Thierry Le Gall
#
# fonctions permettant de créer et gérer une application en perl TK à partir de fichiers de configuration
#
# variables globales
# $dir{share} , $dir{var} , $var{page} , $env{lang} , $env{mode}
# %msg , %appli , %init , %var , %file , %widget , %page , %info , %menu , %button , %tk
#
##########################################################################################
# fichiers dans $dir{var}/appli utilisés dans kreo_main
# main_frame
# main_balloon
#
# fonctions utilisées dans main_frame
# fichiers associés dans $dir{var}/appli
# kreo_menu
# kreo_button
# kreo_entry
# kreo_book
# kreo_variable

require "$dir{share}/prg/fct_var.pm";
require "$dir{share}/prg/fct_file.pm";
require "$dir{share}/prg/fct_utf8.pm";

our %msg;
our %init;
our %menu;

sub kreo_main {
    # création de main , main_frame et main_balloon
    use Tk;
    use Tk::NoteBook;
    use Tk::Balloon;
  # use Tk::BrowseEntry;

    my($file,$main,$frame,$fct,$msg);
    $widget{main} = MainWindow->new;
    $main = $widget{main};
    $main->setPalette($bg{main});
    $main->title     ($tk{title});
    $main->geometry  ($tk{geometry});
    $main->minsize   ($tk{min_width},$tk{min_height});
    $main->bind    ('all','<Key-F10>' ,sub{});
    $main->bind    ('all','<Alt-Key>' ,sub{});
    $main->bind    ('<Escape>'        ,sub{$fct=$tk{escape}; &$fct});
    $main->protocol('WM_DELETE_WINDOW',sub{$fct=$tk{exit}  ; &$fct});

    chdir "$dir{var}/appli";
    $file = 'main_frame';
    open(F1,"<$env{mode}",$file);
    while(<F1>) {
       next if /^#|^\s*$/; # lignes ignorées
       tr/ //d;
       chomp;
       my($w,$fct,$name,$f,$e,$h) = split/;/;
       $frame = $main->$w;
       $widget{$name} = $frame;
       $frame->pack(-fill=>$f,-expand=>$e);
       if ( $h           ) { $frame->configure(-height=>$h) }
       if ( $w eq 'Text' ) { $frame->configure(-font=>$tk{font},-state=>'disabled') }
       else                { &$fct($frame,$name) } }
    close F1;

    &kreo_cursor($tk{cursor});

    $widget{balloon} = $main->Balloon(-font=>$tk{font},-fg=>$fg{text},-bg=>$bg{text});
    if ( -f 'main_balloon' ) {
       $msg  = '';
       $file = 'main_balloon';
       open(FILE,"<$env{mode}",$file);
       while(<FILE>) {
          next if /^#|^\s*$/; # lignes ignorées
          chomp;
          my($b,$x,$f) = split/;/;
          if    ( $x == 1 ) { $msg  = "     $b : $f\n" }
          elsif ( $x == 2 ) { $msg .= " ALT $b : $f\n" }
          elsif ( $x == 3 ) { $msg .= "CTRL $b : $f"; $widget{balloon}->attach($button{$b},-msg=>$msg) } }
       close F1 }

    return $main }

sub kreo_menu {
    my($frame,$file) = @_;
    my($pere,$fils,$widget);
    my %pere;
    open(F2,"<$env{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($f,$w,$t,$c,$a) = split /;/;
       $f =~ tr/ //d;
       $w =~ tr/ //d if $w;
       $c =~ tr/ //d if $c;
       @a = (); @a = split/,/,$a if $a && $a ne '';

       if    ( $f eq 'menu'      ) { $fils = $widget = $frame->Menubutton(-text =>$t)->pack(-side=>'left',-fill=>'x') }
       elsif ( $f eq 'cascade'   ) { $fils = $widget = $pere->cascade    (-label=>$t) }
       elsif ( $f eq 'command'   ) {         $widget = $pere->command    (-label=>$t,-command=>[\&$c,@a]) }
       elsif ( $f eq 'checkbu'   ) {         $widget = $pere->checkbutton(-label=>$t,-variable=>\$$c{$a},-selectcolor=>$fg{select}) }
       elsif ( $f eq 'separator' ) {                   $pere->separator; next }

       if    ( $f eq 'menu'    ) { %pere = (); $pere = $fils }
       elsif ( $f eq 'cascade' ) { $pere{$fils} = $pere ; $pere = $fils }
       elsif ( $f eq 'end'     ) { $pere = $pere{$pere}; next }

       $widget->configure(-font=>$tk{font},-foreground=>$fg{main},-activeforeground=>$bg{select},-activebackground=>$fg{select});
       $menu{$w} = $widget if $w }
    close F2 }

sub kreo_form_menu {
    my($widget,$form,$variable) = @_;
    $widget->update;
    my($x,$y) = $widget->pointerxy();
    my $command = `form_menu.tk $form $x $y`;
    return if ! $command;
    ($command,$variable) = ($1,$2) if $command =~ /(.*?) (.*)/;
    &$command($variable) }

sub kreo_button {
    my($frame,$file) = @_;
    open(F2,"<$env{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($b,$x,$c,$a) = split/;/;

       if   ($x==0) { $t = $c; $t = "$b\n$t" if $b =~ /^F\d+$/ }
       elsif($x==1) { $button{$b} = $frame->Button(-text=>$t);
                      $button{$b}->pack(-side=>'left',-fill=>'x',-expand=>1);
                      $button{$b}->configure(-font=>$tk{font},-foreground=>$fg{main},-activeforeground=>$bg{select},-activebackground=>$fg{select}); 
                      &kreo_state('button',$b,'disabled') }
       elsif($x==4) { $$b = $frame->Label (-text=>''); # inutile de connaitre le wigdet , il n'est donc pas mis dans %button
                      $$b->pack(-side=>'left',-fill=>'x',-expand=>1) }

       if ( $c ) {
          &kreo_state('button',$b,'normal');
          @a = (); @a = split/,/,$a if $a;
          if   ($x==1) { $button{$b}->configure(-command=>[\&$c,@a]) if $c }
          elsif($x==2) { $button{$b}->bind("<Button-2>",[\&kreo_bind,$c,@a]) }
          elsif($x==3) { $button{$b}->bind("<Button-3>",[\&kreo_bind,$c,@a]) }

          # touches de fonction Fx
          if ( $b =~ /^F\d+$/ ) {
             if   ($x==1) { $widget{main}->bind("<$b>"        ,[\&kreo_bind,$c,@a]) }
             elsif($x==2) { $widget{main}->bind("<Alt-$b>"    ,[\&kreo_bind,$c,@a]) }
             elsif($x==3) { $widget{main}->bind("<Control-$b>",[\&kreo_bind,$c,@a]) } } } }
    close F2 }

sub kreo_entry {
    my($frame,$file) = @_;
    my $widget;

    $frame->configure(-bg=>$bg{main});

    open(F2,"<$env{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($w,$t,$c,$v) = split/;/;
       if    ( $w eq 'check' ) { $fg = $fg{main} ; $bg = $bg{main} ; $widget = $frame->Checkbutton(-text=>"$t",-variable=>\$$c{$v}) }
       elsif ( $w eq 'label' ) { $fg = $fg{main} ; $bg = $bg{main} ; $widget = $frame->Label(-text=>"$t") }
       elsif ( $w eq 'entry' ) { $fg = $fg{entry}; $bg = $bg{entry}; $widget = $frame->Entry(-width=>$v ) }

       $widget->pack(-side=>'left',-fill=>'both',-expand=>1);
       $widget->configure(-font=>$tk{font},-fg=>$fg,-bg=>$bg);

       if ( $w eq 'check' ) {
          $widget->configure(-selectcolor=>$fg{entry},-highlightcolor=>$bg{main},-highlightthickness=>5);
          $widget->configure(-activeforeground=>$fg{entry},-activebackground=>$bg{main}) }
       elsif ( $w eq 'entry' ) {
          $widget{$t} = $widget;
          if ( $c ) { $widget->bind('<Return>',\&$c); $widget->bind('<KP_Enter>',\&$c) }
          $widget->configure(-insertbackground=>$fg{entry}) } }
    close F2 }

sub kreo_book {
    my($book,$file) = @_;
    my($bg,$fg);

    $book->configure(-font=>$tk{font},-backpagecolor=>$bg{main},-bg=>$bg{main},-inactivebackground=>$bg{book});

    open(F2,"<$env{mode}",$file);
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       my($page,$label,$info,$state) = split /;/;
       $page =~ tr/ //d;
       $widget{"book_$page"} = $book->add($page,-label=>$label,-raisecmd=>[sub{&kreo_page($page)}]);

       next if $page eq 'form'; # page form réservée pour faire des formulaires

       # zones info et text associées à la page
       $bg = $bg{text};
       $fg = $fg{text};

       if ( $info ) {
          $info{$page} = $widget{"book_$page"}->Text(-height=>1)->pack(-fill=>'x');
          $info{$page}->configure(-state=>'disabled',-font=>$tk{font},-fg=>$fg,-bg=>$bg) }

       if ( $state ) { $state = 'normal'; $bg = $fg{text}; $fg = $bg{text} }
       else          { $state = 'disabled' }
       $page{$page} = $widget{"book_$page"}->Scrolled('Text',-scrollbars=>$tk{scroll},-wrap=>'none')->pack(-fill=>'both',-expand=>1);
       $page{$page}->configure(-state=>$state,-font=>$tk{font},-fg=>$fg,-bg=>$bg);
       $page{$page}->configure(-insertbackground=>$bg{text},-insertwidth=>3) }
    close F2 }

sub kreo_variable {
    my($file) = @_;
    my $widget = $widget{$file};
    my($nom,$lg,$name,$var,$all);
    open(F2,"<$env{mode}","$dir{var}/appli/$file");
    while(<F2>) {
       next if /^#|^\s*$/; # lignes ignorées
       chomp;
       foreach (split/;/) {
          ($nom,$lg,$name,$var) = split/,/;
          $name =~ tr/ //d;
          $var  =~ tr/ //d;
          $lg   = "%-".$lg."s";
          $all .= sprintf "$nom$lg" , $$name{$var} }
       $all .= "\n" }
    close F2;
    chomp $all;

    &kreo_insert($widget,\$all,$fg{text},$bg{text}) }

sub kreo_help_bind {
    shift;
    my($page,$nb) = @_;
    $var{help} = $nb;
    &kreo_page_set($page) }

sub kreo_help {
    my($page,$nb) = @_;
    my($file,$text,$menu);
    my $widget = $page{$page};

    $file = $nb."_*";
    chomp($file = `cd $dir{var}/help; ls -1 $file`);
    &fct_shell(\$text,"cat \"$dir{var}/help/$file\"");
    &kreo_insert($widget,\$text,$fg{text},$bg{text});

    $menu = (split/_/,$file)[1];
    return if ! $menu;

    my($line,$tag);
    $line = 0;
    foreach(split/\n/,$text) {
       $line++;
       next if /^$/;
       $tag = $page."_".$menu;
       &kreo_tag_add($widget,$tag,"$line.1","$line.end",$fg{entry},$bg{text});
       $widget->tagBind($tag,"<Button-1>",[\&kreo_help_bind,$page,$menu]);
       $menu++ } }

##########################################################################################
# fonctions complèmentaires 
# kreo_page
# kreo_page_set
# kreo_page_clear
# kreo_page_text
# kreo_page_global
# kreo_page_edit
# kreo_page_save
# kreo_insert
# kreo_insert_info
# kreo_bind
# kreo_cursor
# kreo_wait_start
# kreo_wait_stop
# kreo_state
# kreo_tag_add
# kreo_tag_enter
# kreo_tag_leave
# kreo_tag_color
# kreo_tag_underline
# kreo_tag_button
# kreo_tag_column
# kreo_tag_string

sub kreo_page {
    # fonction kreo_page exécutée à l'activation de la page
    # - soit par la commande raisecmd de tk::notebook
    # - soit par la fonction kreo_page_set
    # - soit par la touche escape
    my($page) = @_;
    $var{page_old} = $var{page};
    $var{page}     = $page;
    return if $var{"edit_$page"};
    my $fct = "page_$page";
    &$fct(1) } # 1 avec tag

sub kreo_page_set {
    # affichage et reinitialisation d'une page
    my($page) = @_;
    if ( ! $var{page} || $var{page} ne $page ) {
       $widget{book}->raise($page) } # activation de la page + exécution de la fonction kreo_page
    else { &kreo_page($page) } }

sub kreo_page_clear {
    # effacement d'une page et de l'info
    my($page,$state) = @_;
    my $text = '' ;
    my $fg = $fg{text};
    my $bg = $bg{text};
    $state = 'disabled' if ! $state;
    if ( $state eq 'normal' ) { $fg = $bg{text}; $bg = $fg{text} }
    &kreo_insert($widget{info},\$text,$fg{file},$bg{file}) if $widget{info};
    &kreo_insert($page{$page} ,\$text,$fg,$bg,$state)      if $page{$page} }

sub kreo_page_text {
    # affichage de text et de info dans une page
    my($page,$ref_text,$ref_info) = @_;
    &kreo_insert($widget{info},$ref_info,$fg{file},$bg{file});
    &kreo_insert($page{$page} ,$ref_text,$fg{text},$bg{text}) }

sub kreo_page_global {
    # affichage des variables globales dans une page
    my($page) = @_;
    my($text,$info,$ref) = '';
    foreach (sort{$a <=> $b} keys %global ) {
       $ref = $global{$_};
       $text  .= "\n $msg{variables} %$ref\n\n";
       foreach (sort{$a cmp $b} keys %$ref) {
          $text .= sprintf "   %-25s %-s\n" , $_ , $$ref{$_} } }
    &kreo_page_text($page,\$text,\$info) }

sub kreo_page_edit {
    my($page) = @_;
    my $fct = "page_$page";
    &$fct(0); # sans tag
    $page{$page}->configure(-state=>'normal',-fg=>$bg{text},-bg=>$fg{text}); # invers video
    $page{$page}->focus }

sub kreo_page_save {
    my($page,$file) = @_;
    my $text = $page{$page}->get('1.0','end');
    open(FILE,">$env{mode}",$file);
    print FILE "$text";
    close FILE;
    $page{$page}->configure(-state=>'disabled',-fg=>$fg{text},-bg=>$bg{text}) }

sub kreo_insert {
    my($widget,$ref_text,$fg,$bg,$state) = @_;
    $state = 'disabled' if ! $state;
    $widget->configure(-state=>'normal');
    $widget->delete('1.0','end');
    $widget->insert('end',$$ref_text);
    $widget->configure(-fg=>$fg,-bg=>$bg);
    $widget->configure(-state=>$state) }

sub kreo_insert_info {
    my($file) = @_;
    return if ! -e $file;
    $var{file_ext}  = &fct_file_ext ($file);
    $var{file_code} = &fct_file_code($file);
    my $text        = &fct_file_info($file);
    my $date        = &fct_file_date($file);
    my $fg = $fg{file};
    my $bg = $bg{file};
    if    ( $var{file_ext}  =~ /($env{archive})$/ ) { $fg = $fg{archive} }
    elsif ( $var{file_code} eq 'binary'           ) { $fg = $fg{binary}  }
    if ( $date ) { ($fg,$bg) = ($bg,$fg) } # invers video si date = jour
    &kreo_insert($widget{info},\$text,$fg,$bg) }

sub kreo_bind {
    shift;
    my $fct = shift;
    &$fct(@_) }

sub kreo_cursor {
    my($cursor) = @_;
    foreach(keys %widget) { $widget{$_}->configure(-cursor=>$cursor) }
    foreach(keys %page  ) {   $page{$_}->configure(-cursor=>$cursor) } }

sub kreo_wait_start {
    &kreo_cursor($tk{cursor_wait});
    $widget{main}->idletasks }

sub kreo_wait_stop {
    &kreo_cursor($tk{cursor}) }

sub kreo_state {
    my($name,$widget,$state) = @_;
    if ( $$name{$widget} ) {
       $$name{$widget}->configure(-state=>$state) }
    else {
       foreach(keys %$name) { $$name{$_}->configure(-state=>$state) if /^$widget/ } } }

sub kreo_tag_add {
    my($widget,$tag,$x,$y,$fg,$bg,$fct_balloon,$var) = @_;
    $widget->tagDelete($tag);
    $widget->tagAdd($tag,$x,$y);
    $widget->tagConfigure($tag,-foreground=>$fg,-background=>$bg);
    $widget->tagBind($tag,"<Enter>",[\&kreo_tag_enter,$widget,$tag,$bg,$fg,$fct_balloon,$var]);
    $widget->tagBind($tag,"<Leave>",[\&kreo_tag_leave,$widget,$tag,$fg,$bg]) }

sub kreo_tag_enter {
    shift;
    my($widget,$tag,$fg,$bg,$fct_balloon,$var) = @_;
    $widget->tagConfigure($tag,-foreground=>$fg,-background=>$bg);
    $widget->configure(-cursor=>$tk{cursor_select});
    return if ! $fct_balloon; 
    return if ! defined(&$fct_balloon); 
    my $msg = '';
    &fct_balloon($var,\$msg);
    return if $msg eq '';
    $widget{balloon}->attach($widget,-msg=>$msg,-balloonposition=>'mouse') }

sub kreo_tag_leave {
    shift;
    my($widget,$tag,$fg,$bg) = @_;
    $widget->tagConfigure($tag,-foreground=>$fg,-background=>$bg);
    $widget->configure(-cursor=>$tk{cursor});
    $widget{balloon}->detach($widget) if $widget{balloon} }

sub kreo_tag_color {
    my($widget,$tag,$x,$y,$fg,$bg) = @_;
    $widget->tagDelete($tag);
    $widget->tagAdd($tag,$x,$y);
    $widget->tagConfigure($tag,-foreground=>$fg,-background=>$bg) }

sub kreo_tag_underline {
    my($widget,$line) = @_;
    my $tag = "line_$line" ;
    $widget->tagDelete($tag) ;
    $widget->tagAdd($tag,"$line.0","$line.end");
    $widget->tagBind($tag,"<Enter>",sub{$widget->tagConfigure($tag,-underline=>1)});
    $widget->tagBind($tag,"<Leave>",sub{$widget->tagConfigure($tag,-underline=>0)}) }

sub kreo_tag_button {
    my($fct,$widget,$x,$y,$var,$fct_1,$fct_2,$fct_3) = @_;
    my $tag = "$fct.$x";
    &kreo_tag_add   ($widget,$tag,$x,$y,$fg{entry},$bg{text});
    $widget->tagBind($tag,"<ButtonRelease-1>",[\&$fct_1,'bind',$var]) if $fct_1;
    $widget->tagBind($tag,"<ButtonRelease-2>",[\&$fct_2,'bind',$var]) if $fct_2;
    $widget->tagBind($tag,"<Button-3>"       ,[\&$fct_3,'bind',$var]) if $fct_3 }

sub kreo_tag_column {
    my($fct,$widget,$line,$ref_column,$fct_1,$fct_2,$fct_3) = @_;
    my($column,$begin,$end);
    foreach $column ( split /\|/ , $$ref_column ) {
       $begin  = rindex($$ref_column,"|$column|") + 2;
       $column = $1 if $column =~ /^ +(.*?) +$/;
       $end    = length($column) + $begin;
       &kreo_tag_button($fct,$widget,"$line.$begin","$line.$end",$column,$fct_1,$fct_2,$fct_3) } }

sub kreo_tag_string {
    my($fct,$widget,$ref_list,$fct_1,$fct_2,$fct_3) = @_;
    my $string; # chaine à rechercher
    my $offset; # pour rechercher la même $string dans la ligne
    my %string; # pour ne pas refaire la même $string dans la ligne
    my($line,$text,$begin,$end);
    foreach $text ( split /[\n\r]/ , $widget->get("1.0","end") ) {
       $line++;
       %string = ();
       foreach $string ( split /[\s+\/\|\(\):;]/ , $text ) {
          next if ! $$ref_list{$string};
          next if $string{$string};
          $offset = length($text);
          while () {
             $begin = rindex($text,$string,$offset);
             last if $begin == -1;
             $offset = $begin - 1;
             $end = length($string) + $begin;
             &kreo_tag_button($fct,$widget,"$line.$begin","$line.$end",$string,$fct_1,$fct_2,$fct_3) }
          $string{$string} = 1 } } }

1;
