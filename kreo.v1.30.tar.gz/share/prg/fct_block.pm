# fct_block.pm version 1.30 Janvier 2025 par Thierry Le Gall

use strict;

# créer un tableau %block à partir des fichiers $file d'un dossier $dir
# $exclude : chaine à exclure ( peut être vide ) 
sub fct_block_dir {
    my($ref_block,$dir,$exclude) = @_;
    my($file,$line);
    chdir $dir;
    opendir(DIR,$dir);
    while($file = readdir DIR) {
       open (FILE,"$dir/$file");
       while($line=<FILE>) {
          next if $exclude && $line =~ /$exclude/;
          chomp $line;
          $$ref_block{$file}{$line} = 1 }
       close FILE }
    close DIR }

# rechercher les blocks contenus dans un tableau de lignes
# $ref_source  : tableau à analyser - tableau des lignes non trouvées en sortie
# $ref_block   : tableau des blocks à rechercher
# $ref_result  : blocks trouvés
# $ref_include : blocks inclus
# $ref_double  : blocks en double
sub fct_block {
    my($ref_source,$ref_block,$ref_result,$ref_include,$ref_double) = @_;
    my($block,$block1,$block2,$line,$ref,$ref1,$ref2);
    my %tempo;

    # recherche des blocks de $ref_block dans $ref_source , resultat dans $ref_result
    foreach $block (keys %$ref_block) {
       $ref = $$ref_block{$block};
       $$ref_result{$block} = 1;
       foreach $line (keys %$ref) {
          if ( ! $$ref_source{$line} ) {
             delete $$ref_result{$block};
             last } } }

    # recherche des blocks inclus de $ref_result , resultat dans %tempo
    foreach $block1 ( keys %$ref_result) {
       foreach $block2 (keys %$ref_result) {
          next if $block2 eq $block1;
          $ref1 = $$ref_block{$block1};
          $ref2 = $$ref_block{$block2};
          $tempo{$block2}{$block1} = 1;
          foreach $line (keys %$ref2) {
             if ( ! $$ref1{$line} ) {
                delete $tempo{$block2}{$block1}; # blocks différents donc pas inclus
                last } } } }

    # pour les block inclus dans tempo
    # création du tableau $ref_double
    # création du tableau $ref_include et suppression des plans inclus dans $ref_result
    foreach $block1 ( sort { $a cmp $b } keys %tempo) {
       $ref = $tempo{$block1};
       foreach $block2 (keys %$ref) {
          next if $$ref_double{"$block2:$block1:"};
          if ( $tempo{$block2}{$block1} ) { $$ref_double {"$block1:$block2:"} = 1 } 
	  else                            { $$ref_include{"$block1:$block2:"} = 1 ; delete $$ref_result{$block1} } } }

    # suppression dans $ref_double des plans inclus
    foreach (keys %$ref_double) {
       $block1 = (split /:/)[0];
       delete $$ref_double{$_} if ! $$ref_result{$block1} }

    # recherche des lignes non trouvées , erreurs dans $ref_source en sortie
    foreach $block (keys %$ref_result) {
       $ref = $$ref_block{$block};
       foreach $line (keys %$ref) { delete $$ref_source{$line} } } }

1;
