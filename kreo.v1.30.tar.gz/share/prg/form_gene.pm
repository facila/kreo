# form_gene.pm version 1.30 Janvier 2025 par Thierry Le Gall

# si formulaire avec un module .pm , alors :
# avant la création du formulaire : exécution du module
# après la création du formulaire : exécution de init

# si formulaire avec une fonction variable , alors :
# la fonction est le premier argument : récupéré par shift

# variables globales
$global{mainloop} = 1; # 1 formulaire indépendant , 0 formulaire inclus dans une autre application tk
%form   = (); # variables pour tk
%widget = (); # utilisé dans les fonctions du formulaire
%var    = (); # variables en entrée et sortie
@out    = (); # tableau des variables en sortie

sub valid {
    my $out = '';
    foreach(@out) { $out .= $var{$_} if defined $var{$_}; $out .= ';' if @out != 1 }
    if ( $out ) {
       $out = &encode('utf8',$out) if $ENV{LANG} =~ /UTF-8/;
       print $out }
    exit if $global{mainloop} }

sub cancel {
    exit if $global{mainloop} }

sub form_gene {
    if ( $_[0] && $_[0] eq 'no_mainloop' ) { shift; $global{mainloop} = 0 }
    my $form = shift;
    exit if ! -f $form;

    require "$ENV{FACILA}/share/prg/form_widget.pm";

    my($a,$b,$p,$x,$y,$w,$v1,$v2,$v3,$v4);
    my @widget;
    open(FILE,"<$env{mode}",$form);
    while(<FILE>) {
       next if /^#|^\s*$/; # lignes ignorées
       last if /^end/;
       if ( /^form;(.*?);(.*);/ ) {
          $a = $1; $a =~ tr/ //d;
          $b = $2; $b =~ s/\$(\w+)/$ENV{$1}/g; # pour remplacer des variables dans la chaine $b
          $form{$a} = $b }
       elsif ( /^(p|g|k);/ ) {
          chomp;
          ($w,$v1,$v2) = (split/;/)[3,4,5];
          if    ($w =~ /entry/       && $v1 ) { $v1 =~ tr/ //d; $var{$v1} = '' }
          elsif ($w =~ /text|browse/ && $v2 ) { $v2 =~ tr/ //d; $var{$v2} = '' }
          push @widget,$_ } }
    close FILE;

    if ( $form{pm} && -f $form{pm} ) { require $form{pm}; @_ = ()         } # cas avec un module
    if ( $_[0]     && $form{$_[0]} ) { $form{title} = $form{$_[0]}; shift } # cas avec une fonction

    my($i,$l,$width,$height) = (0)x4;
    my %width = ();
    my $ref_list;
    foreach(@widget) {
       $i++; # numéro de widget
       ($p,$x,$y,$w,$v1,$v2,$v3,$v4) = (split/;/);
       $w  =~ tr/ //d; # $widget
       $v1 =~ tr/ //d if $w !~ /^(text|browse|check)$/; 
       $v2 =~ tr/ //d if $w =~ /text|browse/; 

       # l longueur du champ pour entry
       if ($w =~ /entry/) {
          $l = $v2;
          if ( $form{geometry} =~ /width/ ) {
             $l = length($_[0]) + 10 if $_[0];
             $l = $v2 if $v2 && $l < $v2 } }

       # $ref_list pour browse
       if ($w eq 'browse') { $ref_list = &browse($v2) }

       # création du widget
       if    ($w eq 'text'     ) { $widget{$i} = &form_widget($w,$main,$v1) }
       elsif ($w eq 'textvar'  ) { $widget{$i} = &form_widget($w,$main,\$var{$v1});    $var{$v1} = shift if @_ }
       elsif ($w eq 'entry'    ) { $widget{$i} = &form_widget($w,$main,\$var{$v1},$l); $var{$v1} = shift if @_ }
       elsif ($w eq 'button'   ) { $widget{$i} = &form_widget($w,$main,$v1,\&$v2) }
       elsif ($w eq 'check'    ) { $widget{$i} = &form_widget($w,$main,$v1,\$var{$v2}) }
       elsif ($w eq 'check_com') { $widget{$i} = &form_widget($w,$main,$v1,\$var{$v2},\&$v3) }
       elsif ($w eq 'radio'    ) { $widget{$i} = &form_widget($w,$main,$v1,\$$v2,$v3,\&$v4) }
       elsif ($w eq 'browse'   ) { $widget{$i} = &form_widget($w,$main,$v1,\$var{$v2},$ref_list,$v3) }
       else  { next }

       if    ($w =~ /^(text|textvar|browse)$/ && $v2 ) { $widget_name{$v2}  = $widget{$i} } # widget associé à une variable $widget_name{$var} = $widget{$i} , permet de le tagguer
       elsif ($w eq 'entry'                          ) { $widget_entry{$v1} = $widget{$i} } # widget associé à une entrée  $widget_entry{$var} = $widget{$i} , permet de gérer le focus

       # positionnement du widget
       if    ($p eq 'p') { $p = 'place'; $x = "0.$x"; $y = "0.$y" } # conversion de place qui est en pourcentage dans tk
       elsif ($p eq 'g') { $p = 'grid' }
       elsif ($p eq 'k') { $p = 'pack' }
       &form_widget($p,$widget{$i},$x,$y);

       # configuration du widget
       $widget{$i}->configure(-font=>"$form{font} $form{size}",-fg=>$form{fg_text},-bg=>$form{bg_text});
       if    ($w eq 'entry'       ) { $widget{$i}->configure(-fg=>$form{fg_entry},-bg=>$form{bg_entry}) }
       elsif ($w eq 'browse'      ) { $widget{$i}->configure(-disabledbackground=>$form{bg_text},-disabledforeground=>$form{fg_text}) }
       elsif ($w =~ /check|radio/ ) { $widget{$i}->configure(-selectcolor=>$form{fg_entry}) }

       # calcul de la longueur = plus grande ligne $x
       if ($w =~ /text|entry/) {
          $width{$x} += $widget{$i}->reqwidth;
          $width      = $width{$x} if $width < $width{$x} }

       $widget{$i}->focus          if $v3 && $w =~ /entry|button/;
       $widget{$i}->icursor('end') if $v3 && $w eq 'entry' }

    # geometry du formulaire
    if ( $global{mainloop} ) {
       # longueur du formulaire
       if ( $width && $form{geometry} =~ /width/ ) {
          $width += $form{add_width};	
          $width  = $form{min_width} if $width < $form{min_width};
          $form{geometry} =~ s/width/$width/ }

       # hauteur du formulaire
       if ( $form{geometry} =~ /height/ ) {
          $height = 3 * $form{size} * $x;
          $form{geometry} =~ s/height/$height/ } }

    # initialisation
    &init  if exists &init;
    &reset if exists &reset;

    # @out : variables en sortie
    if ( $form{out} ) { @out = split/;/,$form{out} } }

1;
