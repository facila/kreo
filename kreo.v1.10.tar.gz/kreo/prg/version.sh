#!/bin/bash

# version.sh version 1.10 Octobre 2023 par Thierry Le Gall
# création d'une version pour un projet de kreo dans facila

cd $FACILA

   DATE=`date +%y%m%d_%H%M`
PROJECT=$1
   DATA=$PROJECT/data
   SAVE=save/data/$PROJECT.$DATE
VERSION=save/version/$PROJECT.$DATE.tar.gz

     SRC=`kreo/prg/version.pl kreo/data/$USER/archive/$PROJECT`
 SRC_DIR=`echo $SRC | cut -f1 -d';'`
SRC_FILE=`echo $SRC | cut -f2 -d';'`

[ -d $DATA ] && { mkdir $SAVE ; mv $DATA/* $SAVE ; } # sauvegarde et réinitialisation de $DATA 
tar -C $SRC_DIR $SRC_FILE -czf $VERSION              # creation de la version
[ -d $DATA ] && cp -r $SAVE/* $DATA                  # retour au dossier initial de $DATA

printf $VERSION
