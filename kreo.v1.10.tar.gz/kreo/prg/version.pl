#!/usr/bin/perl -w

foreach(`cat $ARGV[0]`) {
   chomp;
   if ( /($ENV{FACILA})\/(.*)/ ) { $src_file .= "$2 "; $src_dir = $1 }
   else                          { $src_file .= "$_ "; $src_dir = '/' } }

print "$src_dir;$src_file;";
