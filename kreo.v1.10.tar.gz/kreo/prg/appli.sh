#!/bin/bash

# version 1.10 Octobre 2023 par Thierry Le Gall
# script de création d'une application en perl TK

APPLI=$1

[ -d "$FACILA/$APPLI" ] && { echo $FACILA/$APPLI existe déjà ; exit ; }

APPLI2=`echo $APPLI | sed 's/^./\u&/'`

cd $FACILA
mkdir $APPLI
cp -pR kreo/appli/* $APPLI

cd $FACILA/$APPLI/prg
mv appli    $APPLI
mv appli.tk $APPLI.tk

cd $FACILA/$APPLI/var/$LANG/appli
sed -i "s/NEW/$APPLI2/" *

cd $FACILA/$APPLI/var/$LANG/help
sed -i "s/NEW/$APPLI2/" *
