# fct_sql.pm version 1.10 Octobre 2023 par Thierry Le Gall

require "$ENV{FACILA}/share/prg/fct_utf8.pm";
use DBI;

# variables globales : %dbi

# fonctions shell
sub fct_sql_count {
    my($table)=@_;
    my $mysql = "mysql -u $dbi{username} -p$dbi{password} $dbi{base}";
    my $query = "SELECT COUNT(1) FROM $table";
    chomp(my $total = `$mysql -Bse "$query" 2> /dev/null`);
    return $total }

# fonctions perl
sub fct_sql_connect    { $dbi{dbh} = DBI->connect("DBI:mysql:$dbi{base}",$dbi{username},$dbi{password}) }
sub fct_sql_disconnect { $dbi{dbh}->disconnect() }
sub fct_sql_exec       { my($query) = @_; &fct_sql_connect; $dbi{dbh}->do($query); &fct_sql_disconnect() }

sub fct_sql_tables {
    # tableau des tables %$ref
    my ($ref) = @_;
    my $sth = $dbi{dbh}->prepare("SHOW TABLES");
    $sth->execute();
    while ( my @row = $sth->fetchrow_array() ) { $$ref{$row[0]} = 1 }
    $sth->finish() }

sub fct_sql_columns {
    # tableau des colonnes d'une table @$ref
    my ($table,$ref) = @_;
    my $sth = $dbi{dbh}->prepare("SHOW COLUMNS FROM $table");
    $sth->execute();
    while ( my @row = $sth->fetchrow_array() ) { push @$ref,$row[0] }
    $sth->finish() }

sub fct_sql_id {
    # tableau des id et des valeurs d'une table %$ref
    my ($table,$ref) = @_;
    my $sth = $dbi{dbh}->prepare("SELECT * FROM $table");
    $sth->execute();
    while ( my ($id,$value) = ($sth->fetchrow_array())[0,1] ) {
       &fct_utf8('decode',\$value); # utf8 pour les accents
       $$ref{$table}{$id} = $value }
    $sth->finish() }

1;
