# fct_var.pm version 1.10 Octobre 2023 par Thierry Le Gall

# fct_var_init  : initialisation des variables de $file
# fct_var_read  : initialisation des variables de $file dans %$name
# fct_var_write : sauvegarde des variables de %$name dans $file

if ( ! $env{mode} ) {
   $env{mode} = '';
   $env{mode} = ':encoding(UTF-8)' if $ENV{LANG} =~ /UTF-8/ }

sub fct_var_init {
    my($file) = @_;
    my($t,$v,$x);
    open(FILE,"<$env{mode}",$file);
    while(<FILE>) {
       next if /^#|^\s*$/; # lignes ignorées
       ($t,$v,$x) = split/;/;
       $v =~ tr/ //d;
       $$t{$v} = $x }
    close FILE }

sub fct_var_read {
    my($name,$file) = @_;
    my($x,$v);
    open(FILE,"<$env{mode}",$file);
    while(<FILE>) { ($x,$v) = split/;/; $$name{$x} = $v }
    close FILE }

sub fct_var_write {
    my($name,$file) = @_;
    my $text;
    foreach( sort { $a cmp $b } keys %$name) { $text .= "$_;$$name{$_};\n" }
    open(FILE,">$env{mode}","$file");
    print FILE "$text";
    close FILE }

1;
