# fct_block.pm version 1.10 Octobre 2023 par Thierry Le Gall

use strict;

# créer un tableau %block à partir des fichiers $file d'un dossier $dir
# $exclude : chaine à exclure ( peut être vide ) 
sub fct_block_dir {
    my($ref_block,$dir,$exclude) = @_;
    my($file,$line);
    chdir $dir;
    opendir(DIR,$dir);
    while($file = readdir DIR) {
       open (FILE,"$dir/$file");
       while($line=<FILE>) {
          next if $exclude && $line =~ /$exclude/;
          chomp $line;
          $$ref_block{$file}{$line} = 1 }
       close FILE }
    close DIR }

# rechercher les blocks contenus dans un tableau de lignes
# $ref_source  : tableau à analyser - tableau des lignes non trouvées en sortie
# $ref_block   : tableau des blocks à rechercher
# $ref_result  : blocks trouvés
# $ref_include : blocks inclus
sub fct_block {
    my($ref_source,$ref_block,$ref_result,$ref_include) = @_;
    my(%no_line,%include);
    my($line,$include);
    my($block,$block1,$block2,$ref,$ref1,$ref2);

    # recherche des blocks
    foreach $block (keys %$ref_block) {
       $ref = $$ref_block{$block};
       foreach $line (keys %$ref) {
          last if $no_line{$block};
          $$ref_result{$block} = 1;
          if ( ! $$ref_source{$line} ) {
             $no_line{$block} = 1;
             delete $$ref_result{$block} } } }

    # recherche des blocks inclus et des lignes non trouvées error
    foreach $block1 (keys %$ref_result) {
       $ref1 = $$ref_block{$block1};
       foreach $line (keys %$ref1) { delete $$ref_source{$line} }
       foreach $block2 (keys %$ref_result) {
          next if $block1 eq $block2;
          $ref2 = $$ref_block{$block2};
          foreach $line (keys %$ref1) {
             $include = 0;
             last if ! $$ref2{$line};
             $include = 1 }
          $$ref_include{$block1} = 1 if $include } }

    # suppression des blocks inclus
    foreach $block (keys %$ref_result) { delete $$ref_result{$block} if $$ref_include{$block} } }

1;
