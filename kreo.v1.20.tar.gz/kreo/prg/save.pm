sub save_select {
    $init{current_dir}  = $appli{save};
    $init{current_file} = '';
    &kreo_page_set('dir') }

sub save {
    my ($dir,$file) = @_; # $file est un fichier ou un dossier
    chomp(my $date = `date +%y%m%d_%H%M`);
    my $save = $file;
    $save = $1 if $file =~ /$env{facila}\/(.*)/;
    $dir  = "$appli{save}/$dir";
    return if $file =~ /^$dir/; # pas de sauvegarde dans le même dossier
    return 1 if &shell_error("mkdir -p \"$dir/$save\"");            # création des dossiers contenus dans $save
    return 1 if &shell_error("rmdir    \"$dir/$save\"");            # suppression du dernier dossier de $save
    return 1 if &shell_error("mv \"$file\" \"$dir/$save.$date\"") } # déplacement de $file dans $dir

sub archive_open {
    my $project = $_[0];
    $project = $appli{project_name} if ! $project;
    return if ! $project;
    return if &error('project_absent',"$dir{data}/init/$project");
    my $archive = "$dir{data}/archive/$project";
    return if &error('file_absent',$archive);
    &open('file',$archive) }

sub archive_create {
    my $project = $appli{project_name};
    return if &error('project_absent',"$dir{data}/init/$project");
    chomp(my $date = `date +%y%m%d_%H%M`);
    my $archive = "$dir{data}/archive/$project";
    my $dir     = "$appli{save}/archive";
    my $tar     = "$dir/$project.$date.tar.gz";
    return if &shell_error("tar -T $archive -czf $tar 2> /dev/null");
    return if &shell_error("chmod 600 $tar");
    &archive_init($dir,$tar) }

sub version_create {
    my $project = $appli{project_name};
    return if &error('project_absent',"$dir{data}/init/$project");
    my $dir = "$appli{save}/version";
    my $tar = '';
    &fct_shell(\$tar,"version.sh $project");
    &archive_init($dir,$tar) }

sub archive_extract {
    my $project = $appli{project_name};
    return if &error('project_absent',"$dir{data}/init/$project");
    return if &error('project_extract',$project); # extract impossible pour kreo
    # création d'une nouvelle archive avant l'extract
    &archive_create;
    # déplacement de la version courante dans save/old si elle existe
    foreach (`cat "$dir{data}/archive/$project"`) { chomp; return if &save('old',"$_") }
    # extract de l'archive séléctionnée
    my $dir = "$appli{save}/archive";
    my $tar = $_[0];
    return if &shell_error("cd /; tar -xzf $tar 2> /dev/null");
    &archive_init($dir,$tar) }

sub archive_init {
    my($dir,$tar) = @_;
    $init{current_dir}  = $dir;
    $init{current_file} = $tar;
    &kreo_page_set('dir') }

1;
