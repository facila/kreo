sub page_help {
    chomp(my $file = `ls -1 $dir{var}/help/$var{help}*`);
    return if &error('file_absent',$file);
    &kreo_help('help',$var{help});
    &kreo_insert_info($file) }

sub page_1 { }
sub page_2 { }
sub page_3 { }

1;
