# fct_file.pm version 1.20 Mars 2024 par Thierry Le Gall

# fct_file_ext  : extention de $file
# fct_file_code : encodage de $file
# fct_file_date : 1 si la date de $file est du jour
# fct_file_line : @file = tableau contenant les lignes de $file
# fct_file_info : encodage , taille et ls de $file

require "$ENV{FACILA}/share/prg/fct_utf8.pm"; # pour fct_shell

sub fct_file_ext {
    my($file) = @_;
    return if ! -e $file;
    my $ext  = ''; $ext = $1 if $file =~ /\.([^\.]*)$/;
    return $ext }

sub fct_file_code {
    my($file) = @_;
    return if ! -e $file;
    chomp(my $code =`file -b --mime-encoding \"$file\"`);
    return $code }

sub fct_file_date {
    my($file) = @_;
    return if ! -e $file;
    return 1 if `date +%Y%m%d` eq `date +%Y%m%d -r \"$file\"` }

sub fct_file_line {
    my($file) = @_;
    return if ! -e $file;
    open FILE,$file;
    my @file = <FILE>;
    close FILE;
    return @file }

sub fct_file_info {
    my($file,$ref_text) = @_;
    return if ! -e $file;
    my $wc='' ; $wc = &fct_file_line($file) if $var{file_code} ne 'binary';
    my $ls='' ; &fct_shell(\$ls,"ls -l \"$file\"");
    $$ref_text  = " $var{file_code}";
    $$ref_text .= " : $wc lignes" if $wc;
    $$ref_text .= " : $ls" }

1;
