# form_init.pm version 1.20 Mars 2024 par Thierry Le Gall

sub form_init {
    $env{mode} = ''; $env{mode} = ':encoding(UTF-8)' if $ENV{LANG} =~ /UTF-8/;
    my $a;
    chdir "$ENV{FACILA}/kreo/var/$ENV{LANG}/form";
    open(FILE,"<$env{mode}","default");
    while(<FILE>) { if ( /^form;(.*);(.*);/ ) { $a = $1; $a =~ tr/ //d; $form{$a} = $2 } }
    close FILE;
    use Tk;
    $main = MainWindow->new }

sub form_main {
    $main->bind('<Escape>',sub{$main->destroy});
    $main->title($form{title});
    $main->geometry($form{geometry});
    $main->resizable($form{resize_w},$form{resize_h});
    $main->configure(-fg=>$form{fg_main},-bg=>$form{bg_main}); 
    MainLoop }

1;
