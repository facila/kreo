#!/usr/bin/perl -w

# commandes utilisées par les menus , les boutons et les tags

############### Aide ###############
sub help {
    my($nb) = @_;

    if ( ! $nb ) {
       # si nb est vide help est appelé par escape -> recherche du menu supérieur à afficher
       $nb = $var{help};
       foreach( sort { $b <=> $a } keys %help ) {
          if ( $nb >= $_ ) { $nb = $help{$_}; last } } }

    &kreo_help_bind('','help',$nb) }

sub entry_1 {
    $var{entry_1} = $widget{entry_1}->get();
    $widget{entry_1}->delete('0','end');
    &kreo_variable('variable') }

############### Quitter ###############
# Quitter utilise les commandes appli_ dans kreo_appli.pm

1;
