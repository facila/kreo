#!/bin/bash

# version 0.09 Septembre 2021 par Thierry Le Gall
# script de modification d'un projet dans kreo

DATA=$1
PROJECT=$2
DIR=$3
EXE=$4
DSC=$5
 
cd $DATA/project/$PROJECT
INIT=`grep -v ^project_ init`

{
echo "$INIT"
echo "project_dir;$DIR;"
echo "project_exe;$EXE;"
echo "project_dsc;$DSC;"
} > init
