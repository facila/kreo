#!/usr/bin/perl -w

# file_dir.pl version 0.09 Septembre 2021 par Thierry Le Gall
# recherche dans $file des fichiers du répertoire $dir

$share = "/usr/local/facila/share/prg";
require "$share/file_dir.pm";

$file = "$share/f111";
$dir  = "/usr/local/facila/plan/";

%list = ();
&list_dir(\%list,$dir);

for $i ( 1 .. 10000 ) {
    %source = ();
    &source_file($file,\%source);

    %find = ();
    &find_file(\%source,\%list,\%find);

    %result = ();
    &result_file(\%list,\%find,\%result);

    foreach $f (keys %result) {
    #   print "f:$f\n";
       foreach $line (`cat $f`) {
          chomp $line;
          delete $source{$line} } }

    #foreach $line (keys %source) {
    #   print "l:$line\n" }
    }

print "\n";
