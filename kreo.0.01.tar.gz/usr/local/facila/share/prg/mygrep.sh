#!/bin/bash

OPTIONS=$1
PATTERN=$2
FILTER=$3
FILE=$4

[ "$FILE" = '' ] && exit

if   [ "$PATTERN" != '' -a "$FILTER"  = '' ] ; then grep -R  $OPTIONS "$PATTERN" $FILE
elif [ "$PATTERN"  = '' -a "$FILTER" != '' ] ; then grep -Rv $OPTIONS "$FILTER"  $FILE
elif [ "$PATTERN" != '' -a "$FILTER" != '' ] ; then grep -R  $OPTIONS "$PATTERN" $FILE | grep -v "$FILTER"
fi
