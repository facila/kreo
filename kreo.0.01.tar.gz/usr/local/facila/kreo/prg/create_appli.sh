#!/bin/bash

# version 0.01 01/01/2021 par Thierry Le Gall
# script de création d'une application en perl TK

FACILA=/usr/local/facila
 APPLI=$1

[ -d "$FACILA/$APPLI" ] && { echo $FACILA/$APPLI existe déjà ; exit ; }

#APPLI2=`echo $APPLI | sed 's/^./\u&/'`

mkdir $FACILA/$APPLI
cd $FACILA/$APPLI
mkdir data
mkdir prg
mkdir tmp
mkdir var
mkdir var/$LANG
mkdir var/$LANG/tk
mkdir var/$LANG/help

cp $FACILA/kreo/init_prg/kreo        prg/$APPLI
cp $FACILA/kreo/init_prg/kreo.tk     prg/$APPLI.tk
cp $FACILA/kreo/init_prg/appli.pm    prg/appli.pm
cp $FACILA/kreo/init_prg/command.pm  prg/command.pm
cp $FACILA/kreo/init_tk/*            var/$LANG/tk
 
chmod -R 755 *
chmod -R 777 tmp

$FACILA/$APPLI/prg/$APPLI &
