sub page_help {
    my $page = $var{page};
    my $file = $file{help};
    return if ! -s $file;
    my $info = '';
    my $text;
    &kreo_shell(\$text,"cat $file");
    &kreo_page_text($page,\$text,\$info) }

sub page_list {
    my $page = $var{page};
    my $file = "$dir{data}/project";
    return if ! -s $file;
    my $info = '';
    my $text;
    &kreo_shell(\$text,"( echo ; ls -1 $file | awk '{ print \" \" \$0 }')");
    &kreo_page_text($page,\$text,\$info);
    &tag_list($page,\$text) }

sub page_project {
    my $page = $var{page};
    my $file = $file{project};
    return if ! -s $file;
    my($tag) = @_;
    my $info = " $file{project}";
    my $text;
    &kreo_shell(\$text,"cat $file");
    &kreo_page_text($page,\$text,\$info);
    &tag_file($page,\$text) if $tag }

sub page_dir {
    my $page = $var{page};
    my $dir  = $var{dir};
    my $text = '';
    if ( ! $dir ) {
       &kreo_page_clear($page);
       return }

    &kreo_variable('variable');
    &kreo_insert($widget{info},\" $dir",$tk{fg_dir},$tk{bg_dir});

    &kreo_wait;
    &kreo_shell(\$text,"ls -al $dir");
    &kreo_insert($page{$page},\$text,$tk{fg_text},$tk{bg_text});
    &tag_dir($page,\$text)}

sub page_file {
    my $page = $var{page} = 'file';
    my $file = $var{file};
    my $fg   = $tk{fg_file};
    my $bg   = $tk{bg_file};
    my $text = '';

    &kreo_state('menu','file_','disabled');
    if ( ! -s $file ) {
       &kreo_page_clear($page);
       return }

    &kreo_variable('variable');
    `( echo $file ; grep -v $file $tmp{histo} ) > $tmp{tmp}; cp $tmp{tmp} $tmp{histo}`;

    my $date  = &kreo_file_date($file);
    my $code  = &kreo_file_code($file);
    $text     = &kreo_file_info($file);
    $fg       = $tk{fg_binary} if $code eq 'binary';
    ($fg,$bg) = ($bg,$fg)      if $date; # invers video si date = jour
    &kreo_insert($widget{info},\$text,$fg,$bg);

    $text = '';
    if ( $code ne 'binary' ) {
       &kreo_shell(\$text,"cat $file");
       &kreo_state('menu','file_','normal') }
    &kreo_insert($page{$page},\$text,$tk{fg_text},$tk{bg_text}) }

sub page_find {
    local $fg = $tk{fg_ko};
    local $bg = $tk{bg_ko};
    $var{entry_include} = $widget{entry_include}->get();
    $var{entry_exclude} = $widget{entry_exclude}->get();
    if ( ! $var{entry_include} && ! $var{entry_exclude} ) {
       &kreo_insert($widget{info},\" $msg{find_entry}",$fg,$bg);
       return }

    $var{find_opt}  = '-s';
    $var{find_opt} .= 'i' if $var{entry_case};
    `cp /dev/null $tmp{tmp}`;

    &kreo_wait;
    my $fct = "find_$var{find}";
    return if &$fct;

    my $text = my $info = '';
    if ( -s $tmp{tmp} ) {
       `cp $tmp{tmp} $tmp{find}`; # $tmp{find} utilisé pour rechercher dans la page Rechercher

       if    ( $var{find} eq 'file'        ) { $var{tag} = 0 }
       elsif ( $var{find} =~ /dir|project/ ) { $var{tag} = 1 }

       &kreo_shell    (\$text,"cat $tmp{find}");
       &kreo_page_text('find',\$text,\$info);
       &tag_file      ('find',\$text) if $var{tag};

       &kreo_file_line($tmp{find},\$text);
       $text = " $text lignes dans $var{find_info}";
       $fg = $tk{fg_ok};
       $bg = $tk{bg_ok} }
    else {
       $text = " $msg{find_error} : $var{entry_include} - $var{entry_exclude}" }

    &kreo_insert($widget{info},\$text,$fg,$bg) }

sub page_histo {
    my $page = 'histo';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat $tmp{histo}");
    &kreo_page_text($page,\$text,\$info);
    &tag_file      ($page,\$text) }

sub page_debug {
    my $page = 'debug';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat $tmp{debug}");
    &kreo_page_text($page,\$text,\$info) }

sub page_var {
    my $page ='var';
    my($text,$var,$info,$global) = '';
    foreach (sort{$a <=> $b} keys %global ) {
       $global = $global{$_};
       $text  .= "\n $msg{variables} %$global\n\n";
       foreach (sort{$a cmp $b} keys %$global) {
          $var = $$global{$_};
          $text .= sprintf "   %-20s %-s\n" , $_ , $var } }

    &kreo_page_text($page,\$text,\$info) }

####################################################################
# fonctions find

# rechercher dans la page Rechercher
sub find_find {
    if ( ! -s $tmp{find} ) {
       &kreo_insert($widget{info},\" $msg{find_ko}",$fg,$bg);
       return 1 }

    $var{find_file} = $tmp{find};
    $var{find_info} = $msg{find_ok};
    &appli_grep }

# rechercher dans le fichier
sub find_file {
    if ( ! -s $var{file} ) {
       &kreo_insert($widget{info},\" $msg{find_file}",$fg,$bg);
       return 1 }

    $var{find_file} = $var{find_info} = $var{file};
    &appli_grep}

# rechercher dans le répertoire
sub find_dir {
    if ( ! -d $var{dir} ) {
       &kreo_insert($widget{info},\" $msg{find_dir}",$fg,$bg);
       return 1 }

    $var{find_file} = $var{find_info} = $var{dir};
    chdir $var{find_file};
    $var{find_file} .= "/*";
    &appli_grep }

# rechercher dans le projet
sub find_project {
    my $project = "$dir{data}/project/$var{project}";
    if ( ! -s $project ) {
       &kreo_insert($widget{info},\" $msg{find_project}",$fg,$bg);
       return 1 }

    my $opt = $var{find_opt};
    $var{find_info} = $var{project};
    my $text; &kreo_shell(\$text,"cat $project");
    foreach(split/\n/,$text) {
       if ( -d $_ ) {
          $var{find_file} = "$_/*";
          chdir $_;
          &appli_grep }
       elsif ( -s $_ ) {
          $var{find_file} = $_ ;
          $var{find_opt} .= 'H';
          &appli_grep;
          $var{find_opt} = $opt } } }

####################################################################
# fonctions tag

sub tag_list {
    my($page,$ref_text) = @_;
    my $ligne = 0;
    foreach(split/\n/,$$ref_text) {
       $ligne++;
       next if $ligne == 1;
       if ( /^ (.+)$/ ) {
          my $link = $1 ;
          my $y    = length($link)+1;
          my $tag  = $page."_$ligne";
          &kreo_tag_add($page{$page},$tag,"$ligne.1","$ligne.$y",$tk{fg_entry},$tk{bg_entry});
          $page{$page}->tagBind($tag,"<ButtonRelease-1>",[\&bind_list,$link]) } } }

sub tag_file {
    my($page,$ref_text) = @_;
    my $ligne = 0;
    foreach(split/\n/,$$ref_text) {
       chomp;
       $ligne++;
       $_ = $1 if /(.*?):/;
       my $link = $_;
       my $y = length($link);
       &tag_dir_file($link,$page{$page},$page."_$ligne","$ligne.0","$ligne.$y") } }

sub tag_dir {
    my($page,$ref_text) = @_;
    my $dir = $var{dir};
    my $var;
    my $ligne = 0;
    foreach(split/\n/,$$ref_text) {
       chomp;
       $ligne++;
       my $link = (split/\s+/)[8];
       if ( $link ) {
          next if $link eq '.';
          next if $link eq '..' && $dir eq '/';
          $link = $1 if / -> (.*)/;

          if    (                  $dir eq '/'          ) { $var = "/$link" }
          elsif ( $link eq '..' && $dir =~ /^(.+)\/.*$/ ) { $var = $1 }
          elsif ( $link eq '..' && $dir =~ /^(\/).+$/   ) { $var = $1 }
          elsif ( $link =~ /^\//                        ) { $var = $link }
          else                                            { $var = "$dir/$link" }

          my $y = length($_);
          my $x = $y - length($link);
          &tag_dir_file($var,$page{$page},$page."_$ligne","$ligne.$x","$ligne.$y") } } }

sub tag_dir_file {
    # tag sur l'affichage des noms de répertoires et des noms de fichiers
    my($var,$widget,$tag,$x,$y,$fg,$bg) = @_;
    if ( -d $var ) {
       $fg = $tk{fg_dir}; $bg = $tk{bg_dir};
       &kreo_tag_add($widget,$tag,$x,$y,$fg,$bg);
       $widget->tagBind($tag,"<ButtonRelease-1>",[\&bind_dir,$var]) }
    elsif ( -f $var ) {
       $fg = $tk{fg_file}; $bg = $tk{bg_file};
       $fg = $tk{fg_binary} if &kreo_file_code($var) eq 'binary';
       &kreo_tag_add($widget,$tag,$x,$y,$fg,$bg);
       $widget->tagBind($tag,"<ButtonRelease-1>",[\&bind_file,$var]) }
    else {
       $fg = $tk{fg_ko}; $bg = $tk{bg_ko};
       &kreo_tag_color($widget,$tag,$x,$y,$fg,$bg) } }

####################################################################
# fonctions bind

sub bind_list {
    shift;
    $var{dir}      = '';
    $var{file}     = '';
    $var{project}  = $_[0];
    $file{project} = "$dir{data}/project/$var{project}";
    `cp /dev/null $tmp{histo}`;
    `cp /dev/null $tmp{find}`;
    &kreo_state('menu','file_','disabled');
    &kreo_variable('variable');
    &kreo_page_clear('dir');
    &kreo_page_clear('file');
    &kreo_page_set('project') }

sub bind_dir {
    shift;
    $var{dir} = $_[0];
    &kreo_page_set('dir') }

sub bind_file {
    shift;
    $var{file} = $_[0];
    &kreo_shell(\$var{dir},"dirname $var{file}");
    &kreo_page_set('file') }

1;
