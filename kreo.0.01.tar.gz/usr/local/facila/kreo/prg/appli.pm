sub appli_init {
    # variables sauvegardées dans init
    my $file = "$dir{data}/init";
    my($x,$v,$page);
    open(FILE,"<$var{mode}",$file);
    while(<FILE>) {
       ($x,$v) = split/;/ ;
       $init{$x} = $var{$x} = $v }
    close FILE;

    $file{help}    = "$dir{var}/help/$file{help}";
    $file{project} = "$dir{data}/project/$var{project}";
    &kreo_state('file_','disabled');
    &kreo_variable('variable');
    $page = 'project';
    if    ( $var{file} ) { $page = 'file' }
    elsif ( $var{dir}  ) { $page = 'dir'  }
    $var{page} = $page;
    &appli_reinit;
    $widget{book}->raise($page) }

sub appli_escape {
    &kreo_page($var{page}) }

sub appli_exit {
    my($file,$x,$v,$init);
    $file = "$dir{data}/init";
    open(FILE,"<$var{mode}",$file);
    while(<FILE>) {
       ($x,$v) = split/;/ ;
       $init .= "$x;$var{$x};\n" }
    close FILE;
    chomp $init;
    `printf "$init" > $file`;
    unlink <$tmp{tmp}*>;
    exit }

sub appli_reinit {
    $widget{entry_include}->focus;
    $widget{entry_include}->delete('0.0','end');
    $widget{entry_exclude}->delete('0.0','end');
    $var{entry_case} = $init{entry_case};
    `cp /dev/null $tmp{debug}`;
    &kreo_page_set($var{page}) }

sub appli_restart {
    system("$dir{prg}/$var{appli} $env{user} &");
    &appli_exit }

sub appli_grep {
    # >> $tmp{tmp} car appli_grep peut etre appelé plusieurs fois sur la recherche dans le projet
    `$dir{share}/mygrep.sh "$var{find_opt}" "$var{entry_include}" "$var{entry_exclude}" "$var{find_file}" 2>/dev/null >> $tmp{tmp}` }

1;
