$var{file} = $_[0];

sub maj { ( $var{id} , $var{user} , $var{group} , $var{others} ) = split//,$var{out} }

sub reinit {
    $var{in}      = `stat --printf=%.4a $var{file}`;
    $var{in_all}  = `stat --printf=%A   $var{file}`;
    $var{in_all} .= "   $var{in}";
    $var{out}     = $var{in};
    my @in = split//, sprintf "%.12b" , oct($var{out});
    for('u_s','g_s','a_t','u_r','u_w','u_x','g_r','g_w','g_x','o_r','o_w','o_x') { $var{$_} = shift @in }
    maj() }

sub change {
    my $x = 0;
    $x += 4000 if $var{u_s};
    $x += 2000 if $var{g_s};
    $x += 1000 if $var{a_t};
    $x +=  400 if $var{u_r};
    $x +=  200 if $var{u_w};
    $x +=  100 if $var{u_x};
    $x +=   40 if $var{g_r};
    $x +=   20 if $var{g_w};
    $x +=   10 if $var{g_x};
    $x +=    4 if $var{o_r};
    $x +=    2 if $var{o_w};
    $x +=    1 if $var{o_x};
    $var{out} = sprintf "%.4d" , $x;
    maj() }

sub result {
    print $var{out} if $var{out} ne $var{in};
    exit }

1;
