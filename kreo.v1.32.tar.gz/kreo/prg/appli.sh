#!/bin/bash

# version 1.32 Juin 2025 par Thierry Le Gall
# script de création d'une application en perl TK

APPLI=$1

[ -d "$FACILA/$APPLI" ] && { echo $FACILA/$APPLI existe déjà ; exit ; }

APPLI2=${APPLI^}

cd $FACILA || exit
mkdir $APPLI
cp -pR kreo/appli/* $APPLI

cd $FACILA/$APPLI/prg || exit
mv appli    $APPLI
mv appli.tk $APPLI.tk

cd $FACILA/$APPLI/var/$LANG/appli || exit
sed -i "s/NEW/$APPLI2/" .\*

cd $FACILA/$APPLI/var/$LANG/help || exit
sed -i "s/NEW/$APPLI2/" .\*
