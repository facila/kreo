#!/bin/bash

# version 1.32 Juin 2025 par Thierry Le Gall
# script de gestion d'un projet dans kreo

create ()
{
DIR=$1
EXE=$2
DSC=$3

echo "$DIR" > "archive/$PROJECT"
echo note   > "note/$PROJECT"
 
{ echo "current_dir;$DIR;"
  echo "current_file;$EXE;"
  echo "entry_case;1;"
  echo "entry_exclude;;"
  echo "entry_include;;"
  echo "project_dir;$DIR;"
  echo "project_exe;$EXE;"
  echo "project_dsc;$DSC;"
} > "init/$PROJECT"

if [ "$DIR" != "" ] && [ ! -d "$DIR" ]
then mkdir "$DIR"
     cd "$DIR" || exit
     mkdir data prg var
fi

if [ "$EXE" != "" ] && [ ! -f "$EXE" ]
then { echo "#!/bin/bash"
       echo
       echo "# ligne à remplacer par le fichier de démarrage de l'application"
       echo "$PROJECT"
     } > "$EXE"
     chmod +x "$EXE"
fi
}

modify ()
{
DIR=$1
EXE=$2
DSC=$3
cd init || exit
INIT=$(grep -v ^project_ "$PROJECT")
{
echo "$INIT"
echo "project_dir;$DIR;"
echo "project_exe;$EXE;"
echo "project_dsc;$DSC;"
} > "$PROJECT"
}

copy ()
{ 
NEW=$1
for DIR in archive init note 
do cp -p "$DIR/$PROJECT" "$DIR/$NEW"
done
}

rename ()
{
NEW=$1
for DIR in archive init note 
do mv "$DIR/$PROJECT" "$DIR/$NEW"
done
}

delete ()
{
for DIR in archive init note 
do rm -f "$DIR/$PROJECT"
done
}

##################################################

cd $FACILA/kreo/data/$USER || exit 
FCT=$1
PROJECT=$2

$FCT "$3" "$4" "$5"
