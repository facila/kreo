sub appli_init {
    fct_var_read('appli',"$dir{data}/appli");
    foreach(`cd $dir{var}/help; ls -1 | grep -v _0_`) { $help{$2} = $1 if /^(\d+)_(\d+)_/ }
    project_init($appli{project_name}) if $appli{project_name};
    kreo_variable('variable');
    help('100');
    }

sub appli_escape {
    if ( $var{page} eq 'help' ) { help(0) }
    else { kreo_page($var{page}) } }

sub appli_grep {
    # >> $tmp{tmp} car appli_grep peut etre appelé plusieurs fois sur la recherche dans le projet
    `$dir{share}/prg/mygrep "$var{find_opt}" "$init{entry_include}" "$init{entry_exclude}" "$var{find_file}" 2>/dev/null >> $tmp{tmp}` }

sub appli_error {
    if ( error('file_edit',$init{current_file}                      ) ) { kreo_page_set('file'); return 1 } 
    if ( error('arch_edit',"$dir{data}/archive/$appli{project_name}") ) { kreo_page_set('arch'); return 1 } 
    if ( error('note_edit',"$dir{data}/note/$appli{project_name}"   ) ) { kreo_page_set('note'); return 1 } }

sub appli_exit {
	# return if appli_error();
	# fct_var_write('appli',"$dir{data}/appli");
	# fct_var_write('init' ,"$dir{data}/init/$appli{project_name}") if $appli{project_name};
    unlink <$tmp{tmp}*>;
    exit }

sub appli_reinit {
    return if appli_error();
    `cp /dev/null $tmp{show}`;
    `cp /dev/null $tmp{debug}`;
    kreo_page_set('help') }

sub appli_restart {
    return if appli_error();
    system("$dir{prg}/$env{appli} $env{user}");
    appli_exit() }

1;
