############### Aide ###############
sub help {
    my($nb) = @_;
    if ( ! $nb ) {
       # si nb est vide help est appelé par escape -> recherche du menu supérieur à afficher
       $nb = $var{help};
       foreach( sort { $b <=> $a } keys %help ) {
          if ( $nb >= $_ ) { $nb = $help{$_}; last } } }
    kreo_help_bind('','help',$nb) }

sub entry_1 {
    $var{entry_1} = $widget{entry_1}->get();
    $widget{entry_1}->delete('0','end');
    kreo_variable('variable') }

sub error {
    my ($msg,$file,$code,$ext) = @_;

    if    ( $msg =~ /absent/ && ! $file ) { } # error

    elsif ( $msg eq 'dir_absent'     ) { return if   -d $file }
    elsif ( $msg eq 'dir_exist'      ) { return if ! -d $file }

    elsif ( $msg eq 'file_absent'    ) { return if   -f $file }
    elsif ( $msg eq 'file_exist'     ) { return if ! -f $file }
    # elsif ( $msg eq 'file_binary'    ) { return if $code ne 'binary' }
    # elsif ( $msg eq 'file_open'      ) { return if $code ne 'binary' || ( $ext && $ext !~ /.($env{archive})$/ ) }
    # elsif ( $msg eq 'file_edit'      ) { return if ! $var{edit_file} }

    # elsif ( $msg eq 'find_empty'     ) { return if   -s $file }
    # elsif ( $msg eq 'find'           ) { return if   -s $file }

    # elsif ( $msg eq 'entry'          ) { return if $init{entry_include} || $init{entry_exclude} }

    # if ( $msg eq 'file_open' ) { $msg = 'file_binary' }

    my $error = $msg{"error_$msg"}; 
    # if    ( $msg eq 'find'  ) { $error .= " : $init{entry_include} - $init{entry_exclude}" }
    # elsif ( $msg !~ /entry/ ) { $error  = "$error : $file" }
    info('error',$error);
    return 1 }

1;
