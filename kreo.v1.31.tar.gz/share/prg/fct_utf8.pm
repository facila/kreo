# fct_utf8.pm version 1.31 Mars 2025 par Thierry Le Gall

use Encode;

sub fct_utf8 {
    return if $ENV{LANG} !~ /UTF-8/;
    my($fct,$ref_text)=@_;
    $$ref_text = &$fct('utf8',$$ref_text) }

sub fct_shell {
    my($ref_text,$command) = @_;
    chomp($$ref_text = `$command`);
    fct_utf8('decode',$ref_text) }

1;
