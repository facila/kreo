sub page_help {
    chomp(my $file = `ls -1 $dir{var}/help/$var{help}*`);
    return if &error('file_absent',$file);
    &kreo_help('help',$var{help});
    &kreo_file_all($file) }

sub page_project {
    my $dir = "$dir{data}/init";
    return if &error('dir_absent',$dir);
    my $page = $var{page};
    my @list;
    my $lg = 0;
    my $ls;
    &kreo_shell(\$ls,"ls -1 \"$dir\"");
    foreach(split/\n/,$ls) { $lg = length("$_") if length("$_") > $lg; push @list,"$_" }
    $lg .= 's';
    my $dsc;
    my $text = "\n";
    foreach(@list) {
       &kreo_shell(\$dsc,"grep project_dsc \"$dir{data}/init/$_\" | cut -f2 -d';'");
       $text .= sprintf " %-$lg : %-s\n" , $_ , $dsc }
    my $info = '';
    &kreo_page_text($page,\$text,\$info);
    &tag_project($page,\$text) }

sub page_arch {
    my $file = "$dir{data}/archive/$appli{project_name}";
    return if &error('file_absent',$file);
    my $page  = $var{page};
    my ($tag) = @_;
    my $text;
    &kreo_shell(\$text,"cat \"$file\"");
    &kreo_page_text($page,\$text,\" $file");
    &tag_file($page,\$text) if $tag }

sub page_note {
    my $file = "$dir{data}/note/$appli{project_name}";
    return if &error('note_absent',$file);
    my $page = $var{page};
    my $text;
    &kreo_shell(\$text,"cat \"$file\"");
    &kreo_page_text($page,\$text,\" $file") }

sub page_dir {
    my $dir = $init{current_dir};
    return if &error('dir_absent',$dir);
    my $page = $var{page};
    &kreo_variable('variable');
    &kreo_insert($widget{info},\" $dir",$fg{dir},$bg{dir});
    my $text = '';
    my $code = '';
       %code = ();
    &kreo_wait_start;
    &kreo_shell(\$text,"ls -alh \"$dir\"");
    &kreo_shell(\$code,"file --mime-encoding \"$dir/*\"");
    &kreo_insert($page{$page},\$text,$fg{text},$bg{text});
    foreach(split/\n/,$code ) { $code{$1} = $2 if /^(.*): *(.*)/ }
    &tag_dir($page,\$text);
    &kreo_wait_stop }

sub page_file {
    my $file = $init{current_file};
    return if &error('file_absent',"$file");
    my $page = $var{page};
    &histo($file);
    &kreo_variable('variable');
    &kreo_file_all($file);

    my $text = '';
    if ( -s $file ) {
       if ( $var{file_code} ne 'binary'           ) { &kreo_shell(\$text,"cat \"$file\"") }
       if ( $var{file_ext}  =~ /($env{archive})$/ ) { &kreo_shell(\$text,"cat \"$dir{var}/help/*archive*\"") } }
    &kreo_insert($page{$page},\$text,$fg{text},$bg{text}) }

sub page_find {
    $init{entry_include} = $widget{entry_include}->get();
    $init{entry_exclude} = $widget{entry_exclude}->get();
    return if &error('entry');

    $var{find_opt}  = '-s';
    $var{find_opt} .= 'i' if $init{entry_case};
    `cp /dev/null $tmp{tmp}`;

    &kreo_wait_start;
    my $fct = "find_$var{find}";
    if ( &$fct                    ) { &kreo_wait_stop; return }
    if ( &error('find',$tmp{tmp}) ) { &kreo_wait_stop; return }

    my ($text,$info);
    $text = $info = '';
    `cp $tmp{tmp} $tmp{find}`; # $tmp{find} utilisé pour rechercher dans la page Rechercher

    if    ( $var{find} eq 'file'             ) { $var{find_tag} = 0 }
    elsif ( $var{find} =~ /dir|project|name/ ) { $var{find_tag} = 1 }

    &kreo_shell    (\$text,"cat \"$tmp{find}\"");
    &kreo_page_text('find',\$text,\$info);
    &tag_file      ('find',\$text) if $var{find_tag};

    $text = &kreo_file_line($tmp{find});
    $text = " $text lignes dans $var{find_info}";
    &kreo_insert($widget{info},\$text,$fg{result},$bg{result});
    &kreo_wait_stop }

sub page_histo {
    my $page = 'histo';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat \"$tmp{histo}\"");
    &kreo_page_text($page,\$text,\$info);
    &tag_file      ($page,\$text) }

sub page_show {
    my $page = 'show';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat \"$tmp{show}\"");
    &kreo_page_text($page,\$text,\$info) }

sub page_debug {
    my $page = 'debug';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat \"$tmp{debug}\"");
    &kreo_page_text($page,\$text,\$info) }

sub page_var {
    &kreo_page_global('var') }

1;
