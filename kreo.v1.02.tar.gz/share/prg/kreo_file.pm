# fonctions 
# kreo_utf8
# kreo_shell
# kreo_var_init
# kreo_var_read
# kreo_var_write

use Encode;

sub kreo_utf8 {
    return if $env{lang} !~ /UTF-8/;
    my($ref_text)=@_;
    $$ref_text = &decode('utf8',$$ref_text) }

sub kreo_shell {
    my($ref_text,$command) = @_;
    chomp($$ref_text = `$command`);
    &kreo_utf8($ref_text) }

sub kreo_var_init {
    # initialisation des variables de $file
    my($file) = @_;
    my($t,$v,$x);
    open(FILE,"<$env{mode}",$file);
    while(<FILE>) {
       next if /^#|^\s*$/; # lignes ignorées
       ($t,$v,$x) = split/;/;
       $v =~ tr/ //d;
       $$t{$v} = $x }
    close FILE }

sub kreo_var_read {
    # initialisation des variables de $file dans %$name
    my($name,$file) = @_;
    my($x,$v);
    open(FILE,"<$env{mode}",$file);
    while(<FILE>) { ($x,$v) = split/;/; $$name{$x} = $v }
    close FILE }

sub kreo_var_write {
    # sauvegarde des variables de %$name dans $file
    my($name,$file) = @_;
    my $text;
    foreach( sort { $a cmp $b } keys %$name) { $text .= "$_;$$name{$_};\n" }
    open(FILE,">$env{mode}","$file");
    print FILE "$text";
    close FILE }

##########################################################################################
# fonctions texte et fichier
# kreo_file_ext
# kreo_file_code
# kreo_file_date
# kreo_file_line
# kreo_file_info
# kreo_file_all

sub kreo_file_ext {
    my($file) = @_;
    return if ! -e $file;
    my $ext  = ''; $ext = $1 if $file =~ /\.([^\.]*)$/;
    return $ext }

sub kreo_file_code {
    my($file) = @_;
    return if ! -e $file;
    chomp(my $code=`file -b --mime-encoding \"$file\"`);
    return $code }

sub kreo_file_date {
    my($file) = @_;
    return if ! -e $file;
    return 1 if `date +%Y%m%d` eq `date +%Y%m%d -r \"$file\"` }

sub kreo_file_line {
    my($file) = @_;
    return if ! -e $file;
    open FILE,$file;
    my @file = <FILE>;
    close FILE;
    return @file }

sub kreo_file_info {
    my($file) = @_;
    return if ! -e $file;

    $var{file_ext}  = &kreo_file_ext($file);
    $var{file_code} = &kreo_file_code($file);
    my $wc='' ; $wc = &kreo_file_line($file) if $var{file_code} ne 'binary';
    my $ls='' ; &kreo_shell(\$ls,"ls -l \"$file\"");

    my $text = " $var{file_code}";
    $text .= " : $wc lignes" if $wc;
    $text .= " : $ls";
    return $text }

sub kreo_file_all {
    my($file) = @_;
    return if ! -e $file;

    my $fg = $fg{file};
    my $bg = $bg{file};
    my $text = &kreo_file_info($file);
    my $date = &kreo_file_date($file);
    if    ( $var{file_ext}  =~ /($env{archive})$/ ) { $fg = $fg{archive} }
    elsif ( $var{file_code} eq 'binary'           ) { $fg = $fg{binary}  }
    if ( $date ) { ($fg,$bg) = ($bg,$fg) } # invers video si date = jour
    &kreo_insert($widget{info},\$text,$fg,$bg) }

1;
