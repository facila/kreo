#!/usr/bin/perl -w

# form_menu_tempo.pl version 1.02 Septembre 2023 par Thierry Le Gall

($form,$title,$nb) = @ARGV;
exit if ! $nb;

$text  = "g;1;2;text;        nom\n";
$text .= "g;1;3;text;      fonction\n";

foreach $i (1..$nb) {
   $l = $i + 2;
   $v ++;
   $out  .= "v$v;";
   $text  .= "g;$l;1;text;menu $i ;\n";
   $entry .= "g;$l;2;entry;v$v;20;";
   $entry .= "f;" if $i == 1; 
   $entry .= "\n";
   $v ++;
   $out  .= "v$v;";
   $entry .= "g;$l;3;entry;v$v;20;\n" }

$resu  = "# variables du formulaire\n\n";
$resu .= "form;title   ;Créer le menu $title;\n";
$resu .= "form;geometry;widthxheight+200+200;\n";
$resu .= "form;out     ;$out\n\n";

$resu .= "# widgets du formulaire\n\n";
$resu .= $text;
$l ++;
$resu .= "g;$l;1;text;\n\n";
$resu .= "$entry\n";
$l ++;
$resu .= "g;$l;2;button;Annuler;cancel;\n";
$resu .= "g;$l;3;button;Valider;valid;";

open(FILE,">",$form);
print FILE "$resu";
close FILE;
