#!/bin/bash

# version 0.05 Juillet 2021 par Thierry Le Gall
# script de modification d'un projet dans kreo

PROJECT=$1
DIR=$2
EXE=$3
DATA=$4
 
cd $DATA/project/$PROJECT
INIT=`egrep -v 'project_dir|project_exe' init`

{
echo "$INIT"
echo "project_dir;$DIR;"
echo "project_exe;$EXE;"
} > init
