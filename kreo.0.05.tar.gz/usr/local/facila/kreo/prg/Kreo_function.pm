sub histo {
    my ($file) = @_;
    `( echo $file ; grep -vx $file $tmp{histo} ) > $tmp{tmp}; cp $tmp{tmp} $tmp{histo}` }

sub info {
    my ($info,$msg) = @_;
    &kreo_insert($widget{info},\" $msg",$fg{$info},$bg{$info}) }

sub result {
    my ($msg,$file) = @_;
    $msg = $msg{"result_$msg"};
    &info('result',"$file : $msg") }

sub shell_verif {
    my $shell = "myverif.pl $_[0]";
    my $msg  = '';
    &kreo_shell(\$msg,"($shell) 2>&1");
    return if ! $msg;
    my $info = 'error';
    $info = 'result' if $msg =~ /OK/;
    `cp /dev/null $tmp{debug} 2>/dev/null`;
    print KREO_DEBUG "shell command : $shell\n";
    print KREO_DEBUG "$msg\n\n";
    &kreo_page_set('debug');
    &info($info,$msg);
    return 1 }

sub shell_error {
    my $shell = $_[0];
    my $msg   = '';
    &kreo_shell(\$msg,"($shell) 2>&1");
    return if ! $msg;
    `cp /dev/null $tmp{debug} 2>/dev/null`;
    print KREO_DEBUG "shell command : $shell\n";
    print KREO_DEBUG "$msg\n\n";
    &kreo_page_set('debug');
    &info('error',$msg);
    return 1 }

sub error {
    my ($msg,$file,$code,$ext) = @_;

    if    ( $msg =~ /absent/ && ! $file ) { } # error

    elsif ( $msg eq 'note_absent'    ) { return if   -f $file }
    elsif ( $msg eq 'find_empty'     ) { return if   -s $file }
    elsif ( $msg eq 'find'           ) { return if   -s $file }

    elsif ( $msg eq 'project_absent' ) { return if   -d $file }
    elsif ( $msg eq 'project_exist'  ) { return if ! -d $file }

    elsif ( $msg eq 'dir_absent'     ) { return if   -d $file }
    elsif ( $msg eq 'dir_exist'      ) { return if ! -d $file }

    elsif ( $msg eq 'file_absent'    ) { return if   -f $file }
    elsif ( $msg eq 'file_exist'     ) { return if ! -f $file }
    elsif ( $msg eq 'file_binary'    ) { return if $code ne 'binary' }
    elsif ( $msg eq 'file_open'      ) { return if $code ne 'binary' || ( $ext && $ext !~ /.($env{archive})$/ ) }

    elsif ( $msg eq 'entry'          ) { return if $var{entry_include} || $var{entry_exclude} }

    if ( $msg eq 'file_open' ) { $msg = 'file_binary' }

    my $error = $msg{"error_$msg"}; 
    if    ( $msg eq 'find'               ) { $error .= " : $var{entry_include} - $var{entry_exclude}" }
    elsif ( $msg !~ /absent|empty|entry/ ) { $error  = "$file : $error" }
    &info('error',$error);
    return 1 }

1;
