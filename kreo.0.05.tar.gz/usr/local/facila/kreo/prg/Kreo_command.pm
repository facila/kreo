#!/usr/bin/perl -w

# commandes utilisées par les menus , les boutons et les tags

our %msg;

############### Aide ###############
sub help {
    my($help) = @_;
    $var{help} = "$dir{var}/help/$help";
    &kreo_page_set('help') }

############### Fonction ###############
sub function_edit {
    &function_edit_save('edit') }

sub function_save {
    &function_edit_save('save') }

sub function_edit_save {
    my $page = $var{page};
    return if $page !~ /file|archive|note/;

    my $file;
    if    ( $page =~ /archive|note/ ) {
	  $file = "$var{project_data}/$page" }
    elsif ( $page eq 'file' ) {
          $file = $var{current_file}; 
          return if &error('file_absent',$var{current_file}); 
          return if &error('file_binary',$var{current_file},$var{file_code}) }

    my ($fct) = @_;
    if ( $fct eq 'edit' ) {
       &kreo_page_edit($page) }
    elsif ( $fct eq 'save' ) {
       &kreo_page_save($page,$file);
       &kreo_page_set($page) } }

sub function_exec {
    my $opt = $widget{entry_include}->get();
    `$var{project_exe} $opt&` }

sub form_create {
    my($form,$title,$nb) = (split/;/,`form.tk form_create`);
    return if ! $form || ! $title || ! $nb; 
    return if $nb > 9;
    $form =~ tr/ /_/;
    $form = "$dir{var}/form/$form";
    `form.pl $form "$title" $nb`;
    &file_select($form) }

sub appli_create {
    }

#######################################
sub kreo_form_menu {
    my($widget,$file,$link) = @_;
    $widget->update;
    my($x,$y) = $widget->pointerxy();
    my $command = `form_menu.tk $file $x $y`;
    return if ! $command;
    &$command($link) }    

############### Rechercher ###############
sub find {
    $var{find} = $_[0];
    $var{find} = 'project' if $var{find} =~ /Tk::Entry=HASH/;
    &kreo_page_set('find') }

##### Projet #####
sub project_clear {
    foreach(keys %var) {  $var{$_} = '' }
    &appli_reinit;
    &kreo_variable('variable');
    }

sub project_init {
    my $project = $_[0];
    $var{project_data} = "$dir{data}/project/$project";
    &kreo_var_read('init',"$var{project_data}/init");
    $widget{entry_include}->insert('end',$var{entry_include});
    $widget{entry_exclude}->insert('end',$var{entry_exclude});
    &kreo_variable('variable');
    &kreo_page_set('dir') }

sub project_select {
    if ( $var{project_name} ) {
       &kreo_var_write('init',"$var{project_data}/init");
       &project_clear }
    $var{project_name} = $_[0];
    &project_init($var{project_name}) }

sub project_create {
    my ($project,$dir,$exe) = (split/;/,`form.tk project_create`);
    return if ! $project || ! $dir || ! $exe;
    return if &error('project_exist',"$dir{data}/project/$project");
    `project_create.sh $project $dir $exe $dir{data}`;
    &project_select($project);
    &kreo_page_set('archive');
    &info('entry',$msg{result_project_create}) }

sub project_modify {
    my $project = $_[0];
    $project = $var{project_name} if ! $project;
    &project_select($project);
    my ($dir,$exe) = (split/;/,`form.tk project_modify $project $var{project_dir} $var{project_exe}`);
    return if ! $dir || ! $exe;
    `project_modify.sh $project $dir $exe $dir{data}`;
    $var{project_dir} = $dir;
    $var{project_exe} = $exe;
    &kreo_variable('variable') }

sub project_open {
    my $project = $_[0];
    $project = $var{project_name} if ! $project;
    return if ! $project;
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    return if &error('file_absent',"$dir/archive");
    `sudo $dir{share}/myopen.sh file $dir/archive &` }

sub project_copy {
    my $project = $_[0];
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    my $project_new = `form.tk entry_2 project_copy $project ''`;
    return if ! $project_new;
    return if &error('project_exist',$project_new);
    `cd $dir{data}/project; cp -rp $project $project_new`;
    &project_select($project_new) }

sub project_rename {
    my $project = $_[0];
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    my $project_new = `form.tk entry_2 project_rename $project ''`;
    return if ! $project_new;
    return if &error('project_exist',$project_new);
    `cd $dir{data}/project; mv $project $project_new`;
    &project_select($project_new) }

sub project_delete {
    my $project = $_[0];
    $project = $var{project_name} if ! $project;
    return if ! $project;
    my $dir = "$dir{data}/project/$project" ;
    return if &error('project_absent',$dir);
    return if ! `form.tk valid project_delete $project`;
    `rm -rf $dir`;
    &project_clear if $project eq $var{project_name};
    &kreo_page_set('project') }

############### Dossier ###############
sub dir_select {
    $var{current_dir} = $_[0];
    &kreo_page_set('dir');
    &histo($var{current_dir}) }

sub dir_open {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{current_dir} if ! $dir;
    return if &error('dir_absent',$dir);
    `sudo $dir{share}/myopen.sh dir $dir &`;
    &histo($dir) }

sub dir_create {
    &kreo_page_set('dir');
    my $dir = `form.tk entry_1 dir_create $var{current_dir}`;
    return if ! $dir;
    return if &error('file_exist',$dir);
    return if &error('dir_exist' ,$dir);
    return if &shell_error("mkdir $dir");
    $var{current_dir} = $dir;
    &kreo_page_set('dir') }

sub dir_copy {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `form.tk entry_2 dir_copy $dir "$dir.old"`;
    return if ! $dir_new;
    return if &shell_error("cp -pR $dir $dir_new");
    $var{current_dir} = $dir_new;
    &kreo_page_set('dir') }

sub dir_move {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `dirname $dir`;
    chomp($dir_new = `dirname $dir_new`);
    $dir_new = `form.tk entry_2 dir_move $dir $dir_new`;
    return if ! $dir_new;
    return if &shell_error("mv $dir $dir_new");
    $var{current_dir} = $dir_new;
    &kreo_page_set('dir') }

sub dir_rename {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `form.tk entry_2 dir_rename $dir "$dir.old"`;
    return if ! $dir_new;
    return if &shell_error("mv $dir $dir_new");
    $var{current_dir} = $dir_new;
    &kreo_page_set('dir') }

sub dir_delete {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{current_dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    return if ! `form.tk valid dir_delete $dir`;
    return if &shell_error("rmdir $dir");
    if ( $dir eq $var{current_dir} ) {
       chomp( $var{current_dir} = `dirname $dir` );
       $var{current_file} = '' }
    &kreo_page_set('dir') }

############### Fichier ###############
sub file_select {
    $var{current_file} = $_[0];
    &kreo_shell(\$var{current_dir},"dirname $var{current_file}");
    &kreo_page_set('file') }

sub file_open {
    my $file = $_[0];
    $file = $var{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $ext  = &kreo_file_ext ($file);
    my $code = &kreo_file_code($file);
    return if &error('file_open',$file,$code,$ext);
    `sudo $dir{share}/myopen.sh file $file &`;
    &histo($file) }

sub file_create {
    &kreo_page_set('dir');
    my $file = `form.tk entry_1 file_create $var{current_dir}`;
    return if ! $file;
    return if &error('file_exist',$file);
    return if &error('dir_exist' ,$file);
    return if &shell_error("echo ' ' > $file");
    $var{current_file} = $file;
    &kreo_page_set('dir') }

sub file_copy {
    my $file = $_[0];
    $file = $var{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form.tk entry_2 file_copy $file "$file.old"`;
    return if ! $file_new;
    return if &shell_error("cp -p $file $file_new");
    $var{current_file} = $file_new;
    &kreo_page_set('file') }

sub file_move {
    my $file = $_[0];
    $file = $var{current_file} if ! $file;
    return if &error('file_absent',$file);
    chomp(my $dir_new = `dirname $file`);
    $dir_new = `form.tk entry_2 file_move $file $dir_new`;
    return if ! $dir_new;
    return if &shell_error("mv $file $dir_new");
    chomp($file = `basename $file`);
    $var{current_dir}  = $dir_new;
    $var{current_file} = "$dir_new/$file";
    &kreo_page_set('dir') }

sub file_rename {
    my $file = $_[0];
    $file = $var{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form.tk entry_2 file_rename $file "$file.old"`;
    return if ! $file_new;
    return if &shell_error("mv $file $file_new");
    $var{current_file} = $file_new;
    &kreo_page_set('file') }

sub file_delete {
    my $file = $_[0];
    $file = $var{current_file} if ! $file;
    return if &error('file_absent',$file);
    return if ! `form.tk valid file_delete $file`;
    return if &shell_error("rm $file");
    $var{current_file} = '' if $file eq $var{current_file};
    &kreo_page_set('dir') }

sub file_verif {
    my $file = $_[0];
    $file = $var{current_file} if ! $file;
    return if &error('file_absent',$file);
    &shell_verif($file) }

sub file_change {
    my($fct,$file) = @_;
    my $var = `form.tk $fct $file`;
    return if ! $var;
    return if &shell_error("$fct $var $file");
    &kreo_page_set('dir') }

############### Archive ###############
sub archive_select {
    $var{current_dir}  = "$dir{facila}/archive";
    $var{current_file} = '';
    &kreo_page_set('dir') }

sub archive_create {
    return if &error('project_absent',$var{project_dir});
    $var{current_dir}  = "$dir{facila}/archive";
    $var{current_file} = `$dir{prg}/archive_create.sh $var{project_name} $var{project_data} $var{current_dir}`;
    &kreo_page_set('file') }

############### Quitter ###############
# le menu Quitter utilise les commandes appli_ dans Kreo_appli.pm

1;
