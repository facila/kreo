#!/usr/bin/perl

chdir '/usr/local/facila' ;
`chown -R root:root kreo share`;
`chmod -R 755       kreo share`;

foreach(`ls -lR kreo`) {
   if    ( /^(kreo.(form|prg).*):$/ ) { $dir = $1; $mod = '744' } 
   elsif ( /^(kreo.*):$/            ) { $dir = $1; $mod = '644' } 

   if ( /^-/ ) { ($file) = (split/\s+/)[8]; `chmod $mod $dir/$file` } }
