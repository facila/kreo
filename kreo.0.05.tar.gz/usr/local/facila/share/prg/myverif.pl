#!/usr/bin/perl -w

($file) = @ARGV;

$type = $1 if $file =~ /\.(.*)/; 
exit if ! $type;

if ( $type =~ /^(pl|pm|tk)$/ ) { `perl -c $file` }
