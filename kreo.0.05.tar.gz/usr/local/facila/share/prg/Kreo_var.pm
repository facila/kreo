# Kreo_var.pm version 0.05 Juillet 2021 par Thierry Le Gall

# initialisation des variables de $file
sub kreo_var_init {
    my($file) = @_;
    my($t,$v,$x);
    open(FILE,"<$env{mode}",$file);
    while(<FILE>) {
       next if /^#|^\s*$/; # lignes ignorées
       ($t,$v,$x) = split/;/;
       $v =~ tr/ //d;
       $$t{$v} = $x }
    close FILE }

# initialisation des variables de $file dans %$name et %var
sub kreo_var_read {
    my($name,$file) = @_;
    my($x,$v);
    open(FILE,"<$env{mode}",$file);
    while(<FILE>) { ($x,$v) = split/;/; $$name{$x} = $var{$x} = $v }
    close FILE }

# sauvegarde des variables de %$name avec les valeurs de %var dans $file
sub kreo_var_write {
    my($name,$file) = @_;
    my $text;
    foreach( sort { $a cmp $b } keys %$name) { $text .= "$_;$var{$_};\n" }
    open(FILE,">$env{mode}",$file);
    print FILE "$text";
    close FILE }

1;
