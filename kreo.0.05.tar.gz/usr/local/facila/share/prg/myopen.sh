#!/bin/bash

proc_dir ()
   {
   cd $DIR
   COM="echo; ls --color=auto -alF; echo; bash"

   #xterm -geometry $GEO -bg $BG -fg $FG -fn $FONT -T $DIR -e "$COM"
   gnome-terminal --geometry=$GEO --working-directory=$DIR -- bash -c "$COM" &
   #gnome-terminal --geometry=$GEO --working-directory=$DIR -- bash -c "echo; ls --color=auto -alF; echo; bash" &
   }

proc_file ()
   {
   COM=/usr/bin/vim

   # gvim -geometry $GEO -bg $BG -fg $FG $FILE
   # xterm -geometry $GEO  -title $FILE -bg $BG -fg $FG -fn $FONT -e $COM $FILE
   gnome-terminal --geometry=$GEO --title $FILE -- $COM $FILE
   }

 GEO=132x32+100+100
  BG=black
  FG=white
FONT=-*-fixed-*-*-*-*-12-*-*-*-*-*-*-*
FONT=-misc-fixed-medium-r-normal–18-120-100-100-c-90-iso10646-1

case $1 in
 dir)  DIR=$2 ; proc_dir  ;;
file) FILE=$2 ; proc_file ;;
esac
