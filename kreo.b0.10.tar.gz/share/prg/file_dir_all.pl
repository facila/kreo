#!/usr/bin/perl -w

# file_dir.pl version 0.10 Janvier 2023 par Thierry Le Gall
# recherche dans $file des fichiers du répertoire $dir

$share = "$ENV{FACILA}/share";
require "$share/prg/file_dir.pm";

$file = "$share/data/f111";
$dir  = "$ENV{FACILA}/plan/";

%list = ();
&list_dir(\%list,$dir);

for $i ( 1 .. 10000 ) {
    %source = ();
    &source_file($file,\%source);

    %find = ();
    &find_file(\%source,\%list,\%find);

    %result = ();
    &result_file(\%list,\%find,\%result);

    foreach $f (keys %result) {
    #   print "f:$f\n";
       foreach $line (`cat $f`) {
          chomp $line;
          delete $source{$line} } }

    #foreach $line (keys %source) {
    #   print "l:$line\n" }
    }

print "\n";
