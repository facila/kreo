#!/usr/bin/perl -w

sub project_exec {
    my $opt = $widget{entry_include}->get();
    system("$init{project_exe} $opt") }

sub project_clear {
    $appli{project_name} = '';
    foreach(keys %init) { $init{$_} = '' }
    &appli_reinit;
    &kreo_variable('variable') }

sub project_init {
    my $project = $_[0];
    &kreo_var_read('init',"$dir{data}/init/$project");
    $widget{entry_include}->insert('end',$init{entry_include});
    $widget{entry_exclude}->insert('end',$init{entry_exclude});
    &kreo_variable('variable');
    my $page = 'arch';
    $page = 'dir' if $init{current_dir};
    &kreo_page_set($page) }

sub project_select {
    my $project = $appli{project_name};
    if ( $project ) {
       &kreo_var_write('init',"$dir{data}/init/$project");
       &project_clear }
    $appli{project_name} = $_[0];
    &project_init($appli{project_name}) }

sub project_create {
    my ($project,$dir,$exe,$dsc) = (split/;/,`form.tk project_create`);
    return if ! $project;
    return if &error('project_exist',"$dir{data}/init/$project");
    `project.sh create $project "$dir" "$exe" "$dsc"`;
    &project_select($project);
    &kreo_page_set('arch');
    &info('entry',$msg{result_project_create}) }

sub project_modify {
    my $project = $_[0];
    $project = $appli{project_name} if ! $project;
    return if &error('project_absent',"$dir{data}/init/$project");
    &project_select($project);
    my $form = `form.tk project_modify $project "$init{project_dir}" "$init{project_exe}" "$init{project_dsc}"`;
    return if ! $form;
    my ($dir,$exe,$dsc) = split/;/,$form;
    `project.sh modify $project "$dir" "$exe" "$dsc"`;
    $init{project_dir} = $dir;
    $init{project_exe} = $exe;
    $init{project_dsc} = $dsc;
    &kreo_variable('variable') }

sub project_rename {
    my $project = $_[0];
    return if &error('project_absent',"$dir{data}/init/$project");
    my $project_new = `form.tk entry_2 project_rename $project ''`;
    return if ! $project_new;
    return if &error('project_exist',$project_new);
    `project.sh rename $project $project_new`;
    $appli{project_name} = $project_new;
    &project_init($project_new) }

sub project_delete {
    my $project = $_[0];
    return if ! $project;
    return if &error('project_absent',"$dir{data}/init/$project");
    return if ! `form.tk valid project_delete $project`;
    `project.sh delete $project`;
    &project_clear if $project eq $appli{project_name};
    &kreo_page_set('project') }

sub project_right {
    return if ! $appli{project_name};
    chomp(my $file = `dirname $init{project_exe}`);
    $file .= "/sys_right.pl";
    return if &error('file_absent',$file);
    system($file);
    &kreo_page($var{page});
    &kreo_insert($widget{info},\" $appli{project_name} : $msg{right}",$fg{result},$bg{result}) }

1;
