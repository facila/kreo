sub file_fct {
    my $page = $var{page};
    return 1 if $page !~ /file|arch|note/;

    my $file;
    if    ( $page eq 'file' ) { $file = $init{current_file}; return 1 if &error('file_binary',$file,$var{file_code}) }
    elsif ( $page eq 'arch' ) { $file = "$dir{data}/archive/$appli{project_name}" } 
    elsif ( $page eq 'note' ) { $file = "$dir{data}/note/$appli{project_name}" }
    return 1 if &error('file_absent',$file);

    &kreo_page_set($page);
    my($fct) = @_;
    if    ( $fct eq 'edit'  ) { return if   $var{"edit_$page"}; $var{"edit_$page"} = 1; &kreo_page_edit($page) }
    elsif ( $fct eq 'save'  ) { return if ! $var{"edit_$page"}; $var{"edit_$page"} = 0; &kreo_page_save($page,$file); &kreo_page_set($page) }
    elsif ( $fct eq 'close' ) { return if ! $var{"edit_$page"}; $var{"edit_$page"} = 0;                               &kreo_page_set($page) } }

sub file_edit  { &file_fct('edit') }
sub file_save  { &file_fct('save') }
sub file_close { &file_fct('close') }

sub file_select {
    return if &error('file_edit',$init{current_file});
    my $file = $_[0];
    return if &error('file_absent',$file);
    $init{current_file} = $file;
    &kreo_shell(\$init{current_dir},"dirname \"$file\"");
    &kreo_page_set('file') }

sub file_open {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $ext  = &kreo_file_ext ($file);
    my $code = &kreo_file_code($file);
    return if &error('file_open',$file,$code,$ext);
    &open('file',"$file");
    &histo($file) }

sub file_create {
    &kreo_page_set('dir');
    my $file = `form.tk entry_1 file_create "$init{current_dir}"`;
    return if ! $file;
    return if &error('file_exist',$file);
    return if &error('dir_exist' ,$file);
    return if &shell_error("echo ' ' > \"$file\"");
    $init{current_file} = $file;
    &kreo_page_set('dir') }

sub file_stock {
    my $stock = $appli{stock};
    return if &error('dir_absent',$stock);
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    return if &shell_error("cp -p \"$file\" \"$stock\"");
    $init{current_dir}  = $stock;
    &kreo_page_set('dir') }

sub file_copy {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form.tk entry_2 file_copy "$file" "$file"`;
    return if ! $file_new;
    return if &shell_error("cp -p \"$file\" \"$file_new\"");
    $init{current_file} = $file_new;
    &kreo_page_set('file') }

sub file_move {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    chomp(my $dir_new = `dirname "$file"`);
    $dir_new = `form.tk entry_2 file_move "$file" "$dir_new"`;
    return if ! $dir_new;
    return if &shell_error("mv \"$file\" \"$dir_new\"");
    chomp($file = `basename "$file"`);
    $init{current_dir}  = $dir_new;
    $init{current_file} = "$dir_new/$file";
    &kreo_page_set('dir') }

sub file_rename {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form.tk entry_2 file_rename "$file" "$file"`;
    return if ! $file_new;
    return if &shell_error("mv \"$file\" \"$file_new\"");
    $init{current_file} = $file_new;
    &kreo_page_set('file') }

sub file_delete {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    return if ! `form.tk valid file_delete "$file"`;
 #  return if &shell_error("rm \"$file\""); # ancienne fonction delete : suppression du fichier
    return if &save('delete',$file); # delete deplace le fichier dans save/delete
    $init{current_file} = '' if $file eq $init{current_file};
    &kreo_page_set('dir') }

sub file_verif {
    my $file = $_[0];
    $file = $init{current_file} if ! $file;
    return if &error('file_absent',$file);
    &shell_verif($file) }

sub file_change {
    my($fct,$file) = @_;
    my $var = `form.tk $fct "$file"`;
    return if ! $var;
    return if &shell_error("$fct \"$var\" \"$file\"");
    &kreo_page_set('dir') }

1;
