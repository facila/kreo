sub archive_open {
    my $project = $_[0];
    $project = $appli{project_name} if ! $project;
    return if ! $project;
    return if &error('project_absent',"$dir{data}/init/$project");
    my $archive = "$dir{data}/archive/$project";
    return if &error('file_absent',$archive);
    &open('file',$archive) }

sub archive_select {
    $init{current_dir}  = "$appli{save}/archive";
    $init{current_file} = '';
    &kreo_page_set('dir') }

sub archive_create {
    my $project = $appli{project_name};
    return if &error('project_absent',"$dir{data}/init/$project");
    chomp(my $date = `date +%y%m%d_%H%M`);
    my $archive = "$dir{data}/archive/$project";
    my $dir     = "$appli{save}/archive";
    my $tar     = "$dir/$project.$date.tar.gz";
    return if &shell_error("tar -T $archive -czf $tar 2> /dev/null");
    &archive_init($dir,$tar) }

sub version_create {
    my $project = $appli{project_name};
    return if &error('project_absent',"$dir{data}/init/$project");
    chomp(my $date = `date +%y%m%d_%H%M`);
    my $archive  = "$dir{data}/archive/$project";
    my $dir      = "$appli{save}/version";
    my $tar      = "$dir/$project.$date.tar.gz";
    my $src_dir  = '';
    my $src_file = '';
    foreach(`cat $archive`) {
       chomp;
       if ( /($env{facila})\/(.*)/ ) { $src_file .= "$2 "; $src_dir = $1 }
       else                          { $src_file .= "$_ " } }
    return if ! $src_file || ! $src_dir;
    return if &shell_error("tar -C $src_dir $src_file -czf $tar 2> /dev/null");
    &archive_init($dir,$tar) }

sub archive_extract {
    my $project = $appli{project_name};
    return if &error('project_absent',"$dir{data}/init/$project");
    return if &error('project_extract',$project); # extract impossible pour kreo
    # création d'une nouvelle archive avant l'extract
    &archive_create;
    # déplacement d'une ancienne version dans save/old
    foreach (`cat "$dir{data}/archive/$project"`) { chomp; return if &save('old',"$_") }
    # extract de l'archive séléctionnée
    my $dir = "$appli{save}/archive";
    my $tar = $_[0];
    return if &shell_error("cd /; tar -xzf $tar 2> /dev/null");
    &archive_init($dir,$tar) }

sub archive_init {
    my($dir,$tar) = @_;
    $init{current_dir}  = $dir;
    $init{current_file} = $tar;
    &kreo_page_set('dir') }

sub save {
    my ($dir,$file) = @_; # $file est un fichier ou un répertoire
    chomp(my $date = `date +%y%m%d_%H%M`);
    my $save = $file;
    $save = $1 if $file =~ /$env{facila}\/(.*)/;
    $dir  = "$appli{save}/$dir";
    return 1 if &shell_error("mkdir -p \"$dir/$save\"");            # création des répertoires contenus dans $save
    return 1 if &shell_error("rmdir    \"$dir/$save\"");            # suppression du dernier repertoire de $save
    return 1 if &shell_error("mv \"$file\" \"$dir/$save.$date\"") } # déplacement de $file dans $dir

1;
