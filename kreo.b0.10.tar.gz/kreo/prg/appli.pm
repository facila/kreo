sub appli_init {
    &kreo_var_read('appli',"$dir{data}/appli");
    `printf "$appli{save}\n$appli{stock}\n" > $tmp{histo}`;
    foreach(`cd $dir{var}/help; ls -1 | grep -v _0_`) { $help{$2} = $1 if /^(\d+)_(\d+)_/ }
    &project_init($appli{project_name}) if $appli{project_name};
    $widget{entry_include}->focus }

sub appli_escape {
    if ( $var{page} eq 'help' ) { &help(0) }
    else { &kreo_page($var{page}) } }

sub appli_grep {
    # >> $tmp{tmp} car appli_grep peut etre appelé plusieurs fois sur la recherche dans le projet
    `$dir{share}/prg/mygrep "$var{find_opt}" "$init{entry_include}" "$init{entry_exclude}" "$var{find_file}" 2>/dev/null >> $tmp{tmp}` }

sub appli_error {
    if ( &error('file_edit',$init{current_file}                      ) ) { &kreo_page_set('file'); return 1 } 
    if ( &error('arch_edit',"$dir{data}/archive/$appli{project_name}") ) { &kreo_page_set('arch'); return 1 } 
    if ( &error('note_edit',"$dir{data}/note/$appli{project_name}"   ) ) { &kreo_page_set('note'); return 1 } }

sub appli_exit {
    return if &appli_error;
    $init{entry_include} = $widget{entry_include}->get();
    $init{entry_exclude} = $widget{entry_exclude}->get();
    &kreo_var_write('appli',"$dir{data}/appli");
    &kreo_var_write('init' ,"$dir{data}/init/$appli{project_name}") if $appli{project_name};
    unlink <$tmp{tmp}*>;
    exit }

sub appli_reinit {
    return if &appli_error;
    $init{entry_include} = $init{entry_exclude} = '';
    $init{entry_case} = 1;
    $widget{entry_include}->focus;
    $widget{entry_include}->delete('0.0','end');
    $widget{entry_exclude}->delete('0.0','end');
    `printf "$appli{save}\n$appli{stock}\n" > $tmp{histo}`;
    `cp /dev/null $tmp{find}`;
    `cp /dev/null $tmp{debug}`;
    &kreo_page_clear('find');
    &kreo_page_clear('file');
    $init{current_dir}  = $init{project_dir};
    $init{current_file} = $init{project_exe};
    &kreo_page_set('dir') }

sub appli_restart {
    return if &appli_error;
    system("$dir{prg}/$env{appli} $env{user}");
    &appli_exit }

1;
