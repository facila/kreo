use strict;

sub init {
    our %var;
    $var{file} = $_[0] }

sub reset {
    our %var;
    $var{user_in}  = $var{user}  = `stat --printf=%U $var{file}`;
    $var{group_in} = $var{group} = `stat --printf=%G $var{file}`;
    $var{in} = $var{out} = "$var{user}:$var{group}" }

sub browse {
    my @list;
    if    ( $_[0] =~ /user/  ) { for(`sort /etc/passwd | cut -f1 -d:`) { chomp; push @list,$_ } }
    elsif ( $_[0] =~ /group/ ) { for(`sort /etc/group  | cut -f1 -d:`) { chomp; push @list,$_ } }
    return \@list }

sub result {
    our %var;
    $var{out} = "$var{user}:$var{group}";
    print $var{out} if $var{out} ne $var{in};
    exit }

1;
