#!/bin/bash

# version 0.04 08/06/2021 par Thierry Le Gall
# script de création d'une archive dans kreo

PROJECT=$1
   DATA=$2
    DIR=$3

DATE=`date +%y%m%d_%H%M`
 TAR=$PROJECT.$DATE.tar.gz
FILE=`cat $DATA/archive | tr "\n" " "`

printf "$DIR/$TAR"

cd /
tar -czf $TAR $FILE 2> /dev/null
mv $TAR $DIR
chmod -R 600 $DIR

# lire le contenu      : cd / ; tar -tzf $DIR/$TAR
# restaurer l'ensemble : cd / ; tar -xzf $DIR/$TAR
