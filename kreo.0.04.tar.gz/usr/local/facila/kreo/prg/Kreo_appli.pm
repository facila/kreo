sub appli_init {
    &kreo_var_read('appli',"$dir{data}/appli");
    $var{help} = "$dir{var}/help/$var{help}";
    &project_init($var{project_name}) if $var{project_name};
    $widget{entry_include}->focus }

sub appli_escape {
    &kreo_page($var{page}) }

sub appli_grep {
    # >> $tmp{tmp} car appli_grep peut etre appelé plusieurs fois sur la recherche dans le projet
    `$dir{share}/mygrep.sh "$var{find_opt}" "$var{entry_include}" "$var{entry_exclude}" "$var{find_file}" 2>/dev/null >> $tmp{tmp}` }

sub appli_exit {
    $var{entry_include} = $widget{entry_include}->get();
    $var{entry_exclude} = $widget{entry_exclude}->get();
    &kreo_var_write('appli',"$dir{data}/appli");
    &kreo_var_write('init' ,"$var{project_data}/init") if $var{project_name};
    unlink <$tmp{tmp}*>;
    exit }

sub appli_reinit {
    $var{entry_include} = $var{entry_exclude} = '';
    $var{entry_case} = 1;
    $widget{entry_include}->focus;
    $widget{entry_include}->delete('0.0','end');
    $widget{entry_exclude}->delete('0.0','end');
    `cp /dev/null $tmp{histo}`;
    `cp /dev/null $tmp{find}`;
    `cp /dev/null $tmp{debug}`;
    &kreo_page_clear('find');
    &kreo_page_clear('file');
    $var{current_dir}  = $var{project_dir};
    $var{current_file} = '';
    &kreo_page_set('dir') }

sub appli_restart {
    system("$dir{prg}/$env{appli} $env{user} &");
    &appli_exit }

1;
