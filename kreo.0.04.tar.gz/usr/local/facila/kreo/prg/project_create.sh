#!/bin/bash

# version 0.04 08/06/2021 par Thierry Le Gall
# script de création d'un projet dans kreo

PROJECT=$1
DIR=$2
EXE=$3
DATA=$4

if [ ! -d $DIR ]
then mkdir $DIR
     cd $DIR
     mkdir data prg var
fi

{
echo "#!/bin/bash"
echo
echo "# ligne à remplacer par le fichier de démarrage de l'application"
echo $PROJECT
} > $EXE
chmod +x $EXE

   cd $DATA/project
mkdir $PROJECT
   cd $PROJECT
 echo $DIR > archive
 echo note > note
 
{
 cat $DATA/init 
echo "project_dir;$DIR;"
echo "project_exe;$EXE;"
} > init
