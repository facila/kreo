#!/bin/bash

set -vx

OPTIONS=$1
PATTERN=$2
FILTER=$3
LIST=$4

[ "$LIST" = '' ] && exit

#echo $LIST | while read FILE ; do echo $FILE ; done
#ls -dR /usr/local/facila/kreo/*
#while read DIR

FILE=$LIST

# echo  then grep -R  $OPTIONS "$PATTERN" $FILE


if   [ "$PATTERN" != '' -a "$FILTER"  = '' ] ; then grep -R  $OPTIONS "$PATTERN" $FILE
elif [ "$PATTERN"  = '' -a "$FILTER" != '' ] ; then grep -Rv $OPTIONS "$FILTER"  $FILE
elif [ "$PATTERN" != '' -a "$FILTER" != '' ] ; then grep -R  $OPTIONS "$PATTERN" $FILE | grep -v "$FILTER"
fi
