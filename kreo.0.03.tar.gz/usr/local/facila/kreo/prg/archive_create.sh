#!/bin/bash

 FACILA=/usr/local/facila
PROJECT=$1
   DATE=`date +%y%m%d_%H%M`
    TAR=$PROJECT.$DATE.tar.gz
    DIR=$FACILA/kreo/data/project
   FILE=`cat $DIR/$PROJECT | tr "\n" " "`
ARCHIVE=$FACILA/archive

printf "$ARCHIVE/$TAR"

cd /
tar -czf $TAR $FILE 2> /dev/null
mv $TAR $ARCHIVE
chmod -R 600 $ARCHIVE

# lire le contenu      : cd / ; tar -tzf $ARCHIVE
# restaurer l'ensemble : cd / ; tar -xzf $ARCHIVE
