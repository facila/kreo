# commandes utilisées par les menus , les boutons et les tags

sub info {
    my ($info,$msg) = @_;
    &kreo_insert($widget{info},\" $msg",$fg{$info},$bg{$info}) }

sub error {
    my ($msg,$file,$code,$ext) = @_;

    if    ( $msg =~ /absent/ && ! $file ) { } # error

    elsif ( $msg eq 'note_absent'    ) { return if   -f $file }
    elsif ( $msg eq 'find_empty'     ) { return if   -s $file }
    elsif ( $msg eq 'find'           ) { return if   -s $file }

    elsif ( $msg eq 'project_absent' ) { return if   -f $file }
    elsif ( $msg eq 'project_exist'  ) { return if ! -f $file }

    elsif ( $msg eq 'dir_absent'     ) { return if   -d $file }
    elsif ( $msg eq 'dir_exist'      ) { return if ! -d $file }

    elsif ( $msg eq 'file_absent'    ) { return if   -f $file }
    elsif ( $msg eq 'file_exist'     ) { return if ! -f $file }
    elsif ( $msg eq 'file_binary'    ) { return if $code ne 'binary' }
    elsif ( $msg eq 'file_open'      ) { return if $code ne 'binary' || $ext eq 'gz' }

    elsif ( $msg eq 'entry'          ) { return if $var{entry_include} || $var{entry_exclude} }

    if ( $msg eq 'file_open' ) { $msg = 'file_binary' }

    my $error = $msg{"error_$msg"}; 
    if    ( $msg eq 'find'               ) { $error .= " : $var{entry_include} - $var{entry_exclude}" }
    elsif ( $msg !~ /absent|empty|entry/ ) { $error  = "$file : $error" }
    &info('error',$error);
    return 1 }

sub result {
    my ($msg,$file) = @_;
    $msg = $msg{"result_$msg"};
    &info('result',"$file : $msg") }

sub shell_error {
    my $error = '';
    &kreo_shell(\$error,"($_[0]) 2>&1");
    return if ! $error;
    print KREO_DEBUG "$_[0]\n";
    print KREO_DEBUG "$error\n";
    &info('error',$error);
    return 1 }

##### Aide #####
sub help {
    my($help) = @_;
    $file{help} = "$dir{var}/help/$help";
    &kreo_page_set('help') }

##### Fonction #####
sub function_edit {
    &function_edit_save('edit') }

sub function_save {
    &function_edit_save('save') }

sub function_edit_save {
    my $page = $var{page};
    return if $page !~ /note|project|file/;

    my $file;
    if    ( $page eq 'note'    ) { $file = "$dir{data}/note/$var{project}" }
    elsif ( $page eq 'project' ) { $file = "$dir{data}/project/$var{project}" }
    elsif ( $page eq 'file'    ) { $file = $var{file}; 
                                   return if &error('file_absent',$var{file}); 
                                   return if &error('file_binary',$var{file},$var{file_code}) }
    my ($fct) = @_;
    if ( $fct eq 'edit' ) {
       &kreo_page_edit($page) }
    elsif ( $fct eq 'save' ) {
       &kreo_page_save($page,$file);
       &kreo_page_set($page) } }

sub function_test {
    my $dir = "$dir{facila}/$var{project}/prg";
    my $opt = $widget{entry_include}->get();
    system("$dir/$var{project} $opt&") }

sub function_create {
    }

##### Rechercher #####
sub find {
    $var{find} = $_[0];
    $var{find} = 'project' if $var{find} =~ /Tk::Entry=HASH/;
    &kreo_page_set('find') }

##### Projet #####
sub project_select {
    $var{dir}      = '';
    $var{file}     = '';
    $var{project}  = $_[0];
    $file{note}    = "$dir{data}/note/$var{project}";
    $file{project} = "$dir{data}/project/$var{project}";
    `cp /dev/null $tmp{histo}`;
    `cp /dev/null $tmp{find}`;
    &kreo_variable('variable');
    &kreo_page_clear('dir');
    &kreo_page_clear('file');
    &kreo_page_clear('find');
    &kreo_page_set('project') }

sub project_open {
    my $project = $_[0];
    $project = $var{project} if ! $project;
    my $file = "$dir{data}/project/$project";
    return if &error('project_absent',$file);
    system("sudo $dir{prg}/file_open.sh $file &") }

sub project_create {
    my $project = `form_dir_file.tk project_create`;
    return if ! $project;
    return if &error('project_exist',$project);
    `project_create.sh $dir{facila} $project`;
    &project_select($project);
    $var{project} = $project;
    $var{file} = $var{dir} = '';
    &kreo_variable('variable');
    &info('entry',$msg{result_project_create}) }

sub project_delete {
    my $project = $_[0];
    $project = $var{project} if ! $project;
    my $file = "$dir{data}/project/$project";
    return if &error('project_absent',$file);
    $project = `form_dir_file.tk project_delete $project`;
    return if ! $project;
    `project_delete.sh $dir{facila} $project`;
    $file{note} = $file{project} = $var{project} = $var{file} = $var{dir} = '';
    &kreo_variable('variable');
    &kreo_page_clear('project');
    &kreo_page_set('list') }

sub project_copy {
    my $file = "$dir{data}/project/$var{project}";
    return if &error('project_absent',$file);
    my $project = `form_dir_file.tk project_copy $var{project}`;
    return if ! $project;
    return if &error('project_exist',$project);
    `cd "$dir{facila}"      ; cp -Rp $var{project} $project`;
    `cd "$dir{data}/project"; cp  -p $var{project} $project` }

sub project_rename {
    my $file = "$dir{data}/project/$var{project}";
    return if &error('project_absent',$file);
    my $project = `form_dir_file.tk project_rename $var{project}`;
    return if ! $project;
    return if &error('project_exist',$project);
    `cd "$dir{facila}"      ; mv $var{project} $project`;
    `cd "$dir{data}/project"; mv $var{project} $project`;
    $var{project} = $project;
    $var{file} = $var{dir} = '';
    &kreo_variable('variable');
    &kreo_page_set('project') }

##### Dossier #####
sub dir_select {
    $var{dir} = $_[0];
    &kreo_page_set('dir') }

sub dir_open {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{dir} if ! $dir;
    return if &error('dir_absent',$dir);
    system("sudo $dir{prg}/dir_open.sh $dir &") }

sub dir_create {
    &kreo_page_set('dir');
    my $dir = `form_dir_file.tk dir_create $var{dir}`;
    return if ! $dir;
    return if &error('file_exist',$dir);
    return if &error('dir_exist' ,$dir);
    return if &shell_error("mkdir $dir");
    $var{dir} = $dir;
    &kreo_page_set('dir') }

sub dir_delete {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    $dir = `form_dir_file.tk dir_delete $dir`;
    return if ! $dir;
    return if &shell_error("rmdir $dir");
    if ( $dir eq $var{dir} ) {
       chomp( $var{dir} = `dirname $dir` );
       $var{file} = '' }
    &kreo_page_set('dir') }

sub dir_copy {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `form_dir_file.tk dir_copy $dir`;
    return if ! $dir_new;
    return if &shell_error("cp -pR $dir $dir_new");
    $var{dir} = $dir_new;
    &kreo_page_set('dir') }

sub dir_rename {
    &kreo_page_set('dir');
    my $dir = $_[0];
    $dir = $var{dir} if ! $dir;
    return if $dir eq '/';
    return if &error('dir_absent',$dir);
    my $dir_new = `form_dir_file.tk dir_rename $dir`;
    return if ! $dir_new;
    return if &shell_error("mv $dir $dir_new");
    $var{dir} = $dir_new;
    &kreo_page_set('dir') }

##### Fichier #####
sub file_select {
    $var{file} = $_[0];
    &kreo_shell(\$var{dir},"dirname $var{file}");
    &kreo_page_set('file') }

sub file_open {
    my $file = $_[0];
    $file = $var{file} if ! $file;
    return if &error('file_absent',$file);
    my $ext  = &kreo_file_ext ($file);
    my $code = &kreo_file_code($file);
    return if &error('file_open',$file,$code,$ext);
    system("sudo $dir{prg}/file_open.sh $file &") }

sub file_create {
    &kreo_page_set('dir');
    my $file = `form_dir_file.tk file_create $var{dir}`;
    return if ! $file;
    return if &error('file_exist',$file);
    return if &error('dir_exist' ,$file);
    return if &shell_error("echo ' ' > $file");
    $var{file} = $file;
    &kreo_page_set('dir') }

sub file_delete {
    my $file = $_[0];
    $file = $var{file} if ! $file;
    return if &error('file_absent',$file);
    $file = `form_dir_file.tk file_delete $file`;
    return if ! $file;
    return if &shell_error("rm $file");
    $var{file} = '' if $file eq $var{file};
    &kreo_page_set('dir') }

sub file_copy {
    my $file = $_[0];
    $file = $var{file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form_dir_file.tk file_copy $file`;
    return if ! $file_new;
    return if &shell_error("cp -p $file $file_new");
    $var{file} = $file_new;
    &kreo_page_set('file') }

sub file_rename {
    my $file = $_[0];
    $file = $var{file} if ! $file;
    return if &error('file_absent',$file);
    my $file_new = `form_dir_file.tk file_rename $file`;
    return if ! $file_new;
    return if &shell_error("mv $file $file_new");
    $var{file} = $file_new;
    &kreo_page_set('file') }

sub chmod {
    my($var,$file) = @_;
    $var = `form_chmod.tk "$var" $file`;
    return if ! $var;
    return if &shell_error("chmod $var $file");
    &kreo_page_set('dir') }

sub chown {
    my($var,$file) = @_;
    $var = `form_chown.tk "$var" $file`;
    return if ! $var;
    return if &shell_error("chown $var $file");
    &kreo_page_set('dir') }

##### Archive #####
sub archive_select {
    $var{dir}  = "$dir{facila}/archive";
    $var{file} = '';
    &kreo_page_set('dir') }

sub archive_create {
    my $file = "$dir{data}/project/$var{project}";
    return if &error('project_absent',$file);
    $var{dir}  = "$dir{facila}/archive";
    $var{file} = `$dir{prg}/archive_create.sh $var{project}`;
    &kreo_page_set('file') }

##### Quitter #####
sub quit_exit {
    my($file,$x,$v,$text);
    $file = "$dir{data}/init";
    foreach( sort { $a cmp $b } keys %init) { $text .= "$_;$var{$_};\n" }
    open(FILE,">$var{mode}",$file);
    print FILE "$text";
    close FILE;

    unlink <$tmp{tmp}*>;
    exit }

sub quit_reinit {
    $widget{entry_include}->focus;
    $widget{entry_include}->delete('0.0','end');
    $widget{entry_exclude}->delete('0.0','end');
    $var{entry_case} = $init{entry_case};
    `cp /dev/null $tmp{debug}`;
    &kreo_page_set($var{page}) }

sub quit_restart {
    system("$dir{prg}/$var{appli} $env{user} &");
    &quit_exit }

1;
