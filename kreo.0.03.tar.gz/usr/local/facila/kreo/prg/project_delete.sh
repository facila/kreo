#!/bin/bash

# version 0.03 22/05/2021 par Thierry Le Gall
# script de suppression d'un projet dans kreo

FACILA=$1
PROJECT=$2

[ "$PROJECT" = "" ] && exit

cd $FACILA
[ -d "$PROJECT" ] && rm -Rf $PROJECT

cd kreo/data
FILE=note/$PROJECT    ; [ -f $FILE ] && rm -f $FILE
FILE=project/$PROJECT ; [ -f $FILE ] && rm -f $FILE
