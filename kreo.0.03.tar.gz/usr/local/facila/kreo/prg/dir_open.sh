#!/bin/bash

DIR=$1
gnome-terminal --geometry=132x32+100+100 --working-directory=$DIR -- bash -c "echo; ls --color=auto -alF; echo; bash" &
