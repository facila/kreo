sub appli_init {
    # variables sauvegardées dans init
    my $file = "$dir{data}/init";
    my($x,$v,$page);
    open(FILE,"<$var{mode}",$file);
    while(<FILE>) {
       ($x,$v) = split/;/ ;
       $init{$x} = $var{$x} = $v }
    close FILE;

    $file{help}    = "$dir{var}/help/$file{help}";
    $file{note}    = "$dir{data}/note/$var{project}";
    $file{project} = "$dir{data}/project/$var{project}";
    &kreo_variable('variable');
    $page = $var{find} = 'project';
    if    ( $var{file} ) { $page = 'file' }
    elsif ( $var{dir}  ) { $page = 'dir'  }
    $var{page} = $page;
    &quit_reinit;
    $widget{book}->raise($page) }

sub appli_escape {
    &kreo_page($var{page}) }

sub appli_grep {
    # >> $tmp{tmp} car appli_grep peut etre appelé plusieurs fois sur la recherche dans le projet
    `$dir{share}/mygrep.sh "$var{find_opt}" "$var{entry_include}" "$var{entry_exclude}" "$var{find_file}" 2>/dev/null >> $tmp{tmp}` }

1;
