#!/bin/bash

# version 0.03 22/05/2021 par Thierry Le Gall
# script de copie d'un projet dans kreo

FACILA=$1
OLD=$2
NEW=$3

cd $FACILA
cp -Rp $OLD $NEW

cd $FACILA/kreo/data/project
cp -p $OLD $NEW
