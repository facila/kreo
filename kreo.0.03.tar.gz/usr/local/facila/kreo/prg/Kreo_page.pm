sub page_help {
    my $file = $file{help};
    return if &error('file_absent',$file);
    my $page = $var{page};
    my $info = '';
    my $text;
    &kreo_shell(\$text,"cat $file");
    &kreo_page_text($page,\$text,\$info) }

sub page_list {
    my $file = "$dir{data}/project";
    return if &error('dir_absent',$file);
    my $page = $var{page};
    my $info = '';
    my $text;
    &kreo_shell(\$text,"( echo ; ls -1 $file | awk '{ print \" \" \$0 }')");
    &kreo_page_text($page,\$text,\$info);
    &tag_list($page,\$text) }

sub page_note {
    my $project = $file{project};
    return if &error('project_absent',$project);
    my $note = $file{note};
    return if &error('note_absent',$note);
    my $page = $var{page};
    my $text;
    &kreo_shell(\$text,"cat $note");
    &kreo_page_text($page,\$text,\" $note") }

sub page_project {
    my $project = $file{project};
    return if &error('project_absent',$project);
    my $page  = $var{page};
    my ($tag) = @_;
    my $text;
    &kreo_shell(\$text,"cat $project");
    &kreo_page_text($page,\$text,\" $project");
    &tag_file($page,\$text) if $tag }

sub page_dir {
    my $dir = $var{dir};
    return if &error('dir_absent',$dir);
    my $page = $var{page};
    &kreo_variable('variable');
    &kreo_insert($widget{info},\" $dir",$fg{dir},$bg{dir});
    my $text = '';
    &kreo_wait;
    &kreo_shell(\$text,"ls -al $dir");
    &kreo_insert($page{$page},\$text,$fg{text},$bg{text});
    &tag_dir($page,\$text)}

sub page_file {
    my $file = $var{file};
    return if &error('file_absent',$file);
    my $page = $var{page};
    `( echo $file ; grep -v $file $tmp{histo} ) > $tmp{tmp}; cp $tmp{tmp} $tmp{histo}`;
    &kreo_variable('variable');

    my $fg = $fg{file};
    my $bg = $bg{file};
    my $text = &kreo_file_info($file);
    my $date = &kreo_file_date($file);
    if    ( $var{file_ext}  eq 'gz'     ) { $fg = $fg{gz}     }
    elsif ( $var{file_code} eq 'binary' ) { $fg = $fg{binary} }
    if    ( $date                       ) { ($fg,$bg) = ($bg,$fg) } # invers video si date = jour
    &kreo_insert($widget{info},\$text,$fg,$bg);

    $text = '';
    if ( -s $file ) {
       if ( $var{file_code} ne 'binary' ) { &kreo_shell(\$text,"cat $file") }
       if ( $var{file_ext}  eq 'gz'     ) { &kreo_shell(\$text,"cat $dir{var}/help/gz") } }
    &kreo_insert($page{$page},\$text,$fg{text},$bg{text}) }

sub page_find {
    $var{entry_include} = $widget{entry_include}->get();
    $var{entry_exclude} = $widget{entry_exclude}->get();
    return if &error('entry');

    $var{find_opt}  = '-s';
    $var{find_opt} .= 'i' if $var{entry_case};
    `cp /dev/null $tmp{tmp}`;

    &kreo_wait;
    my $fct = "find_$var{find}";
    return if &$fct;
    return if &error('find',$tmp{tmp});

    my $text = my $info = '';
    `cp $tmp{tmp} $tmp{find}`; # $tmp{find} utilisé pour rechercher dans la page Rechercher

    if    ( $var{find} eq 'file'        ) { $var{tag} = 0 }
    elsif ( $var{find} =~ /dir|project/ ) { $var{tag} = 1 }

    &kreo_shell    (\$text,"cat $tmp{find}");
    &kreo_page_text('find',\$text,\$info);
    &tag_file      ('find',\$text) if $var{tag};

    $text = &kreo_file_line($tmp{find});
    $text = " $text lignes dans $var{find_info}";
    &kreo_insert($widget{info},\$text,$fg{result},$bg{result}) }

sub page_histo {
    my $page = 'histo';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat $tmp{histo}");
    &kreo_page_text($page,\$text,\$info);
    &tag_file      ($page,\$text) }

sub page_debug {
    my $page = 'debug';
    my $info = '';
    my $text; &kreo_shell(\$text,"cat $tmp{debug}");
    &kreo_page_text($page,\$text,\$info) }

sub page_var {
    &kreo_page_global('var') }

####################################################################
# fonctions find

# rechercher dans la page Rechercher
sub find_find {
    return 1 if &error('find_empty',$tmp{find});
    $var{find_file} = $tmp{find};
    $var{find_info} = $msg{result_find};
    &appli_grep }

# rechercher dans le fichier
sub find_file {
    return 1 if &error('file_absent',$var{file});
    $var{find_file} = $var{find_info} = $var{file};
    &appli_grep }

# rechercher dans le dossier
sub find_dir {
    return 1 if &error('dir_absent',$var{dir});
    $var{find_file} = $var{find_info} = $var{dir};
    chdir $var{find_file};
    $var{find_file} .= "/*";
    &appli_grep }

# rechercher dans le projet
sub find_project {
    my $project = "$dir{data}/project/$var{project}";
    return 1 if &error('project_absent',$project);
    my $opt = $var{find_opt};
    $var{find_info} = $var{project};
    my $text; &kreo_shell(\$text,"cat $project");
    foreach(split/\n/,$text) {
       if ( -d $_ ) {
         #$var{find_file} = "$_/*";
          $var{find_file} = "$_";
          chdir $_;
          &appli_grep }
       elsif ( -s $_ ) {
          $var{find_file} = $_ ;
          $var{find_opt} .= 'H';
          &appli_grep;
          $var{find_opt} = $opt } } }

1;
