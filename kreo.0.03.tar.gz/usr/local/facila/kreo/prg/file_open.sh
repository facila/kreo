#!/bin/bash

FILE=$1
gnome-terminal --geometry=132x32+100+100 --title $FILE -- vim $FILE
