#!/bin/bash

# version 0.03 22/05/2021 par Thierry Le Gall
# script de création d'un projet dans kreo

FACILA=$1
PROJECT=$2
DIR=$FACILA/$PROJECT

mkdir $DIR
mkdir $DIR/prg

echo $DIR/prg/$PROJECT > $FACILA/kreo/data/note/$PROJECT
echo $DIR/prg/$PROJECT > $FACILA/kreo/data/project/$PROJECT

{
echo "#!/bin/bash"
echo
echo "# ligne à remplacer par le fichier de démarrage de l'application"
echo $DIR/prg/$PROJECT.sh
} > $DIR/prg/$PROJECT

chmod +x $DIR/prg/$PROJECT
